#!/bin/bash
#
# Builds Daylight.app.
#
# There is no Xcode project: the app is a Swift package plus a bundle assembled
# here. That keeps it buildable with only the Command Line Tools installed.
set -euo pipefail

cd "$(dirname "$0")/.."
ROOT="$(pwd)"
CONFIG="${1:-release}"
APP_NAME="Daylight"
BUNDLE_ID="app.daylight.Daylight"
VERSION="1.0.0"
BUILD="1"
OUT="$ROOT/build"
APP="$OUT/$APP_NAME.app"
# The bundle is assembled and signed in a staging directory outside the project.
# If the project lives in an iCloud-synced folder (~/Documents, ~/Desktop), the
# file provider attaches a com.apple.FinderInfo attribute to new directories,
# and codesign refuses to sign or verify a bundle carrying one.
STAGE="$(mktemp -d "${TMPDIR:-/tmp}/daylight-build-XXXXXX")"
STAGED_APP="$STAGE/$APP_NAME.app"
trap 'rm -rf "$STAGE"' EXIT

echo "==> Building ($CONFIG)"
swift build -c "$CONFIG" --product daylight

BIN="$ROOT/.build/$CONFIG/daylight"
[ -x "$BIN" ] || { echo "build produced no binary"; exit 1; }

echo "==> Assembling bundle"
mkdir -p "$STAGED_APP/Contents/MacOS" "$STAGED_APP/Contents/Resources"
cp "$BIN" "$STAGED_APP/Contents/MacOS/$APP_NAME"

echo "==> Generating icon"
ICONSET="$STAGE/icon.iconset"
rm -rf "$ICONSET"
mkdir -p "$OUT"
swiftc -O "$ROOT/Scripts/make-icon.swift" -o "$STAGE/make-icon" 2>/dev/null
"$STAGE/make-icon" "$ICONSET" >/dev/null
iconutil -c icns "$ICONSET" -o "$STAGED_APP/Contents/Resources/$APP_NAME.icns"
rm -rf "$ICONSET"

cat > "$STAGED_APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleName</key><string>$APP_NAME</string>
    <key>CFBundleDisplayName</key><string>$APP_NAME</string>
    <key>CFBundleIdentifier</key><string>$BUNDLE_ID</string>
    <key>CFBundleExecutable</key><string>$APP_NAME</string>
    <key>CFBundleIconFile</key><string>$APP_NAME</string>
    <key>CFBundlePackageType</key><string>APPL</string>
    <key>CFBundleShortVersionString</key><string>$VERSION</string>
    <key>CFBundleVersion</key><string>$BUILD</string>
    <key>LSMinimumSystemVersion</key><string>14.0</string>
    <!-- A menu bar utility: no Dock icon, no window on launch. -->
    <key>LSUIElement</key><true/>
    <key>NSHumanReadableCopyright</key><string>Daylight</string>
    <key>NSSupportsAutomaticTermination</key><false/>
    <key>NSSupportsSuddenTermination</key><false/>
</dict>
</plist>
PLIST
plutil -lint "$STAGED_APP/Contents/Info.plist" >/dev/null

printf 'APPL????' > "$STAGED_APP/Contents/PkgInfo"

echo "==> Signing"
# Extended attributes picked up from the filesystem make codesign refuse the
# bundle with "resource fork, Finder information, or similar detritus".
xattr -cr "$STAGED_APP" 2>/dev/null || true
find "$STAGED_APP" -name '.DS_Store' -delete 2>/dev/null || true
# Ad-hoc signature. This makes the bundle launchable on this machine; it is NOT
# a Developer ID signature and the app is NOT notarised. See Docs/release.md for
# the remaining distribution steps.
if ! codesign --force --deep --sign - --options runtime "$STAGED_APP" 2>/dev/null; then
    codesign --force --deep --sign - "$STAGED_APP"
fi
if codesign --verify --deep --strict "$STAGED_APP" 2>/dev/null; then
    echo "    ad-hoc signature verified"
else
    echo "    WARNING: signature did not verify" >&2
    exit 1
fi

echo "==> Installing"
mkdir -p "$OUT"
rm -rf "$APP"
ditto "$STAGED_APP" "$APP"
xattr -cr "$APP" 2>/dev/null || true

VERIFIED_COPY=""
if ! codesign --verify --deep --strict "$APP" 2>/dev/null; then
    # A synced folder (iCloud Desktop & Documents, Dropbox and similar) attaches
    # com.apple.FinderInfo to new directories, and codesign refuses to verify a
    # bundle carrying one. The app still launches; the signature just cannot be
    # checked in place. Keep a verifiable copy somewhere that is not synced.
    VERIFIED_COPY="$HOME/Library/Caches/$APP_NAME/$APP_NAME.app"
    mkdir -p "$(dirname "$VERIFIED_COPY")"
    rm -rf "$VERIFIED_COPY"
    ditto "$STAGED_APP" "$VERIFIED_COPY"
    if codesign --verify --deep --strict "$VERIFIED_COPY" 2>/dev/null; then
        echo "    note: this project is in a synced folder, which adds an extended"
        echo "          attribute that codesign rejects. build/$APP_NAME.app runs"
        echo "          normally but cannot be verified in place."
    else
        echo "    WARNING: could not produce a verifiable copy" >&2
        VERIFIED_COPY=""
    fi
fi

echo ""
echo "Built: $APP"
du -sh "$APP" | awk '{print "Size:  " $1}'
echo ""
if [ -n "$VERIFIED_COPY" ]; then
    echo "Verified copy: $VERIFIED_COPY"
    echo "               (use this one for signing, notarising or distributing)"
    echo ""
fi
echo "Run with:      open \"$APP\""
echo "Simulation:    \"$APP/Contents/MacOS/$APP_NAME\" --simulate"
echo "Diagnostics:   \"$APP/Contents/MacOS/$APP_NAME\" --diagnose"
