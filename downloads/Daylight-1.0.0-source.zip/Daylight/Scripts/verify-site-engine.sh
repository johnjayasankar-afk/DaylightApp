#!/bin/bash
#
# Checks that the landing page's JavaScript engine still agrees with the Swift
# one. The page claims to run the app's real schedule maths; this is what makes
# that a fact rather than a hope.
#
# Compares sunrise and sunset across a spread of latitudes — including polar
# cases — at the solstices and equinoxes.
set -euo pipefail
cd "$(dirname "$0")/.."

command -v node >/dev/null || { echo "node is required for this check" >&2; exit 2; }

TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

swift build --product daylight >/dev/null

cat > "$TMP/ref.swift" <<'EOF'
import Foundation
import DaylightCore
let cities = ["London", "New York", "Tokyo", "Sydney", "Reykjavík", "Tromsø",
              "Singapore", "São Paulo", "Anchorage", "Cape Town"]
for name in cities {
    guard let c = Cities.all.first(where: { $0.name == name }),
          let z = TimeZone(identifier: c.timeZoneIdentifier) else { continue }
    for (mo, d) in [(3, 20), (6, 21), (9, 22), (12, 21)] {
        var cal = Calendar(identifier: .gregorian); cal.timeZone = z
        let day = cal.date(from: DateComponents(year: 2026, month: mo, day: d))!
        for kind in [SolarEvent.sunrise, .sunset] {
            let r = SolarCalculator.event(kind, date: day, location: c.location, timeZone: z)
            let text: String
            switch r {
            case .occurs(let s): text = String(format: "%.0f", (s / 60).rounded())
            case .polarDay: text = "polar-day"
            case .polarNight: text = "polar-night"
            }
            print("\(name)|2026-\(mo)-\(d)|\(kind.rawValue)|\(text)")
        }
    }
}
EOF

swiftc -O "$TMP/ref.swift" \
  -I .build/out/Products/Debug -L .build/out/Products/Debug -lDaylightCore \
  -o "$TMP/ref" 2>/dev/null
"$TMP/ref" > "$TMP/swift.txt"

node -e "
global.window = {};
require('$PWD/site/assets/data.js');
require('$PWD/site/assets/engine.js');
const E = window.DaylightEngine;
const cities = ['London','New York','Tokyo','Sydney','Reykjavík','Tromsø','Singapore','São Paulo','Anchorage','Cape Town'];
const out = [];
for (const name of cities) {
  const c = E.cities.find(x => x.name === name);
  if (!c) continue;
  for (const [mo, d] of [[3,20],[6,21],[9,22],[12,21]]) {
    const probe = new Date(Date.UTC(2026, mo-1, d, 12, 0, 0));
    const off = E.zoneOffsetMinutes(c.tz, probe);
    for (const kind of ['sunrise','sunset']) {
      const r = E.solarEvent(kind, {year:2026, month:mo, day:d, lat:c.lat, lon:c.lon, offsetMinutes:off});
      const text = (r === E.POLAR_DAY) ? 'polar-day' : (r === E.POLAR_NIGHT) ? 'polar-night' : String(Math.round(r));
      out.push(\`\${name}|2026-\${mo}-\${d}|\${kind}|\${text}\`);
    }
  }
}
require('fs').writeFileSync('$TMP/js.txt', out.join('\n') + '\n');
"

if diff -q "$TMP/swift.txt" "$TMP/js.txt" >/dev/null; then
    echo "site engine matches the app across $(wc -l < "$TMP/swift.txt" | tr -d ' ') solar probes"
else
    echo "MISMATCH between the site engine and the app:" >&2
    diff "$TMP/swift.txt" "$TMP/js.txt" >&2 || true
    exit 1
fi
