import AppKit
import Foundation

// The application icon.
//
// Generated from source rather than shipped as a binary asset, so it is
// versioned, diffable, and restyled by editing numbers rather than by opening
// a drawing program.
//
// The composition is the product's own idea: a day's worth of colour
// temperature, cool at the top and warm at the horizon, with the sun sitting on
// the line between them. Everything is clipped to the tile — an earlier version
// let the horizon band escape the rounded corners, which left the bottom of the
// icon square.

/// macOS icon geometry. The artwork occupies a squircle inset from the canvas;
/// the margin is part of the specification, not wasted space.
private enum Geometry {
    static let tileFraction: CGFloat = 0.805      // tile width ÷ canvas width
    static let cornerFraction: CGFloat = 0.2237   // corner radius ÷ tile width
    static let horizonFraction: CGFloat = 0.400   // horizon height ÷ tile height
    static let sunDiameterFraction: CGFloat = 0.44
    static let sunCentreFraction: CGFloat = 0.435 // sun centre height ÷ tile height
}

private func lerp(_ a: CGFloat, _ b: CGFloat, _ t: CGFloat) -> CGFloat { a + (b - a) * t }

func drawIcon(canvas: CGFloat) -> NSBitmapImageRep {
    let rep = NSBitmapImageRep(
        bitmapDataPlanes: nil, pixelsWide: Int(canvas), pixelsHigh: Int(canvas),
        bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true, isPlanar: false,
        colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0)!

    NSGraphicsContext.saveGraphicsState()
    NSGraphicsContext.current = NSGraphicsContext(bitmapImageRep: rep)
    NSGraphicsContext.current?.imageInterpolation = .high

    let tileSide = canvas * Geometry.tileFraction
    let tile = NSRect(x: (canvas - tileSide) / 2, y: (canvas - tileSide) / 2,
                      width: tileSide, height: tileSide)
    let radius = tileSide * Geometry.cornerFraction
    let tilePath = NSBezierPath(roundedRect: tile, xRadius: radius, yRadius: radius)

    // A soft shadow under the tile, as system icons have. Drawn first so it
    // sits behind everything and never tints the artwork.
    NSGraphicsContext.saveGraphicsState()
    let shadow = NSShadow()
    shadow.shadowColor = NSColor.black.withAlphaComponent(0.28)
    shadow.shadowBlurRadius = tileSide * 0.045
    shadow.shadowOffset = NSSize(width: 0, height: -tileSide * 0.022)
    shadow.set()
    NSColor.black.setFill()
    tilePath.fill()
    NSGraphicsContext.restoreGraphicsState()

    // Everything below is clipped to the tile. This is the part that was
    // missing before, and it is why the icon had square bottom corners.
    NSGraphicsContext.saveGraphicsState()
    tilePath.addClip()

    // The sky is the product's own idea in one image: cool daylight high up,
    // warming as it comes down to the horizon. Drawn at 90°, so location 0 is
    // the bottom of the tile — the warm end.
    let sky = NSGradient(colorsAndLocations:
        (NSColor(calibratedRed: 0.925, green: 0.549, blue: 0.278, alpha: 1), 0.00),
        (NSColor(calibratedRed: 0.706, green: 0.416, blue: 0.353, alpha: 1), 0.26),
        (NSColor(calibratedRed: 0.396, green: 0.322, blue: 0.412, alpha: 1), 0.52),
        (NSColor(calibratedRed: 0.208, green: 0.255, blue: 0.384, alpha: 1), 0.78),
        (NSColor(calibratedRed: 0.129, green: 0.169, blue: 0.278, alpha: 1), 1.00))!
    sky.draw(in: tile, angle: 90)

    // The sun, sitting on the horizon.
    let sunDiameter = tileSide * Geometry.sunDiameterFraction
    let sunCentreY = tile.minY + tileSide * Geometry.sunCentreFraction
    let sunRect = NSRect(x: tile.midX - sunDiameter / 2, y: sunCentreY - sunDiameter / 2,
                         width: sunDiameter, height: sunDiameter)

    // A halo, so the disc sits in the sky rather than on top of it.
    let halo = NSGradient(colorsAndLocations:
        (NSColor(calibratedRed: 1.0, green: 0.75, blue: 0.45, alpha: 0.42), 0.0),
        (NSColor(calibratedRed: 1.0, green: 0.65, blue: 0.35, alpha: 0.0), 1.0))!
    halo.draw(in: sunRect.insetBy(dx: -sunDiameter * 0.55, dy: -sunDiameter * 0.55),
              relativeCenterPosition: .zero)

    let sun = NSGradient(colorsAndLocations:
        (NSColor(calibratedRed: 1.000, green: 0.906, blue: 0.702, alpha: 1), 0.00),
        (NSColor(calibratedRed: 0.988, green: 0.749, blue: 0.404, alpha: 1), 0.45),
        (NSColor(calibratedRed: 0.941, green: 0.545, blue: 0.243, alpha: 1), 1.00))!
    sun.draw(in: NSBezierPath(ovalIn: sunRect), angle: -90)

    // The ground: darker, and it covers the lower part of the disc.
    let horizonY = tile.minY + tileSide * Geometry.horizonFraction
    let ground = NSRect(x: tile.minX, y: tile.minY,
                        width: tile.width, height: horizonY - tile.minY)
    let groundGradient = NSGradient(colorsAndLocations:
        (NSColor(calibratedRed: 0.086, green: 0.094, blue: 0.129, alpha: 1), 0.0),
        (NSColor(calibratedRed: 0.145, green: 0.153, blue: 0.204, alpha: 1), 1.0))!
    groundGradient.draw(in: ground, angle: 90)

    // A bright line along the horizon, the one warm accent the interface uses.
    let line = NSBezierPath()
    line.move(to: NSPoint(x: tile.minX, y: horizonY))
    line.line(to: NSPoint(x: tile.maxX, y: horizonY))
    line.lineWidth = max(1, tileSide * 0.012)
    NSColor(calibratedRed: 1.0, green: 0.784, blue: 0.475, alpha: 0.92).setStroke()
    line.stroke()

    NSGraphicsContext.restoreGraphicsState()

    // A hairline rim, which keeps the tile from dissolving into a dark
    // background in dark mode.
    let rim = NSBezierPath(roundedRect: tile.insetBy(dx: 0.5, dy: 0.5),
                           xRadius: radius, yRadius: radius)
    rim.lineWidth = max(1, tileSide * 0.004)
    NSColor.white.withAlphaComponent(0.10).setStroke()
    rim.stroke()

    NSGraphicsContext.restoreGraphicsState()
    return rep
}

let out = CommandLine.arguments.count > 1 ? CommandLine.arguments[1] : "./icon.iconset"
try? FileManager.default.createDirectory(atPath: out, withIntermediateDirectories: true)
let specs: [(Int, String)] = [
    (16, "icon_16x16"), (32, "icon_16x16@2x"), (32, "icon_32x32"), (64, "icon_32x32@2x"),
    (128, "icon_128x128"), (256, "icon_128x128@2x"), (256, "icon_256x256"),
    (512, "icon_256x256@2x"), (512, "icon_512x512"), (1024, "icon_512x512@2x"),
]
for (px, name) in specs {
    let rep = drawIcon(canvas: CGFloat(px))
    if let data = rep.representation(using: .png, properties: [:]) {
        try? data.write(to: URL(fileURLWithPath: "\(out)/\(name).png"))
    }
}
print("icon set written to \(out)")
