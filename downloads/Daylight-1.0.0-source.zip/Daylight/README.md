# Daylight

Adjust your display to your preferences through the day.

Daylight is a macOS menu bar utility that gradually shifts your display's
warmth and brightness according to a schedule you control, and gets out of the
way the moment you want it to.

It works entirely on your Mac. No account, no network requests, no location
permission, no analytics. Sunrise and sunset come from a place you pick — from
a list built into the app or by coordinates — calculated locally.

---

## What it does today

- **Real warmth control** on any display macOS exposes a colour transfer table
  for, verified by reading the setting back after every write.
- **Software dimming**, clearly labelled as such — it is not backlight control,
  and the app never claims otherwise.
- **A scheduling engine** with clock anchors, solar anchors (calculated
  locally), separate weekday/weekend schedules, and schedules that cross
  midnight. Night shifts and non-Western weeks are ordinary cases, not
  special ones.
- **Pick your place from a built-in list** of 101 cities, or type coordinates.
  Daylight offers a starting suggestion from your time zone — a setting, not a
  position, so it costs no permission — and tells you if the place you picked
  keeps a different clock from your Mac.
- **A troubleshooting guide inside the app**, written as symptoms rather than
  features, with a button at the end of each answer instead of only advice.
- **An interactive daily timeline** you can drag, edit numerically, scrub, and
  read as text.
- **Temporary overrides** with visible, honest expiry — 15/30/60 minutes, until
  the next scheduled change, or until you resume.
- **Modes** (Focus, Reading, Wind Down, Colour Work, Presentation, Gaming,
  Night Desk) that are nothing more than named combinations of settings, each
  with its behaviour written out in full.
- **A small rules engine** — frontmost app, time range, weekday, battery,
  connected display — resolved per-control against a fixed, visible precedence
  ladder.
- **Per-display settings**: rename, exclude, warmth limits, dimming floor,
  brightness offset, keyed to durable display identity rather than an index.
- **Conflict detection.** If another utility (f.lux, Night Shift, another
  gamma tool) is fighting for the same display, Daylight says so in plain
  language instead of silently losing.
- **Editable modes.** Every mode is a named set of values with nothing hidden
  inside it. Make your own, change the built-in ones, or put the originals back.
- **Rules you can actually edit** — change what a rule matches and what it does,
  reorder them to break ties, and see which are matching right now.
- **Linked displays and workspaces.** Group monitors so they share limits;
  Daylight recognises where you are set up from which displays are attached —
  no location permission, no network sniffing.
- **Per-display manual changes.** Warm one screen without touching the other.
- **A command palette** (⇧⌥⌘K) for everything the menu bar can do.
- **Optional break reminders** — quiet, ignorable, no streaks or counters.
- **An optional local history** of what the app did, kept for as long as you
  choose and deleted when you switch it off.
- **Restoration** on quit, pause, restore, and preview cancellation — plus a
  global ⇧⌥⌘R shortcut that works without any permissions.
- **Full keyboard operation**, including the timeline: arrow keys move an
  anchor by five minutes, Shift-arrow by an hour, and every icon-only control
  has a real label.

### Experimental

- **External monitor backlight over DDC/CI.** Off by default. It uses private
  system API, only claims support for a display that has actually answered a
  capability query, and nothing else in the app depends on it. Unverified —
  there was no external monitor available to test it on.

## What it deliberately does not do

- It does not change your **built-in display's backlight**. macOS provides no
  public API for that, so Daylight offers software dimming and labels it
  honestly.
- It does not touch your **colour profiles or calibration data**.
- It makes **no medical claims**. It will not prevent eye damage, treat eye
  strain, or improve your sleep, and it contains no invented "circadian" or
  "eye health" scores. Temperature values are approximate display targets, not
  measurements of emitted light.
- It does not use the **camera** as a light sensor, read screen contents, or
  keep a history of which apps you use.

---

## Requirements

| | |
|---|---|
| macOS | 14.0 or later (developed and verified on macOS 27.0, build 26A5425a) |
| Architecture | Apple Silicon and Intel (verified on Apple Silicon, M1 Max) |
| Toolchain | Swift 6.x — **full Xcode is not required**, Command Line Tools is enough |

## Build and run

```bash
./Scripts/build-app.sh release
open build/Daylight.app
```

That produces `build/Daylight.app`, ad-hoc signed and launchable on the machine
that built it. There is no Xcode project: the app is a Swift package plus a
bundle assembled by that script.

If the project sits in an iCloud- or Dropbox-synced folder, the script says so
and also writes a signature-verifiable copy to `~/Library/Caches/Daylight/`.
The copy in `build/` runs perfectly well either way.

Run the tests:

```bash
swift build && ./.build/debug/daylight-tests
```

Render the interface to PNGs for review, in both themes:

```bash
swift build --product daylight-render && .build/out/Products/Debug/daylight-render ./shots
```

Run against fake displays, touching no real hardware:

```bash
./build/Daylight.app/Contents/MacOS/Daylight --simulate
```

Report what your displays actually support, changing nothing:

```bash
./build/Daylight.app/Contents/MacOS/Daylight --diagnose
```

Watch what happens as you dock, undock, sleep and wake:

```bash
./build/Daylight.app/Contents/MacOS/Daylight --watch-displays
```

Prove the whole chain — settings in, gamma table out — and put it back:

```bash
./build/Daylight.app/Contents/MacOS/Daylight --self-test
```

## First run

Daylight appears in the menu bar; it has no Dock icon. Setup takes about a
minute and asks for no permissions. Closing the main window leaves it running
in the menu bar. Quitting restores every display it changed.

## Uninstalling

1. Quit Daylight from the menu bar. This restores your displays.
2. Delete `Daylight.app`.
3. Delete `~/Library/Application Support/Daylight` if you want your settings
   gone too.
4. If you enabled "Start Daylight when I log in", turn it off first, or remove
   it under System Settings › General › Login Items.

Daylight installs no helpers, no daemons, and no kernel extensions, and makes
no persistent changes to your display configuration.

## If something looks wrong

- **Press ⇧⌥⌘R.** That restores normal output on every display immediately, and
  works whether or not the app's windows are open.
- If Daylight is not running, macOS itself restores the colour table when the
  process exits — including if it is force-quit. This was verified directly;
  see `Docs/test-results.md`.
- If your screen keeps flipping between two settings, another display utility
  is probably running. Daylight will say so in the Today view. Turn one of them
  off.

## Documentation

| | |
|---|---|
| [Architecture](Docs/architecture.md) | How the pieces fit together and why |
| [Compatibility](Docs/compatibility.md) | What is verified, what is not, and on what hardware |
| [Test results](Docs/test-results.md) | What was tested, how, and what the numbers were |
| [Roadmap](Docs/roadmap.md) | Status of every feature: done, experimental, blocked, planned |
| [Release checklist](Docs/release.md) | Signing, notarisation, and what remains for distribution |
| [Licences](Docs/licenses.md) | Dependencies, algorithms, and the licence decision still to make |

## Renaming

Everything user-visible comes from `Branding` in
`Sources/DaylightCore/Settings.swift`, plus the three name variables at the top
of `Scripts/build-app.sh`. Changing those two places renames the product.

## Licence and attribution

**No licence has been chosen yet**, so default copyright applies. If you intend
to share Daylight, add a `LICENSE` file — that choice is yours to make, not
one to inherit by accident.

There are no third-party dependencies: Daylight links only frameworks that ship
with macOS. It is an independent implementation containing no f.lux code,
branding or assets. Algorithms are implemented from their published
descriptions. Full details in [Docs/licenses.md](Docs/licenses.md).
