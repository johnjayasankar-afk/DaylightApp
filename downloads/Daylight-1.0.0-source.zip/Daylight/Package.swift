// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "Daylight",
    platforms: [.macOS(.v14)],
    products: [
        .library(name: "DaylightCore", targets: ["DaylightCore"]),
        .library(name: "DaylightDisplay", targets: ["DaylightDisplay"]),
        .library(name: "DaylightUI", targets: ["DaylightUI"]),
        .executable(name: "daylight", targets: ["DaylightApp"]),
        .executable(name: "daylight-tests", targets: ["DaylightTests"]),
        .executable(name: "daylight-render", targets: ["DaylightRender"]),
    ],
    targets: [
        // Pure logic. No platform display APIs. Deterministic and fully testable.
        .target(name: "DaylightCore", swiftSettings: [.swiftLanguageMode(.v5)]),
        // Platform adapters and the one authoritative controller per display.
        .target(name: "DaylightDisplay", dependencies: ["DaylightCore"], swiftSettings: [.swiftLanguageMode(.v5)]),
        // Every view. A library rather than part of the executable so the
        // renderer can build the real interface without the application object.
        .target(name: "DaylightUI", dependencies: ["DaylightCore", "DaylightDisplay"],
                swiftSettings: [.swiftLanguageMode(.v5)]),
        // The application shell: lifecycle, menu bar, windows.
        .executableTarget(
            name: "DaylightApp",
            dependencies: ["DaylightCore", "DaylightDisplay", "DaylightUI"],
            swiftSettings: [.swiftLanguageMode(.v5), .unsafeFlags(["-parse-as-library"])]
        ),
        // XCTest and swift-testing are not present in a Command Line Tools
        // toolchain, so the suite runs as an executable with a small
        // ObjC-runtime-driven runner. Same assertions, same exit codes.
        .executableTarget(name: "DaylightTests", dependencies: ["DaylightCore", "DaylightDisplay"],
                          swiftSettings: [.swiftLanguageMode(.v5)]),
        // Renders the real views to PNGs so the interface can be reviewed in
        // light and dark themes, and at narrow widths, without a screenshot.
        .executableTarget(name: "DaylightRender",
                          dependencies: ["DaylightCore", "DaylightDisplay", "DaylightUI"],
                          swiftSettings: [.swiftLanguageMode(.v5), .unsafeFlags(["-parse-as-library"])]),
    ]
)
