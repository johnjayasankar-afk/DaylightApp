# Improvement log

A running record of iterative work on the Daylight landing page (`site/`), so
each cycle builds on the last rather than rediscovering or reversing it.

---

## Cycle 1 — the demo becomes the argument

**Context.** The page described the product well but *demonstrated* almost none
of it. It showed one of the app's four presets, used none of its 101 cities or
its solar calculator, and talked about warmth in kelvin without ever showing
what a kelvin value looks like. A visitor's two real questions — *what will this
do to my screen?* and *which setting is right for me?* — were answered in prose.

### What this cycle delivered

**The hero demo now runs the app's real engine, and answers both questions.**

- **All four presets**, switchable — Balanced, Subtle, Extra Warm, Follow the
  sun. This is the same choice the app puts in front of you during setup, so
  the page lets you make it before downloading.
- **A city picker over the app's own 101 cities**, with today's real sunrise and
  sunset. Pick one and the sun-following preset resolves against your actual
  location, clamps and all. Preselected from the browser's time zone — a
  setting, not a position, so it costs no permission — and remembered in
  `localStorage`.
- **A warmth preview.** A sample panel is multiplied by the very channel gains
  the app writes to the display, so it is the same arithmetic, applied to one
  box on a page. *Hold to compare* shows it unmodified. The caption says
  plainly that a web page cannot change your display and the app can.
- **A step list** showing the resolved schedule, annotated when an anchor is
  clamped away from the sun or falls back for want of a location.
- **The scrubber's track is painted from the schedule on screen**, so the
  control doubles as a legend.

**How the page is kept honest.** Two new scripts:

- `Scripts/build-site-data.sh` regenerates `site/assets/data.js` from
  `Daylight --export-site-data`. The presets and cities on the page are the
  app's own, not transcribed.
- `Scripts/verify-site-engine.sh` diffs the JavaScript solar port against the
  Swift one across 80 probes.

### What was actually verified

- **Engine parity:** JS and Swift agree on all 80 solar probes — 10 cities
  (Tromsø and Reykjavík for high latitude, Singapore for the equator, Sydney
  and São Paulo for the southern hemisphere) across both solstices and both
  equinoxes, sunrise and sunset. Re-runnable via `Scripts/verify-site-engine.sh`.
- **Data parity:** regenerating `data.js` after the change produced no diff.
- **Behaviour, in a browser:** preset switching, city switching (New York →
  Tromsø → Singapore) with anchors landing exactly 30 minutes before real
  sunset as the preset specifies; scrub; *Back to now*; compare.
- **Accessibility:** 232 text nodes measured against WCAG AA in dark and light,
  0 failures, lowest ratio 6.34. One `h1`, no heading skips, no unnamed
  controls, no image missing alt text.
- **Layout:** no horizontal overflow at 320, 375, 390, 768, 1024 or 1280.
  Desktop keeps chart and preview side by side; below 860 px they stack with
  the preview promoted above the step list.
- **App unaffected:** 263 Swift tests still pass.
- No console errors.

### Bugs found and fixed this cycle

1. **`[hidden]` did nothing.** "Back to now" was visible on load while
   reporting `hidden === true`: `[hidden]` is only a UA-stylesheet
   `display: none`, and `.button`'s `display: inline-flex` beat it. Now set
   globally with `!important`, so the attribute means what it says.
2. **`body { overflow-x: hidden }` was masking overflow rather than preventing
   it — and it made every `scrollWidth` check meaningless, because a clipped
   page can never report being too wide.** Removed, then re-verified honestly.
3. The sunrise/sunset readout was derived from the active preset's anchors, so
   it was blank on the three presets that do not follow the sun — making the
   city picker look inert. Now computed independently.

### A measurement worth not repeating

An apparent mobile clipping bug was a **capture artifact**: Chrome enforces a
minimum window width on macOS, so `--window-size=390` lays out wider and crops
the screenshot. Rendering the same page in a 700 px window showed it fitting
with room to spare, and direct DOM measurement in a real 375 px viewport found
zero elements past the edge. Trust the DOM measurement over the screenshot at
narrow widths.

### Limitations and dependencies

- The warmth preview is a **browser approximation**, not a display change. It
  applies the app's real gains, but to one element — it cannot show what your
  panel would do, and the page says so.
- The demo shows **today** only. Clamps and polar cases are implemented and
  annotated, but a visitor in September cannot see the December behaviour that
  makes them interesting.
- `Scripts/verify-site-engine.sh` needs `node`, which is not required to build
  or run either the app or the site.
- The download remains **signed but not notarised**; see `site/DEPLOY.md` and
  `Docs/release.md`.

### Highest-value opportunities next cycle

1. **Let the demo move through the year, not just the day.** A month control
   would make the solar clamps and polar day/night visible — currently the most
   interesting behaviour in the schedule engine is invisible for most of the
   year. Likely the single biggest remaining gain.
2. **The page above the demo is still all prose.** The three "how it works"
   cards and six "details" cards are well written but visually uniform; one or
   two deserve a small diagram or a live element.
3. **No comparison with the obvious alternative.** Visitors will be weighing
   this against f.lux and Night Shift. An honest, non-disparaging comparison of
   what each does and does not do would be genuinely useful — and the app's own
   conflict detection gives it something true to say.
4. **The screenshots are static.** The Displays and Rules views are shown as
   images; the schedule editor could plausibly be made interactive using the
   same engine already on the page.
