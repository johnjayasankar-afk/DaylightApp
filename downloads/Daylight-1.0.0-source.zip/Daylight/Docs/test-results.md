# Test results

Recorded on the reference machine described in [compatibility.md](compatibility.md).
Everything below is either an automated assertion or a value observed directly.
Nothing here is an estimate.

## Automated suite

```bash
swift build && ./.build/out/Products/Debug/daylight-tests
```

    ok   ColourScienceTests  (8 tests)
    ok   SolarTests  (8 tests)
    ok   CityTests  (15 tests)
    ok   CitySearchNormalisationTests  (3 tests)
    ok   LocationTimeZoneTests  (7 tests)
    ok   ScheduleResolutionTests  (25 tests)
    ok   PrecedenceTests  (7 tests)
    ok   OverrideTests  (6 tests)
    ok   RulesTests  (12 tests)
    ok   TransitionTests  (11 tests)
    ok   PersistenceTests  (17 tests)
    ok   SettingsForwardCompatibilityTests  (8 tests)
    ok   DisplayIdentityTests  (6 tests)
    ok   BaselineValidatorTests  (6 tests)
    ok   DeviceAdapterTests  (17 tests)
    ok   CoordinatorIntegrationTests  (14 tests)
    ok   WorkspaceTests  (9 tests)
    ok   DisplayGroupTests  (7 tests)
    ok   GroupEditingTests  (4 tests)
    ok   BreakReminderTests  (13 tests)
    ok   CommandPaletteTests  (9 tests)
    ok   HistoryTests  (13 tests)
    ok   ExtremeSettingsTests  (6 tests)
    ok   OverrideScopeTests  (5 tests)
    ok   DDCProtocolTests  (12 tests)
    ok   SleepingDisplayTests  (3 tests)
    ok   ExperimentalBrightnessTests  (5 tests)
    ok   ScopedOverrideIntegrationTests  (7 tests)

    263 tests, 10611 assertions, 0 failed  —  16.384s

XCTest and swift-testing are not available in a Command Line Tools toolchain,
so the suite runs as an executable with a small XCTest-shaped runner. It
discovers test methods through the ObjC runtime and exits non-zero on failure.

### What the suite covers

| Area | Examples |
|---|---|
| Colour science | Neutral maps to unity gains; gains never exceed 1 (no clipping); blue falls monotonically with temperature; mired interpolation is not linear kelvin |
| Solar | London midsummer/midwinter, Sydney (southern hemisphere), Tromsø polar day **and** polar night reported rather than faked, leap day, invalid coordinates |
| Schedule | Holds between anchors; exact value at the anchor; halfway at mid-ramp; after-midnight uses yesterday's anchor; **night-shift schedule that wakes at 20:00**; weekday/weekend; **custom weekend days (Fri–Sat)**; the weekday/weekend boundary across midnight |
| Time | Spring-forward keeps wall-clock anchors; the 02:30 gap anchor counts as passed when the clock jumps; the repeated fall-back hour evaluates identically both times; time-zone change re-resolves to local wall clock |
| Degenerate input | Empty schedule; disabled anchors; zero-length transition; colliding anchors resolved deterministically with a plain-language diagnostic; solar anchor with no location; polar night fallback |
| Precedence | Higher layer wins; **per-control resolution keeps warmth when a rule sets only brightness**; pause outranks rules; emergency restore outranks pause; explanation names the responsible rule |
| Overrides | Duration expiry; until-next-change; until-resumed never expires silently; the status sentence reads as English |
| Rules | All triggers must match; time range wrapping midnight; overlapping rules resolved by visible order; overlapping rules on different controls both apply; a rule with no triggers never matches; a deleted profile is ignored rather than crashing |
| Transitions | Retargeting mid-fade is continuous (no jump); fade is monotonic and bounded; tick interval scales with how much actually changes; no busy loop when nothing changes; write policy suppresses invisible changes; slow-device rate limit |
| Persistence | Round trip; **no temporary files survive a save**; corrupt file recovers the user's settings from the backup; unrecoverable state falls back to defaults and says so; migration from an older and a *newer* schema; validation repairs out-of-range values; imported files are clamped before use; **export contains no secrets**; an unknown display gets safe defaults rather than someone else's settings |
| Identity | UUID preferred over EDID; stable across calls; identical monitors produce the same key; different serials distinguished |
| Baseline | A plain ramp is accepted; a slightly calibrated profile is accepted; **f.lux's actual measured table (R 1.00 / G 0.36 / B 0.10) is rejected**; a dimmed or non-monotonic table is rejected |
| Device adapters | Disconnect (at prepare and mid-session), timeout, write failure, **accepted-but-unverifiable is not reported as confirmed**, readback disagreement, foreign overwrite, rate limiting, partial failure across devices leaves the healthy one working, repeated application does not accumulate |
| Coordinator (integration) | Schedule reaches the devices; pause/resume; override expires back to the schedule; emergency restore; automation off; **preview cleans up on cancel and on its own expiry**; per-display limits win over the schedule; excluded display untouched; settings survive a restart; wake recomputes rather than replays |

| Workspaces | Most specific match wins; catch-all; extra displays do not break a match; disabled skipped; sits below app rules and above the schedule |
| Display groups | Members share limits; names and exclusions stay per-display; a display belongs to one group; a group of one is dropped; **editing a grouped display's limit actually takes effect** |
| Break reminders | Interval; quiet hours defer rather than skip; wrapping midnight; silencing modes; snooze; clamping; **reminder text contains no medical or guilt language** |
| Command palette | Prefix, initials, keyword and subsequence matching; no-match returns empty; ties break stably |
| DDC/CI framing | Set and get packets match the MCCS byte layout and checksum; replies with a bad checksum, an error result, the wrong feature, a zero maximum, or truncation are all rejected; level conversion round-trips and clamps |
| Workspaces | Most specific match wins; catch-all; extra displays do not break a match; sits below app rules and above the schedule |
| Override scope | A change aimed at one display leaves the others alone; group scope covers members only; scope survives encoding; an override written before scopes existed defaults to all displays |
| History | Nothing is written while it is off; identical entries within a minute collapse; retention prunes; the count is capped regardless; clearing removes the file; **entry wording carries no health claims** |
| Extreme settings | Warm, dim and both-together each get their own message; the boundary itself is not flagged; the message includes the way back |
| Bundled cities | Every one of the 101 entries has valid coordinates, names a real IANA zone, and **its longitude agrees with that zone's UTC offset**; sunset at an equinox falls in a plausible hour for all of them; search handles case, accents, and letters that survive Unicode folding (ø, æ, ð) |
| Location | A city carries its time zone; a mismatch with the Mac's clock is detected; zones that merely share an offset are not flagged; a location from a settings file written before time zones were recorded still decodes |
| Settings compatibility | **A settings file from the first release still loads**, with the user's schedules, anchors and per-display settings intact; unknown future fields are ignored; a single unreadable field costs that field only |

### Bugs the suite caught during development

1. **Schedule ran an hour late on a daylight-saving day.** Anchors were stored
   in wall-clock seconds but evaluated in elapsed time, which diverge on a
   23-hour day. Fixed by evaluating from the clock's own fields; the fix is
   pinned by `testSpringForwardKeepsWallClockAnchors`.
2. **Emergency restore left the interface lying.** It restored the hardware but
   never recomputed the published state, so the Today view kept explaining an
   override that was no longer in force. Caught by
   `testEmergencyRestoreGoesNeutralImmediately`.
3. **The simulated built-in display described itself as external** — a small
   thing, but simulation that misreports is worse than no simulation.
4. **Editing a limit on a linked display did nothing.** The write went to the
   display's own settings, which the group's shared settings then overrode.
5. **A "Workspace" layer was listed in the visible precedence ladder while
   nothing could set it** — a feature implied but not present. Removed, then
   reinstated once workspaces were actually built.
6. **Two settings were stored but read by nothing.** `warnOnExtremeSettings`
   and `respectsReducedMotion` were saved, loaded, migrated and tested, and
   affected nothing whatsoever. Found by grepping every settings field for a
   use outside the settings file. Both now have behaviour behind them.
7. **Editing a limit on a linked display wrote to the wrong place** and was
   immediately overridden by the group's own settings, so the control moved and
   nothing happened.
8. **A sleeping display was skipped entirely.** The tick loop only wrote to a
   display reporting `.connected`, so with the screen asleep nothing was
   applied at all — and the correct value only arrived after the screen came
   back, which is exactly when a wrong one is most visible. A sleeping display
   is still online and still has a transfer table; only a disconnected one is
   skipped now.
9. **The application delegate could be released before launch finished.**
   `NSApplication.delegate` is weak, and the delegate was held only in a local
   constant whose last strong use was the assignment — ARC was free to release
   it before `run()` called `applicationDidFinishLaunching`. It happened to
   work for several builds, which is the worst kind of working. Now stored for
   the life of the process.

### The bug the suite did *not* catch, and what changed

Adding fields to `DaylightSettings` broke loading of every settings file
written by an earlier build. Swift's synthesised decoder treats a missing key
as an error even for a property with a default value, so the load threw, the
store fell back to defaults, and **the entire configuration was silently
replaced**.

It was found by running the built app against a settings file written earlier
in the session and noticing the display went to 2800 K / 70 % when the file
asked for 3000 K / 85 %:

    settings file:  Verification schedule, 3000 K at 85%
    observed:       0.7000, 0.3251, 0.0827   <- 2800 K @ 70%, the default schedule

The migration test that existed did not catch it, because it took a *current*
struct and changed its version number — which exercises nothing about decoding.
`SettingsForwardCompatibilityTests` now decodes literal older JSON payloads,
and every `Codable` type that can gain fields decodes each one with
`decodeIfPresent` and a default. After the fix, the same check gives:

    settings file:  Verification schedule, 3000 K at 85%
    observed:       0.8500, 0.4311, 0.1321   <- exactly right

## Hardware verification

### Real display control, end to end, through the built app

The built `Daylight.app` was launched with a schedule pinned to 3000 K at 85 %
dimming, and the transfer table was read directly with an independent tool.

| Step | R | G | B |
|---|---|---|---|
| Before launch | 1.0000 | 1.0000 | 1.0000 |
| App running (t+1s … t+4s, stable) | **0.8500** | **0.4311** | **0.1321** |
| Independently computed for 3000 K @ 85 % | **0.8500** | **0.4311** | **0.1321** |
| After quit | 1.0000 | 1.0000 | 1.0000 |

Exact agreement to four decimal places, and full restoration on quit.
This is **readback-confirmed**, not visually confirmed — see the vocabulary
note in [compatibility.md](compatibility.md).

### Write, readback and restore, in isolation

    CGSetDisplayTransferByTable  err = 0
    readback max R,G,B           = 1.0000, 0.2780, 0.0506
    expected max R,G,B           = 1.0000, 0.2780, 0.0506
    max deviation from request   = 0.00000   -> ACCEPTED & READBACK MATCHES

### Cleanup when the process dies

| Scenario | Table afterwards |
|---|---|
| Normal exit without restoring | 1.0000, 1.0000, 1.0000 |
| `SIGKILL` while holding a transform | 1.0000, 1.0000, 1.0000 |

macOS restores the transfer table when the owning process exits, including when
it is force-quit. This is why Daylight ships no watchdog helper.

### Conflict with another utility, measured

f.lux was running during development. With Daylight holding its own value:

    t+1s  drift 0.00000
    t+2s  drift 0.08264   <-- overwritten by another process
    t+3s  drift 0.08264
    t+4s  drift 0.08264

f.lux reasserted after roughly two seconds. This is the behaviour the in-app
conflict warning describes, and the numbers above are where the detector's
0.02 threshold comes from.

## Performance

Release build, idle, one display, schedule holding a steady value. Sampled with
`ps -o %cpu=,rss=` every 12 seconds.

| Metric | Result |
|---|---|
| Idle CPU | **0.0 %** on all samples, across two separate runs |
| Cumulative CPU time | **0.14 s over 1 m 4 s wall**, and 0.16 s over 2 m 20 s in an earlier run |
| Resident memory | 77 MB, stable to within 0.2 MB over a minute |
| Bundle size | 3.5 MB |
| Network requests | None. The app opens no sockets. |

Memory is dominated by the AppKit + SwiftUI framework baseline rather than by
anything Daylight allocates; 73 MB is honest, not impressive. Deferring the
menu bar popover's construction until first click accounted for ~6 MB of it.

One measurement was thrown out rather than reported: a suite run that took
541 s instead of the usual 11.6 s. That was contention with a concurrent
release build, not a regression — a clean re-run gave 11.5 s. It is mentioned
because a number measured under contention is not a measurement.

Idle wake behaviour is by construction rather than by measurement: the
scheduler sleeps until the next meaningful change, capped by a 5-minute
heartbeat that exists so a clock change cannot leave the output stale.

## Interface review

The real views were rendered to PNGs with `daylight-render` and inspected in
light and dark themes at 760 pt and at 460 pt wide. This is a build step rather
than a manual chore, which is why it caught as much as it did.

Third pass:

- The **application icon** had square bottom corners: the horizon band was
  drawn as a plain rectangle and never clipped to the rounded tile. It was also
  gradient-inverted — warm at the top, cool at the horizon, the opposite of
  what the app does — and the ground took 61 % of the tile. Redrawn with the
  correct macOS tile geometry, a cool-to-warm sky matching the timeline's own
  scale, and everything clipped to the tile. Checked at 32 px as well as 512.
- The location card showed London's sunrise as **01:20**. That was arithmetically
  right — those are London's solar times on a Mac set to New York, which is what
  the schedule genuinely uses — but presenting them bare is baffling, and it is
  the signature of a real mistake. Daylight now records which zone a place keeps
  and explains the discrepancy instead of leaving it looking like a bug.
- The privacy copy still claimed coordinates were "typed in yourself", which
  stopped being the only path the moment the city picker existed.

Second pass, after the feature work:

- Mode cards came out ragged — different heights in the same row — and showed a
  description without the values the mode would actually apply. Both fixed; a
  mode that hides its own numbers rather undercuts the claim that it is a
  transparent combination of settings.
- The menu bar's four footer buttons did not line up, twice. `Grid` could not
  equalise a `Menu` against `Button`s, and a fixed-width frame leaves a button
  content-sized and centred inside it. Fixed properly with a `WideButton`
  component that expands its label.
- The Settings panel had grown to nine cards and about 3400 pt of scroll. Modes
  moved to their own section, which is also where they belong: they are applied
  constantly, from three different places.
- Lists with nothing in them showed a bare sentence or nothing at all. Every
  list now has a real empty state with a way forward.

First pass:

- The warmth band was invisible in light mode, because a true 6500 K swatch is
  white — the middle of the day looked like missing data. Replaced with a
  cool-to-warm scale that stays legible in both themes.
- Numbers were formatted inconsistently: `Text` interpolation localised
  integers, so the same value read "6,500 K" in the editor and "6500 K"
  everywhere else.
- Helper text people are meant to read was set in the faintest tertiary grey.
- The warmth slider got *cooler* as you dragged right, contradicting its own
  labels.
- The menu bar footer's buttons did not line up.
- The brightness axis labels collided with the lane name at narrow widths, and
  the 100 % line sat on the lane's border.
- Mode descriptions truncated mid-word.

## Accessibility

- Every icon-only control takes its accessibility label as a required argument,
  so one cannot be added without it.
- Timeline anchors are focusable and keyboard-operable: arrows move by five
  minutes, Shift-arrow by an hour, with a visible focus ring and an adjustable
  action for assistive technology. Anchors that follow the sun are not
  focusable, because they cannot be moved.
- The timeline has a full text equivalent listing every anchor, its time, its
  values and its origin — the primary path for a screen reader rather than a
  fallback bolted on.
- Meaning is never carried by colour alone: lanes are named, anchors are
  labelled and positioned, and every status pill has text.
- Reduce Motion is honoured through a single vocabulary of four short
  animations, none of which loop.
- The break reminder never takes focus and never blocks anything.

## The end-to-end self-test

`Daylight --self-test` runs the real engine against the real displays for two
seconds, prints what the engine decided, what each display reports, and what the
hardware actually reads back, then restores and exits.

It exists because "the schedule is right" and "the display layer is right" do
not together prove the two are connected — and the first time it was run it
immediately showed they were not:

    Displays the coordinator is driving: 1
      Built-in Retina Display
        connection    Asleep
        confidence    Requested          <- nothing had been applied

After the fix, with the display still asleep:

    connection    Asleep
    confidence    Confirmed by readback
    applied       3000 K at 85%

    What the hardware actually reads back
      display 1   R 0.8500  G 0.4311  B 0.1321

## Multi-display checklist

Unverified, and the largest outstanding gap. `Daylight --diagnose` prints a
read-only report of what each attached display supports;
`Daylight --watch-displays` keeps running and reports every configuration
change, sleep and wake as it happens.

With a second monitor attached, this is what to confirm:

- [ ] Both displays are listed, each with its own durable key.
- [ ] Warmth changes on both, and each reports "Confirmed by readback".
- [ ] Per-display limits apply independently.
- [ ] Excluding one display leaves it alone while the other keeps following the
      schedule.
- [ ] Linking them shares limits; unlinking does not change what is on screen.
- [ ] Undocking and re-docking rebinds the same durable key — settings must not
      be lost, and the transient display id will have changed.
- [ ] Closing the lid (clamshell) does not confuse the built-in display's state.
- [ ] Mirroring is detected and disclosed.
- [ ] Two identical monitors are reported as ambiguous rather than guessed at.
- [ ] Sleep and wake re-establish baselines without a visible flash.
- [ ] `--diagnose` reports whether DDC brightness answered on the external
      display. If it does, the experimental switch under Settings can be tried.

The current single-display run reports:

    [1] Built-in Retina Display
        durable key    uuid:37D8832A-2D66-02CA-B9F7-8F30A301B230
        colour control yes (1024-entry table)
        HDR capable    yes — transfer-table interaction with HDR content is unverified
        baseline       rejectedForeignTransform
        CONFLICT       another utility appears to be adjusting this display

That conflict line is f.lux, running on the same machine. The baseline
validator refused to adopt its warm table as "neutral" and the detector flagged
it — both behaving as designed, against a real competing application.

## Not verified

Stated as incomplete verification rather than glossed over:

- Multiple physical displays, docking/undocking, clamshell, mirroring,
  reconnection under a new display ID — **only one display was available**.
  These paths are covered against simulated devices only.
- Sleep and wake on real hardware.
- HDR interaction with the transfer table.
- Whether the transform appears in screenshots or screen sharing.
- `SMAppService` launch-at-login registration.
- Intel Macs; macOS versions other than 27.0.
- Visual confirmation by a person that the screen looks correct at each
  setting. Software cannot establish this.
