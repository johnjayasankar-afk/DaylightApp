# Status and roadmap

Five states are used, and they mean different things:

- **Done** — implemented and covered by tests or direct hardware observation.
- **Done (simulated only)** — implemented and tested, but the hardware to
  exercise it was not available.
- **Experimental** — deliberately isolated; not depended on by anything stable.
- **Blocked** — cannot be built as specified; the reason is given.
- **Planned** — not started.

Nothing in the shipping interface is a button that does not work.

## Release 1 — everyday utility

| Item | Status |
|---|---|
| Real display warmth control | **Done** — readback-confirmed on hardware |
| Software dimming | **Done** |
| Hardware brightness | **Blocked** — no public macOS API. See [compatibility](compatibility.md). |
| Background scheduling engine | **Done** |
| Manual and automatic modes | **Done** |
| Daily schedule editing | **Done** — drag, numeric, add/remove/rename, undo |
| Solar schedules | **Done** — local NOAA calculation, no network, no location permission |
| City picker | **Done** — 101 bundled cities, searchable, with a time-zone-derived suggestion |
| Troubleshooting guide | **Done** — in-app, symptom-first, each answer ends in an action |
| Weekday / weekend schedules | **Done** — including custom weekend days |
| Night-shift schedules | **Done** |
| Per-display settings | **Done (simulated only)** for multi-display; single-display verified on hardware |
| Display groups | **Done** — linked displays share limits; names and exclusions stay separate |
| Menu bar control surface | **Done** |
| Temporary overrides with visible expiry | **Done** |
| Safe preview and restoration | **Done** — bounded, with cleanup on cancel, expiry, panel exit and quit |
| Persistent local settings | **Done** — versioned, atomic, validated, with backup recovery |
| Export / import | **Done** — imports treated as untrusted and clamped |
| Sleep / wake handling | **Done (unverified on hardware)** |
| Reconnect handling | **Done (simulated only)** |
| Quit cleanup | **Done** — verified |
| Crash cleanup | **Done** — macOS restores on process exit, verified under `SIGKILL` |
| Onboarding | **Done** |
| Main settings window | **Done** — Today, Schedule, Displays, Rules, Settings |
| Capability and error states | **Done** — three levels of confidence reported per display |
| Conflict detection | **Done** — measured against f.lux |
| Reproducible build | **Done** — one script, no Xcode required |
| Installable app | **Done, ad-hoc signed** — not notarised; see [release](release.md) |

### Everything stored is now wired up

Two settings (`warnOnExtremeSettings`, `respectsReducedMotion`) were being
saved and loaded but read by nothing — controls that looked real and did
nothing. Both now have behaviour behind them, and a shipping build has no
setting that does not.

### The one remaining Release 1 gap

**Multi-display behaviour is unverified on hardware.** Every path exists and is
covered against simulated devices, but only one display was ever attached. This
is the largest gap between what the code claims and what has been observed.

`Daylight --diagnose` and `--watch-displays` exist specifically to close it; see
the checklist in [test-results.md](test-results.md).

## Release 2 — advanced personalisation

| Item | Status |
|---|---|
| Rich timeline editing | **Done** — drag, type, and full keyboard operation |
| Editable modes | **Done** — create, edit and delete; built-ins restorable |
| Editable rules | **Done** — triggers, actions and ordering are all changeable |
| Weekday / weekend schedules | **Done** |
| Night-shift and rotating schedules | **Done** for night shift; rotating (n-days-on/off) **planned** |
| Application-specific rules | **Done** — permission-free, bundle identifier only, nothing written to disk |
| Workspace profiles | **Planned** — deliberately absent from the model and the interface until implemented |
| Keyboard shortcuts | **Done** — three global shortcuts via Carbon, no permissions, conflicts detected and reported |
| Command search / action palette | **Done** — ⇧⌥⌘K, ranked search over every action |
| Break reminders | **Done** — interval, snooze, quiet hours, suppressed by silencing modes |
| Local preference learning | **Planned** — must stay local, explainable, and opt-in |
| Ambient-light adaptation | **Blocked** — checked, not assumed: `AppleLMUController` and `AppleSMCLMU` have no instances on this Apple Silicon Mac, and no public interface exposes the sensor. The webcam will not be used as a substitute. |
| Per-display manual changes | **Done** — a manual change can target one display, a group, or all |
| Settings export / import | **Done** |
| Local history | **Done** — optional, deduplicated, capped, deleted when switched off |

## Release 3 — lighting ecosystem

Nothing here is started. The device seam (`LightingDevice`) and the pacing
policy (`WritePolicy.slowExternalDevice`) exist so that these attach without
disturbing the display engine.

| Item | Status | Note before starting |
|---|---|---|
| Philips Hue | **Planned** | Local bridge API; verify current auth flow and rate limits |
| Home Assistant | **Planned** | Local API and long-lived token, stored in the Keychain — never in exported settings |
| OpenRGB devices | **Planned** | Check licensing and current protocol; most are RGB-only, so warm-white must be labelled an approximation |
| Keyboard lighting | **Planned** | Apple provides no public API for built-in keyboard backlight |
| Monitor bias lighting | **Planned** | Distinguish power / brightness / tunable white / RGB / zones per device |
| DDC/CI external brightness | **Experimental, built, unverified** | Off by default. Packet framing is unit-tested; the hardware path has never been exercised, because no external monitor was available. See [compatibility](compatibility.md). |
| Cross-device sync | **Planned** | Would introduce the first network dependency; the core must stay fully functional without it |
| Advanced diagnostics | **Planned** | |

Room lighting will be strictly opt-in per device, will not turn on sleeping
lights, and will not fight a physical switch.

## Next highest-value work

1. **Attach a second display and run `--watch-displays`.** Everything is
   written and simulated; none of it is proven. Also the only way to find out
   whether the DDC path works at all.
2. **Notarisation**, once a Developer ID certificate is available.
3. **Rotating shift schedules** (n days on, n off), the last scheduling shape
   the engine does not express.
4. **Preference learning** — noticing that evenings are usually adjusted warmer
   and offering to update the schedule. Local statistics only, opt-in, and
   reversible; nothing about this needs a model. The history log already
   records the raw material.
5. **A licence decision.** There is no `LICENSE` file, so default copyright
   applies and the project cannot be shared as it stands. That choice belongs
   to its owner. See [licenses.md](licenses.md).
