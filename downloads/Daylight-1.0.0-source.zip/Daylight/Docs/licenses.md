# Licences and dependencies

## Third-party dependencies

**None.**

`Package.swift` declares no external packages. Daylight links only frameworks
that ship with macOS:

| Framework | Used for | Public API? |
|---|---|---|
| Foundation | Dates, calendars, JSON, file I/O | Yes |
| CoreGraphics | Display enumeration and the colour transfer table | Yes |
| ColorSync | Durable display UUIDs | Yes |
| AppKit | Windows, menu bar, drawing | Yes |
| SwiftUI | The interface | Yes |
| Combine | Publishing state to the interface | Yes |
| IOKit | Power source; DDC transport in the experimental module | Mixed — see below |
| IOKit.ps | Whether the Mac is on battery | Yes |
| Carbon.HIToolbox | System-wide keyboard shortcuts | Yes (long-standing, not deprecated) |
| ServiceManagement | Launch at login | Yes |
| ObjectiveC | Test discovery in the test runner only | Yes |

### The one place private API is used

The experimental DDC/CI module resolves five symbols from IOKit at runtime that
are not in its public headers: `IOAVServiceCreate`,
`IOAVServiceCreateWithService`, `IOAVServiceReadI2C`, `IOAVServiceWriteI2C` and
`IOAVServiceCopyEDID`.

It is off by default, nothing else depends on it, and if the symbols are absent
it reports itself unsupported. See [compatibility.md](compatibility.md).

## Algorithms

Both are implemented from their published descriptions. No code was copied.

- **Solar position** — the NOAA solar calculation, as described in the NOAA
  General Solar Position Calculations documentation.
- **Colour temperature to chromaticity** — the cubic-spline approximation of
  the Planckian locus from Kim, Garcia, Kwak and Choi, *Design of Advanced
  Colour Temperature Control System for HDTV Applications* (2002), valid from
  1667 K to 25000 K.
- **DDC/CI framing** — the VESA Monitor Control Command Set, from its
  specification.

## Independence from f.lux

Daylight was written as an independent implementation. It contains no f.lux
code, branding, assets, or strings, and was not derived from disassembly or
inspection of that application. The overlap is in the problem being solved, not
in the solution.

## Bundled data

The city list in `Sources/DaylightCore/Cities.swift` is 101 hand-entered
entries: name, region, coordinates rounded to four decimal places, and IANA
time zone identifier. These are geographic facts rather than a copyrighted
compilation, and no database was copied. Every entry is checked by tests —
coordinates against their time zone, and sunset times at an equinox.

## Daylight's own licence

**Not yet chosen.** There is no `LICENSE` file, which means default copyright
applies and nobody has permission to redistribute it.

That is a decision for the owner of the project rather than something to be
picked by default. If it is to be shared, add a `LICENSE` file — MIT and
Apache-2.0 are the usual permissive choices, GPL-3.0 the usual copyleft one —
and note it in the README.
