# Compatibility

## Verification vocabulary

Daylight distinguishes four different claims, and this document uses them
strictly:

| Level | Means |
|---|---|
| **Requested** | Daylight computed a value and asked for it. |
| **Accepted** | The system returned success. Nothing more. |
| **Readback-confirmed** | The setting was read back afterwards and matched. |
| **Visually confirmed** | A person looked at the screen and saw it change. |

The app itself reports the first three per display, in the Displays view. The
fourth cannot be established by software and is never claimed by it.

## Reference machine

Everything below marked "verified" was verified on:

| | |
|---|---|
| Machine | MacBook Pro, Apple M1 Max |
| macOS | 27.0 (build 26A5425a) |
| Display | Built-in Retina, 1800 × 1169 pt, HDR-capable (max potential EDR 16.0) |
| Toolchain | Swift 6.4, Command Line Tools (no Xcode) |
| Notable | f.lux was installed and running during development |

## Feature support

| Capability | API | Status on the reference machine |
|---|---|---|
| Display enumeration | `CGGetOnlineDisplayList` | **Verified** |
| Durable identity | `CGDisplayCreateUUIDFromDisplayID` | **Verified** — returned a stable UUID |
| Friendly name | `NSScreen.localizedName` | **Verified** — "Built-in Retina Display" |
| Warmth control | `CGSetDisplayTransferByTable` | **Readback-confirmed**, deviation 0.00000 |
| Software dimming | same transfer table | **Readback-confirmed** |
| Restore one display | write stored baseline | **Verified** |
| Restore all | `CGDisplayRestoreColorSyncSettings` | **Verified** |
| Cleanup after crash | macOS process-exit behaviour | **Verified**, including under `SIGKILL` |
| Hotplug notification | `CGDisplayRegisterReconfigurationCallback` | Implemented, **not verified** (single display) |
| Sleep / wake | `NSWorkspace` notifications | Implemented, **not verified** on hardware |
| Global shortcuts | Carbon `RegisterEventHotKey` | **Verified** — registers with no permissions |
| Launch at login | `SMAppService` | Implemented, **not verified** |
| Hardware brightness (built-in) | — | **Not supported.** See below. |
| Hardware brightness (external, DDC) | private `IOAVService*` | **Symbols present; path unverified.** No external monitor was available. |
| Workspace detection | display identity | **Verified** for the single-display case |

## DDC/CI: the one experimental path

All five private symbols Daylight would use (`IOAVServiceCreateWithService`,
`IOAVServiceReadI2C`, `IOAVServiceWriteI2C`, `IOAVServiceCopyEDID`,
`IOAVServiceCreate`) resolve on this machine, and the IORegistry contains one
`DCPAVServiceProxy` node. That is the whole of what could be verified: with no
external monitor attached, **no DDC exchange has ever taken place**.

What *is* tested is the part that does not need hardware: the DDC/CI message
framing and reply parsing are covered by unit tests against byte sequences from
the VESA MCCS specification, including checksum validation and every malformed
reply the parser must reject.

The module is built to fail closed:

- It is **off by default**, behind a switch labelled experimental.
- It never touches a built-in display.
- It matches a display to its AV service by **EDID**; where that is not
  possible it only proceeds when there is exactly one external display and
  exactly one external service. Pairing several monitors by index would be a
  guess, and a wrong guess sends brightness commands to the wrong screen.
- It claims support only after a display **answers** a capability query. A
  write that returns success proves nothing; plenty of displays absorb I²C
  traffic and ignore it.
- If anything fails, Daylight uses software dimming and says so.

If a future macOS removes these symbols, this module stops working and nothing
else changes.

## Hardware brightness: why it is absent

There is no public macOS API that lets an application set a display's
backlight level.

The methods other utilities use are:

- **Built-in displays** — the private `DisplayServices.framework`, or
  `CoreDisplay_Display_SetUserBrightness`. Both are private. Daylight does not
  use either, and a built-in display's backlight is therefore never touched.
- **External displays** — DDC/CI over I²C, described above. Also private, and
  support varies by monitor, cable and dock.

By default Daylight therefore reports `supportsHardwareBrightness: false`
everywhere and offers software dimming instead, labelled as software dimming in
the interface, in the data model, and in this document.

## Ambient light sensor: checked, and absent

Ambient adaptation is listed as blocked rather than planned because the sensor
was looked for rather than assumed. On this machine:

    AppleLMUController                         0
    AppleSMCLMU                                0
    IOAppleSensorInterface                     0
    AppleALSInterface                          0

`AppleLMUController` — the service every ambient-light implementation has used
historically — has no instances on Apple Silicon, and nothing public replaces
it. Daylight therefore offers no ambient adaptation at all rather than a
feature that silently never fires.

It will not use the webcam as a substitute light meter.

## Sleeping displays

A display that is asleep is still online and still has a transfer table, so
Daylight writes to it. That means the correct value is already in place the
instant the screen comes back, instead of it briefly showing whatever was set
before. Only a genuinely *disconnected* display is skipped.

This was verified directly: with the built-in display asleep, the app applied
3000 K at 85 % and the table read back R 0.8500 / G 0.4311 / B 0.1321 — exactly
the computed value, readback-confirmed.

## Interaction with other software

| Software | Behaviour |
|---|---|
| **f.lux** | Direct conflict — both write the same gamma table. Measured during development: f.lux reasserted its own table roughly 2 seconds after Daylight wrote. Daylight detects this and says so; it does not attempt to win, and does not disable f.lux. Run one or the other. |
| **Night Shift** | Same class of conflict. Turn one off. |
| **True Tone** | Operates separately; not overwritten by Daylight, and not controllable by it. |
| **Automatic brightness** | Untouched. Daylight never changes the backlight. |
| **Colour profiles / calibration** | Never modified. Daylight writes only the transfer table and always restores the profile's own values. |
| **Other gamma utilities** (Lunar, Vivid, Gammy…) | Same conflict; detected the same way. |

The conflict detector compares readback against what was last written and flags
a difference over 0.02. It is not a guess — it is evidence that another process
wrote to the table.

## Known limitations, stated plainly

- **HDR.** The built-in display reports a maximum potential EDR of 16.0. How
  the transfer table interacts with HDR content on screen has **not** been
  verified, and the Displays view says so on any HDR-capable display.
- **Screenshots and screen sharing.** Whether a gamma transform appears in a
  screen capture was **not** established: `screencapture` produced no file on
  the reference machine because Screen Recording permission was not granted.
  Daylight makes no claim either way. (This is also why no screenshot is used
  anywhere as evidence that a display transform worked.)
- **Multiple displays.** All the code paths exist — per-display identity,
  ambiguity handling, mirroring, exclusion, rebinding on reconnect — and are
  covered by tests against simulated devices. None have been exercised against
  a second physical monitor, because only one was attached.
- **DisplayLink and other indirect displays.** Untested. They may not expose a
  usable transfer table; Daylight will report colour control as unsupported if
  the capacity comes back zero.
- **Intel Macs.** The APIs used are architecture-independent, but nothing was
  run on Intel.
- **Mirrored displays.** Detected and disclosed in the interface. Not verified
  against real mirrored hardware.

## Reproducing the hardware checks

The probe used during development is not shipped, but the essential check is
three lines:

```bash
# 1. read the table   2. run Daylight   3. read again   4. quit   5. read again
```

`Docs/test-results.md` records the exact values observed at each step.
