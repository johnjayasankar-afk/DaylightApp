# Architecture

## The one-sentence version

Inputs become a *desired* state through pure, testable logic; a single
coordinator turns that into *applied* state through device adapters; the
interface only ever expresses intent.

```
schedule ─┐
rules ────┼─► precedence resolver ─► desired target
override ─┤        (per control)          │
pause ────┘                               ▼
                              per-display capability + limits
                                          │
                                          ▼
                              transition engine (monotonic)
                                          │
                                          ▼
                              write policy (suppress / rate-limit)
                                          │
                                          ▼
                        device adapter ─► reported result + readback
```

## Modules

| Module | Depends on | Contains |
|---|---|---|
| `DaylightCore` | Foundation only | Colour science, solar calculation, schedule engine, precedence and rules, transition engine, settings and store, device protocol, simulated device |
| `DaylightDisplay` | Core, AppKit, CoreGraphics | The CoreGraphics adapter, display manager, and the coordinator |
| `DaylightUI` | Core, Display, SwiftUI | Every view, behind a small facade |
| `DaylightApp` | Core, Display, UI | Lifecycle, menu bar, windows, diagnostics |
| `DaylightTests` | Core, Display | The test suite and its runner |
| `DaylightRender` | Core, Display, SwiftUI | Renders the real views to PNGs for design review |

`DaylightCore` has no platform display dependencies at all. That is what makes
the entire scheduling story testable without a screen, and it is the seam a
future Windows or Linux port would build against: only `DaylightDisplay` would
be replaced.

## Key decisions

### Wall clock for schedules, monotonic time for transitions

A schedule anchor at 19:00 means 19:00 on the clock — it must not drift an hour
when daylight saving changes. So the timeline resolves anchors into wall-clock
seconds from local midnight, and evaluation reads the clock's *fields* rather
than subtracting dates.

Transitions are the opposite. A fade must not leap or stall because the clock
was corrected or a time zone changed, so `TransitionEngine` is driven purely by
`CLOCK_MONOTONIC_RAW`.

This split is the single most load-bearing decision in the codebase, and it was
put there by a failing test: evaluating in elapsed time put the whole schedule
an hour out on a 23-hour day.

### Interpolation in mired, not kelvin

2000 K → 3000 K is a large visible change; 8000 K → 9000 K is nearly invisible.
Interpolating linearly in kelvin therefore produces a fade that races through
the part people can see and crawls through the part they cannot. Everything
interpolates in mired (10⁶/K) instead.

### The tick rate comes from the data, not from a frame rate

`TickPlanner.interval` divides the size of the change by a perceptual step
(1 mired) and spreads the writes over the transition's duration. A 90-minute
schedule ramp therefore needs a write roughly once a minute; a 6-second manual
fade needs about 14 a second. There is no animation loop, and an idle app wakes
on a 5-minute heartbeat that exists only so a clock change cannot leave the
output stale.

### Per-control precedence

Layers are a small closed enum, highest wins, and resolution happens
*separately for warmth and for dimming*. A rule that dims on battery therefore
does not silently discard the schedule's warmth. Each control records which
layer supplied it, which is what makes the plain-language explanation
("Your display is neutral because Colour Work is active for this app") a
statement of fact rather than a guess.

### Baselines are captured, validated, and refused

Applying a transform relative to "whatever is on the display right now" is how
an app slowly bakes another utility's tint into its own idea of neutral. So
`CoreGraphicsDisplayDevice.prepare()`:

1. reads the current table,
2. calls `CGDisplayRestoreColorSyncSettings()` and reads again,
3. **validates** the result — a plausible baseline has its three channels
   within 0.12 of each other at full scale and is monotonic,
4. falls back to a plain ramp and records `rejectedForeignTransform` if not.

The rejection threshold is not theoretical. On the machine this was built on,
f.lux was running, and the table read back as R 1.00 / G 0.36 / B 0.10. There is
a test pinned to exactly those numbers.

Every apply is then computed from the stored baseline, never from the current
table, so repeated application cannot accumulate.

### Durable display identity

Settings are keyed on `uuid:<CGDisplayCreateUUIDFromDisplayID>` where available,
falling back to `edid:<vendor>-<model>-<serial>`. Never an index — indices are
reassigned on dock, undock and wake, and keying on one is how a saved 2400 K
night profile ends up on a colleague's projector.

Two identical monitors with no serial genuinely cannot be distinguished. Rather
than inventing an unstable index, Daylight keeps the shared key, marks the
identity ambiguous, and says so in the interface.

### Ownership and cleanup

A CoreGraphics gamma table belongs to the process that set it, and macOS
restores the previous state when that process exits — verified here including
under `SIGKILL`. Crash cleanup is therefore the system's job, and Daylight
deliberately installs **no** watchdog or helper to duplicate it; a second
controller would be a second thing to go wrong.

What Daylight adds on top is deliberate restoration on quit, pause, restore and
preview cancellation, done **per display** by writing that display's baseline
back rather than by calling the global reset — so one failing device never
resets the others.

### The interface never writes to hardware

Views call intents on the coordinator (`pauseAutomation(for:)`,
`applyProfile(_:expiry:)`). The coordinator owns the only path to a device.
Slider drags go through a `Debouncer` so a fast sweep coalesces into a handful
of writes instead of hundreds.

### The views are a library, not part of the executable

`DaylightUI` exposes three entry points — `mainWindow`, `menuBar`, `onboarding`
— plus a `Review` namespace used only for rendering the interface to images.
Everything else in it is internal.

Views never reference `AppDelegate`; they talk to an `AppCommands` protocol it
conforms to. That is what lets the renderer build the real interface with no
application object at all, which in turn is what makes reviewing the interface
in both themes a build step rather than a manual chore.

### Motion is a closed vocabulary

Four named animations (`settle`, `reveal`, `move`, `drift`), all short, none
looping. Each returns `nil` when motion should be reduced, so one check covers
both the system setting and the app's own switch, and no call site has to
remember to ask.

### Empty states are components, not afterthoughts

`EmptyStateView`, `Pill`, `IconButton` and `WideButton` exist so that a pill in
Rules is the same object as a pill in Today, and so an icon-only button cannot
be built without an accessibility label — it is a required argument.

`WideButton` in particular exists because a plain `Button` inside a fixed-width
frame stays content-sized and sits centred, which is why rows of buttons come
out ragged. Expanding the *label* is what widens the control; doing that once
in a component is more reliable than remembering it four times.

## Environment constraints worth knowing

**No Xcode on the build machine.** Two consequences, both worked around rather
than papered over:

- *XCTest and swift-testing are unavailable* — they ship with Xcode, not with
  Command Line Tools. The suite runs as an executable with a small runner
  (`Sources/DaylightTests/TestRunner.swift`) that reimplements the slice of the
  XCTest API the tests use, and discovers test methods through the ObjC runtime
  the same way XCTest does. Test files are written in XCTest's own shape, so
  migrating is a matter of changing `DaylightTestCase` to `XCTestCase`.

- *`@State` is unavailable* — in the macOS 27 SDK it is a macro whose plugin
  (`SwiftUIMacros`) ships only with Xcode. Every other SwiftUI property wrapper
  works. View-local state therefore lives in small `ObservableObject` types held
  with `@StateObject` (see `ViewState.swift`), which for an app this size is
  arguably the better structure anyway.

## Where a future port would attach

`LightingDevice` is the whole seam. A Windows implementation would provide a
`LightingDevice` over the platform's gamma path and a manager that enumerates
monitors; `DaylightCore` would be reused unchanged. Nothing above the adapter
knows what a gamma table is — the protocol speaks in `ResolvedTarget` and
`AppliedResult` — so external lights would attach at the same seam, with
`WritePolicy.slowExternalDevice` already in place for their pacing.
