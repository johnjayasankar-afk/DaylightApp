import SwiftUI
import DaylightCore
import DaylightDisplay

/// Editing state for the timeline, including undo. Kept separate from the view
/// so the drag maths stays testable by inspection and the view stays declarative.
final class TimelineModel: ObservableObject {
    @Published var hoverSeconds: Double?
    @Published var draggingAnchorID: UUID?
    @Published var previewSeconds: Double?
    @Published var selectedAnchorID: UUID?
    private var undoStack: [Schedule] = []

    var canUndo: Bool { !undoStack.isEmpty }

    func snapshot(_ schedule: Schedule) {
        undoStack.append(schedule)
        if undoStack.count > 40 { undoStack.removeFirst() }
    }
    func undo() -> Schedule? {
        guard !undoStack.isEmpty else { return nil }
        return undoStack.removeLast()
    }
    func clearUndo() { undoStack.removeAll() }
}

/// The 24-hour view of a day.
///
/// Two stacked lanes — warmth and brightness — because they are different
/// quantities and stacking them keeps either one readable on its own. Meaning
/// is never carried by colour alone: every anchor has a label and a position,
/// and the whole thing has a text equivalent underneath.
struct DayTimelineView: View {
    let timeline: Timeline
    let now: Date
    var editable: Bool = false
    var onDrag: ((UUID, Double) -> Void)?
    var onDragEnd: (() -> Void)?
    @ObservedObject var model: TimelineModel

    private let warmthLaneHeight: CGFloat = 96
    private let brightnessLaneHeight: CGFloat = 62
    private let laneGap: CGFloat = 10
    private let topPadding: CGFloat = 24

    private var totalHeight: CGFloat {
        topPadding + warmthLaneHeight + laneGap + brightnessLaneHeight + 20
    }

    var body: some View {
        GeometryReader { geo in
            let w = geo.size.width
            ZStack(alignment: .topLeading) {
                canvas(width: w)
                if editable { anchorHandles(width: w) }
                readout(width: w)
            }
            .contentShape(Rectangle())
            .onContinuousHover { phase in
                switch phase {
                case .active(let p): model.hoverSeconds = seconds(forX: p.x, width: w)
                case .ended: model.hoverSeconds = nil
                }
            }
        }
        .frame(height: totalHeight)
        .accessibilityElement(children: .contain)
        .accessibilityLabel("Daily lighting timeline")
    }

    // MARK: Geometry

    private func x(forSeconds s: Double, width: CGFloat) -> CGFloat {
        CGFloat(min(max(s, 0), 86_400) / 86_400) * width
    }
    private func seconds(forX x: CGFloat, width: CGFloat) -> Double {
        Double(min(max(x, 0), width) / max(width, 1)) * 86_400
    }

    private var warmthTop: CGFloat { topPadding }
    private var warmthBottom: CGFloat { topPadding + warmthLaneHeight }
    private var brightTop: CGFloat { warmthBottom + laneGap }
    private var brightBottom: CGFloat { brightTop + brightnessLaneHeight }

    private func warmthY(_ t: ColourTemperature) -> CGFloat {
        // Plotted in mired so the curve's shape matches how the change looks.
        let lo = ColourTemperature.neutral.mired
        let hi = ColourTemperature(kelvin: ColourTemperature.advancedRange.lowerBound).mired
        let f = (t.mired - lo) / (hi - lo)
        return warmthTop + CGFloat(min(max(f, 0), 1)) * warmthLaneHeight
    }
    /// Inset top and bottom so a value at either extreme sits inside the lane
    /// rather than merging with its border.
    private func brightY(_ d: SoftwareDimming) -> CGFloat {
        let usable = brightnessLaneHeight - 16
        return brightBottom - 8 - CGFloat(min(max(d.factor, 0), 1)) * usable
    }
    private func brightGridY(_ fraction: Double) -> CGFloat {
        let usable = brightnessLaneHeight - 16
        return brightBottom - 8 - CGFloat(fraction) * usable
    }

    // MARK: Canvas

    private func canvas(width w: CGFloat) -> some View {
        Canvas { ctx, size in
            let samples = timeline.sample(stepSeconds: 240)
            guard samples.count > 1 else { return }

            // Warmth lane: a band whose fill follows the day's colour, with a
            // solid line on top so the shape reads without relying on colour.
            for i in 0..<(samples.count - 1) {
                let x0 = x(forSeconds: samples[i].seconds, width: w)
                let x1 = x(forSeconds: samples[i + 1].seconds, width: w)
                let y0 = warmthY(samples[i].target.temperature)
                let y1 = warmthY(samples[i + 1].target.temperature)
                var p = Path()
                p.move(to: CGPoint(x: x0, y: y0))
                p.addLine(to: CGPoint(x: x1, y: y1))
                p.addLine(to: CGPoint(x: x1, y: warmthBottom))
                p.addLine(to: CGPoint(x: x0, y: warmthBottom))
                p.closeSubpath()
                ctx.fill(p, with: .color(Palette.swatch(for: samples[i].target.temperature).opacity(0.55)))
            }
            var warmLine = Path()
            warmLine.move(to: CGPoint(x: x(forSeconds: samples[0].seconds, width: w),
                                      y: warmthY(samples[0].target.temperature)))
            for s in samples.dropFirst() {
                warmLine.addLine(to: CGPoint(x: x(forSeconds: s.seconds, width: w),
                                             y: warmthY(s.target.temperature)))
            }
            ctx.stroke(warmLine, with: .color(Palette.primaryText.opacity(0.55)), lineWidth: 1.5)

            // Brightness lane: a plain line, deliberately unlike the warmth band.
            var brightLine = Path()
            brightLine.move(to: CGPoint(x: x(forSeconds: samples[0].seconds, width: w),
                                        y: brightY(samples[0].target.dimming)))
            for s in samples.dropFirst() {
                brightLine.addLine(to: CGPoint(x: x(forSeconds: s.seconds, width: w),
                                               y: brightY(s.target.dimming)))
            }
            ctx.stroke(brightLine, with: .color(Palette.primaryText.opacity(0.5)),
                       style: StrokeStyle(lineWidth: 1.5, lineJoin: .round))

            // Brightness reference lines, so a nearly-flat curve still tells
            // you *where* it is rather than just that it is flat.
            for (fraction, label) in [(1.0, "100%"), (0.5, "50%")] {
                let gy = brightGridY(fraction)
                var g = Path()
                g.move(to: CGPoint(x: 6, y: gy))
                g.addLine(to: CGPoint(x: w - 34, y: gy))
                ctx.stroke(g, with: .color(Palette.hairline.opacity(0.7)),
                           style: StrokeStyle(lineWidth: 1, dash: [2, 4]))
                // Kept on the right, clear of the lane name on the left.
                ctx.draw(Text(label).font(.system(size: 8)).foregroundStyle(Palette.tertiaryText),
                         at: CGPoint(x: w - 16, y: gy))
            }

            // Lane frames.
            for rect in [CGRect(x: 0, y: warmthTop, width: w, height: warmthLaneHeight),
                         CGRect(x: 0, y: brightTop, width: w, height: brightnessLaneHeight)] {
                ctx.stroke(Path(roundedRect: rect, cornerRadius: 6),
                           with: .color(Palette.hairline), lineWidth: 1)
            }

            // Lane names, so neither curve depends on colour to be identified.
            ctx.draw(Text("Warmth").font(.system(size: 9, weight: .medium))
                        .foregroundStyle(Palette.secondaryText),
                     at: CGPoint(x: 30, y: warmthTop + 9))
            ctx.draw(Text("Brightness").font(.system(size: 9, weight: .medium))
                        .foregroundStyle(Palette.secondaryText),
                     at: CGPoint(x: 38, y: brightTop + 9))

            // Hour ticks every three hours; labelled every six.
            for hour in stride(from: 0, through: 24, by: 3) {
                let hx = x(forSeconds: Double(hour) * 3600, width: w)
                var tick = Path()
                tick.move(to: CGPoint(x: hx, y: brightBottom))
                tick.addLine(to: CGPoint(x: hx, y: brightBottom + 4))
                ctx.stroke(tick, with: .color(Palette.hairline), lineWidth: 1)
                if hour % 6 == 0 && hour < 24 {
                    ctx.draw(Text(hourLabel(hour)).font(.system(size: 9))
                                .foregroundStyle(Palette.tertiaryText),
                             at: CGPoint(x: hx + 14, y: brightBottom + 11))
                }
            }

            // Transition regions: the ramps, shaded so they are visible as
            // periods rather than instants.
            for anchor in timeline.todayAnchors where anchor.anchor.transitionMinutes > 0 {
                let end = anchor.seconds
                let start = end - anchor.anchor.transitionMinutes * 60
                let rect = CGRect(x: x(forSeconds: start, width: w), y: warmthTop,
                                  width: x(forSeconds: end, width: w) - x(forSeconds: start, width: w),
                                  height: warmthLaneHeight)
                ctx.fill(Path(rect), with: .color(Palette.primaryText.opacity(0.045)))
            }

            // Anchor rules.
            for anchor in timeline.todayAnchors {
                let ax = x(forSeconds: anchor.seconds, width: w)
                var line = Path()
                line.move(to: CGPoint(x: ax, y: warmthTop))
                line.addLine(to: CGPoint(x: ax, y: brightBottom))
                ctx.stroke(line, with: .color(Palette.primaryText.opacity(0.22)),
                           style: StrokeStyle(lineWidth: 1, dash: [3, 3]))
            }

            // The current moment.
            let nowX = x(forSeconds: Timeline.wallClockSeconds(of: now, in: timeline.timeZone), width: w)
            var nowLine = Path()
            nowLine.move(to: CGPoint(x: nowX, y: warmthTop - 6))
            nowLine.addLine(to: CGPoint(x: nowX, y: brightBottom))
            ctx.stroke(nowLine, with: .color(Palette.accent), lineWidth: 2)
            ctx.fill(Path(ellipseIn: CGRect(x: nowX - 3.5, y: warmthTop - 10, width: 7, height: 7)),
                     with: .color(Palette.accent))

            // A previewed time of day, when someone is scrubbing.
            if let p = model.previewSeconds ?? model.hoverSeconds {
                let px = x(forSeconds: p, width: w)
                var l = Path()
                l.move(to: CGPoint(x: px, y: warmthTop))
                l.addLine(to: CGPoint(x: px, y: brightBottom))
                ctx.stroke(l, with: .color(Palette.primaryText.opacity(0.45)), lineWidth: 1)
            }
        }
        .frame(height: totalHeight)
        .accessibilityHidden(true)
    }

    private func hourLabel(_ hour: Int) -> String {
        switch hour {
        case 0: return "12 AM"
        case 12: return "12 PM"
        case let h where h < 12: return "\(h) AM"
        default: return "\(hour - 12) PM"
        }
    }

    // MARK: Draggable handles

    private func anchorHandles(width w: CGFloat) -> some View {
        ForEach(timeline.todayAnchors) { resolved in
            AnchorHandle(
                resolved: resolved,
                x: x(forSeconds: resolved.seconds, width: w),
                isSelected: model.selectedAnchorID == resolved.id,
                help: handleHelp(resolved),
                onSelect: { model.selectedAnchorID = resolved.id },
                onDragTo: { location in
                    model.draggingAnchorID = resolved.id
                    model.selectedAnchorID = resolved.id
                    onDrag?(resolved.id, seconds(forX: location, width: w))
                },
                onDragEnd: {
                    model.draggingAnchorID = nil
                    onDragEnd?()
                },
                onNudge: { minutes in
                    guard !resolved.anchor.time.isSolar else { return }
                    model.selectedAnchorID = resolved.id
                    let moved = resolved.seconds + Double(minutes) * 60
                    onDrag?(resolved.id, min(max(moved, 0), 86_340))
                    onDragEnd?()
                })
        }
    }

    /// Snapping while dragging. Five minutes is fine enough to place an anchor
    /// where you meant to and coarse enough that it lands on a round number.
    static let dragSnapSeconds: Double = 300

    private func handleHelp(_ r: ResolvedAnchor) -> String {
        if r.anchor.time.isSolar {
            return "\(r.anchor.name) follows the sun (\(clockString(r.seconds)) today). Edit it in the anchor list."
        }
        return "\(r.anchor.name) at \(clockString(r.seconds)). Drag to move, or edit the time in the list below."
    }

    // MARK: Hover readout

    @ViewBuilder
    private func readout(width w: CGFloat) -> some View {
        if let s = model.hoverSeconds {
            let ev = timeline.evaluateAtWallClock(seconds: s)
            let boxWidth: CGFloat = 168
            VStack(alignment: .leading, spacing: 2) {
                Text(clockString(s)).font(.system(size: 11, weight: .semibold)).monospacedDigit()
                Text("\(Format.kelvin(ev.target.temperature)) · \(Format.percent(ev.target.dimming.factor)) brightness")
                    .font(.system(size: 10)).foregroundStyle(Palette.secondaryText)
                Text(ev.currentAnchorName).font(.system(size: 10)).foregroundStyle(Palette.tertiaryText)
            }
            .padding(7)
            .frame(width: boxWidth, alignment: .leading)
            .background(RoundedRectangle(cornerRadius: 7, style: .continuous).fill(Palette.raised))
            .overlay(RoundedRectangle(cornerRadius: 7, style: .continuous)
                .strokeBorder(Palette.hairline, lineWidth: 1))
            .shadow(color: .black.opacity(0.10), radius: 6, y: 2)
            .position(x: min(max(x(forSeconds: s, width: w), boxWidth / 2 + 4), w - boxWidth / 2 - 4),
                      y: totalHeight - 6)
            .allowsHitTesting(false)
        }
    }
}

/// The timeline's text equivalent. Not a fallback bolted on afterwards — it is
/// the same information, and for a screen reader it is the primary path.
struct TimelineTextSummary: View {
    let timeline: Timeline
    let now: Date

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            ForEach(timeline.todayAnchors) { r in
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text(clockString(r.seconds))
                        .font(.system(size: 11, design: .rounded)).monospacedDigit()
                        .foregroundStyle(Palette.secondaryText)
                        .frame(width: 46, alignment: .leading)
                    Text(r.anchor.name).font(.daylightCaption)
                    Spacer(minLength: 8)
                    Text("\(Format.kelvin(r.anchor.temperature)) · \(Format.percent(r.anchor.dimming.factor))")
                        .font(.system(size: 11, design: .rounded)).monospacedDigit()
                        .foregroundStyle(Palette.secondaryText)
                    if r.anchor.transitionMinutes > 0 {
                        Text("over \(Int(r.anchor.transitionMinutes))m")
                            .font(.system(size: 10)).foregroundStyle(Palette.tertiaryText)
                    }
                }
                .accessibilityElement(children: .combine)
                .accessibilityLabel(sentence(for: r))
            }
        }
    }

    private func sentence(for r: ResolvedAnchor) -> String {
        var s = "\(r.anchor.name) at \(clockString(r.seconds)), about \(Format.kelvin(r.anchor.temperature)), brightness \(Format.percent(r.anchor.dimming.factor))"
        if r.anchor.transitionMinutes > 0 {
            s += ", reached gradually over \(Int(r.anchor.transitionMinutes)) minutes"
        }
        switch r.origin {
        case .solar(let e): s += ", following \(e.friendlyName)"
        case .solarClamped(let e, let side):
            s += ", following \(e.friendlyName) but held to its \(side == .earliest ? "earliest" : "latest") allowed time"
        case .solarFallback(let e, _): s += ", using a fallback time because \(e.friendlyName) is unavailable"
        case .clock: break
        }
        return s
    }
}


/// A small, non-interactive strip of the warmth curve.
///
/// Used where the full timeline would be too much — the welcome screen — so a
/// glance still shows the shape of the day rather than an empty panel.
struct TimelineStrip: View {
    let timeline: Timeline
    var height: CGFloat = 54

    var body: some View {
        Canvas { ctx, size in
            let samples = timeline.sample(stepSeconds: 300)
            guard samples.count > 1 else { return }
            let w = size.width
            func x(_ s: Double) -> CGFloat { CGFloat(s / 86_400) * w }
            func y(_ t: ColourTemperature) -> CGFloat {
                let lo = ColourTemperature.neutral.mired
                let hi = ColourTemperature(kelvin: ColourTemperature.advancedRange.lowerBound).mired
                return CGFloat(min(max((t.mired - lo) / (hi - lo), 0), 1)) * (size.height - 8) + 4
            }
            for i in 0..<(samples.count - 1) {
                var p = Path()
                p.move(to: CGPoint(x: x(samples[i].seconds), y: y(samples[i].target.temperature)))
                p.addLine(to: CGPoint(x: x(samples[i + 1].seconds), y: y(samples[i + 1].target.temperature)))
                p.addLine(to: CGPoint(x: x(samples[i + 1].seconds), y: size.height))
                p.addLine(to: CGPoint(x: x(samples[i].seconds), y: size.height))
                p.closeSubpath()
                ctx.fill(p, with: .color(Palette.swatch(for: samples[i].target.temperature).opacity(0.65)))
            }
            var line = Path()
            line.move(to: CGPoint(x: 0, y: y(samples[0].target.temperature)))
            for s in samples.dropFirst() {
                line.addLine(to: CGPoint(x: x(s.seconds), y: y(s.target.temperature)))
            }
            ctx.stroke(line, with: .color(Palette.primaryText.opacity(0.45)), lineWidth: 1.2)
        }
        .frame(height: height)
        .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 8, style: .continuous)
            .strokeBorder(Palette.hairline, lineWidth: 1))
        .accessibilityHidden(true)
    }
}


/// One anchor handle on the timeline.
///
/// Draggable with the mouse and movable with the keyboard: arrow keys nudge by
/// five minutes, shift-arrow by an hour. An anchor that follows the sun is
/// shown faded and refuses to move, because its time comes from the sky rather
/// than from you.
struct AnchorHandle: View {
    let resolved: ResolvedAnchor
    let x: CGFloat
    let isSelected: Bool
    let help: String
    let onSelect: () -> Void
    let onDragTo: (CGFloat) -> Void
    let onDragEnd: () -> Void
    let onNudge: (Int) -> Void

    @FocusState private var isFocused: Bool

    private var isSolar: Bool { resolved.anchor.time.isSolar }

    // Split into small pieces deliberately: as one chain this is long enough
    // that the type-checker gives up on it.
    private var marker: some View {
        RoundedRectangle(cornerRadius: 3, style: .continuous)
            .fill(isSelected ? Palette.accent : Palette.primaryText.opacity(0.6))
            .frame(width: 8, height: 14)
            .overlay(RoundedRectangle(cornerRadius: 3, style: .continuous)
                .strokeBorder(Palette.raised, lineWidth: 1))
    }

    /// A visible focus ring: a handle reachable by keyboard but invisible when
    /// focused is not actually reachable.
    private var focusRing: some View {
        RoundedRectangle(cornerRadius: 5, style: .continuous)
            .strokeBorder(Palette.accent, lineWidth: isFocused ? 2 : 0)
            .padding(-3)
    }

    private var drag: some Gesture {
        DragGesture(minimumDistance: 1)
            .onChanged { g in
                guard !isSolar else { return }
                onDragTo(g.location.x)
            }
            .onEnded { _ in onDragEnd() }
    }

    private var interactive: some View {
        marker
            .overlay(focusRing)
            .contentShape(Rectangle().inset(by: -6))
            .opacity(isSolar ? 0.5 : 1)
            .help(help)
            .focusable(!isSolar)
            .focused($isFocused)
            // The keys: overload is the one that reports modifiers, which is
            // how Shift gets to mean "an hour" rather than "five minutes".
            .onKeyPress(keys: [.leftArrow, .rightArrow]) { press in
                keyNudge(press, backwards: press.key == .leftArrow)
            }
            .gesture(drag)
            .onTapGesture(perform: onSelect)
    }

    private var hint: String {
        isSolar
            ? "Follows the sun. Edit its offset in the anchor list below."
            : "Left and right arrows move this by five minutes. Hold Shift for an hour."
    }

    var body: some View {
        interactive
            .accessibilityElement()
            .accessibilityLabel(resolved.anchor.name)
            .accessibilityValue(accessibilityValue)
            .accessibilityHint(hint)
            .accessibilityAddTraits(isSelected ? [.isSelected] : [])
            .accessibilityAdjustableAction { onNudge($0 == .increment ? 5 : -5) }
            .position(x: x, y: 10)
    }

    private func keyNudge(_ press: KeyPress, backwards: Bool) -> KeyPress.Result {
        let magnitude = press.modifiers.contains(.shift) ? 60 : 5
        onNudge(backwards ? -magnitude : magnitude)
        return .handled
    }

    private var accessibilityValue: String {
        let time = clockString(resolved.seconds)
        let warmth = Format.kelvin(resolved.anchor.temperature)
        let brightness = Format.percent(resolved.anchor.dimming.factor)
        return "\(time), about \(warmth), brightness \(brightness)"
    }
}

/// Scrub to any time of day and see what the schedule would be doing.
///
/// Explicitly a preview of the *schedule*, not of the display: nothing is
/// written to hardware, and the control says so. Keyboard-operable because it
/// is an ordinary slider.
struct TimeScrubber: View {
    @ObservedObject var model: TimelineModel
    let timeline: Timeline
    let now: Date
    let animation: Animation?

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 10) {
                Text("Preview a time").font(.daylightCaption)
                    .foregroundStyle(Palette.secondaryText)
                Slider(value: Binding(
                    get: { model.previewSeconds ?? Timeline.wallClockSeconds(of: now, in: timeline.timeZone) },
                    set: { model.previewSeconds = ($0 / 300).rounded() * 300 }),
                       in: 0...86_340)
                    .controlSize(.small)
                    .accessibilityLabel("Preview a time of day")
                    .accessibilityValue(readout)
                if model.previewSeconds != nil {
                    Button("Now") {
                        withAnimation(animation) { model.previewSeconds = nil }
                    }
                    .controlSize(.small)
                }
            }
            HStack(spacing: 8) {
                Text(verbatim: readout)
                    .font(.system(size: 11, design: .rounded)).monospacedDigit()
                    .foregroundStyle(model.previewSeconds == nil ? Palette.secondaryText : Palette.primaryText)
                if model.previewSeconds != nil {
                    Pill(text: "preview only — nothing is applied", tone: .neutral)
                }
                Spacer()
            }
        }
    }

    private var readout: String {
        let seconds = model.previewSeconds
            ?? Timeline.wallClockSeconds(of: now, in: timeline.timeZone)
        let ev = timeline.evaluateAtWallClock(seconds: seconds)
        let time = clockString(seconds)
        let warmth = Format.kelvin(ev.target.temperature)
        let brightness = Format.percent(ev.target.dimming.factor)
        return "\(time) · \(ev.currentAnchorName) · about \(warmth) · \(brightness) brightness"
    }
}
