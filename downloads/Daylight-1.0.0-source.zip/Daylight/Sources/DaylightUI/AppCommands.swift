import Foundation

/// What the views are allowed to ask the application shell to do.
///
/// The views used to hold a reference to `AppDelegate` directly, which meant
/// the interface could not be built or rendered without the whole application
/// object. This protocol is the seam: `AppDelegate` conforms to it, and the
/// renderer passes `nil`.
public protocol AppCommands: AnyObject {
    func showMainWindow()
    func refreshStatusIcon()
    func finishOnboarding()
    func emergencyRestore()
    /// Returns a human-readable message if the change was refused.
    func setLaunchAtLogin(_ enabled: Bool) -> String?
    var launchAtLoginIsOn: Bool { get }
    /// Shortcuts another application already owns, so Daylight could not
    /// register them.
    var unavailableShortcuts: [String] { get }
}
