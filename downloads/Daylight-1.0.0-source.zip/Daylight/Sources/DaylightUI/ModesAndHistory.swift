import SwiftUI
import DaylightCore
import DaylightDisplay

// MARK: - Modes

/// Modes get their own section rather than a card buried in Settings: they are
/// applied constantly, from the menu bar, from rules and from the palette.
struct ModesPanel: View {
    @ObservedObject var coordinator: LightingCoordinator

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: Metrics.stackGap) {
                ModesCard(coordinator: coordinator)
                whereTheyAppearCard
            }
            .padding(Metrics.gutter)
        }
        .navigationTitle("Modes")
    }

    private var whereTheyAppearCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 8) {
                SectionLabel(text: "Where modes appear")
                Text("""
                Every mode you keep here shows up in three places: the menu bar panel, the command palette (\(GlobalHotKey.palette.description)), and as an action a rule can apply.

                A mode sits above your schedule but below a pause, so applying one does not fight the Restore command or an explicit pause. It lasts until the next scheduled change unless you pick a different duration in the menu bar.
                """)
                .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                .fixedSize(horizontal: false, vertical: true)
            }
        }
    }
}

final class ModesModel: ObservableObject {
    @Published var editingID: UUID?
}

/// Creating and editing the app's modes.
///
/// The built-in modes are ordinary editable records, not privileged ones — what
/// you can change about Reading, you can change about a mode you made yourself.
/// "Restore the built-in modes" puts the originals back without touching yours.
struct ModesCard: View {
    @ObservedObject var coordinator: LightingCoordinator
    @StateObject private var model = ModesModel()

    private static let symbols = [
        "scope", "book", "moon", "paintpalette", "person.2", "gamecontroller",
        "lamp.desk", "sun.max", "cloud.moon", "eye", "sparkles", "leaf",
        "cup.and.saucer", "film", "chart.bar", "text.alignleft",
    ]

    var body: some View {
        Card {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    SectionLabel(text: "Modes")
                    Spacer()
                    Menu("Add mode") {
                        Button("From what's on screen now") { addFromCurrent() }
                        Button("Blank") { add(blank()) }
                    }
                    .controlSize(.small).frame(width: 100)
                }
                Text("A mode is a named set of values you can apply from the menu bar, a rule, or the command palette. Nothing is hidden inside one.")
                    .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                    .fixedSize(horizontal: false, vertical: true)

                if coordinator.settings.profiles.isEmpty {
                    EmptyStateView(symbol: "square.stack", title: "No modes",
                                   message: "You have removed every mode. You can add one, or put the originals back.",
                                   action: ("Restore the built-in modes", restoreBuiltIns))
                } else {
                    ForEach(coordinator.settings.profiles) { profile in
                        ModeRow(profile: profile,
                                isEditing: model.editingID == profile.id,
                                symbols: Self.symbols,
                                usedByRules: rulesUsing(profile),
                                onToggleEditing: {
                                    withAnimation(Motion.reveal(coordinator.settings)) {
                                        model.editingID = model.editingID == profile.id ? nil : profile.id
                                    }
                                },
                                onChange: { update($0) },
                                onDelete: { delete(profile) })
                        if profile.id != coordinator.settings.profiles.last?.id {
                            Divider().padding(.vertical, 2)
                        }
                    }
                    if !coordinator.settings.profiles.contains(where: { $0.isBuiltIn })
                        || coordinator.settings.profiles.count < Profile.builtIns().count {
                        Button("Restore the built-in modes", action: restoreBuiltIns)
                            .buttonStyle(.link).font(.daylightCaption)
                    }
                }
            }
        }
    }

    private func rulesUsing(_ profile: Profile) -> [String] {
        coordinator.settings.rules.filter { rule in
            rule.actions.contains { if case .applyProfile(let id, _) = $0 { return id == profile.id }
                                    else { return false } }
        }.map(\.name)
    }

    private func blank() -> Profile {
        Profile(name: "New mode", symbolName: "sparkles",
                target: LightingTarget(temperature: ColourTemperature(kelvin: 4500),
                                       dimming: SoftwareDimming(factor: 0.9)),
                summary: "")
    }

    private func addFromCurrent() {
        let now = coordinator.outcome.target
        var profile = blank()
        profile.name = "Like now"
        profile.target = LightingTarget(temperature: now.temperature, dimming: now.dimming)
        profile.summary = "About \(Format.kelvin(now.temperature)) at \(Format.percent(now.dimming.factor)) brightness."
        add(profile)
    }

    private func add(_ profile: Profile) {
        coordinator.settings.profiles.append(profile)
        model.editingID = profile.id
    }

    private func update(_ profile: Profile) {
        guard let i = coordinator.settings.profiles.firstIndex(where: { $0.id == profile.id }) else { return }
        coordinator.settings.profiles[i] = profile
    }

    private func delete(_ profile: Profile) {
        withAnimation(Motion.reveal(coordinator.settings)) {
            coordinator.settings.profiles.removeAll { $0.id == profile.id }
        }
    }

    /// Adds back any built-in that is missing, by name, and leaves everything
    /// else — including your edits to the ones still present — alone.
    private func restoreBuiltIns() {
        let existing = Set(coordinator.settings.profiles.map(\.name))
        let missing = Profile.builtIns().filter { !existing.contains($0.name) }
        guard !missing.isEmpty else { return }
        coordinator.settings.profiles.append(contentsOf: missing)
    }
}

struct ModeRow: View {
    let profile: Profile
    let isEditing: Bool
    let symbols: [String]
    let usedByRules: [String]
    let onToggleEditing: () -> Void
    let onChange: (Profile) -> Void
    let onDelete: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 10) {
                Image(systemName: profile.symbolName)
                    .frame(width: 18).foregroundStyle(Palette.secondaryText)
                    .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 1) {
                    HStack(spacing: 6) {
                        Text(profile.name).font(.daylightBody)
                        if profile.isBuiltIn { Pill(text: "built in") }
                        if profile.silencesReminders { Pill(text: "quiet") }
                    }
                    Text(valueLine).font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                }
                Spacer(minLength: 8)
                IconButton(symbol: isEditing ? "chevron.up.circle.fill" : "pencil",
                           label: isEditing ? "Close editor" : "Edit \(profile.name)",
                           action: onToggleEditing)
                IconButton(symbol: "minus.circle", label: "Delete \(profile.name)", action: onDelete)
            }

            if isEditing { editor }
        }
        .padding(.vertical, 3)
        .accessibilityElement(children: .contain)
    }

    private var valueLine: String {
        var parts: [String] = []
        if let t = profile.target.temperature { parts.append(Format.kelvin(t)) }
        if let d = profile.target.dimming { parts.append("\(Format.percent(d.factor)) brightness") }
        if parts.isEmpty { return "Changes nothing on its own." }
        return parts.joined(separator: " · ")
    }

    private var editor: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 10) {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Name").font(.system(size: 10)).foregroundStyle(Palette.secondaryText)
                    TextField("Name", text: Binding(
                        get: { profile.name },
                        set: { var p = profile; p.name = $0; onChange(p) }))
                        .textFieldStyle(.roundedBorder).controlSize(.small).frame(width: 160)
                }
                VStack(alignment: .leading, spacing: 3) {
                    Text("Icon").font(.system(size: 10)).foregroundStyle(Palette.secondaryText)
                    Menu {
                        ForEach(symbols, id: \.self) { symbol in
                            Button { var p = profile; p.symbolName = symbol; onChange(p) } label: {
                                Label(symbol, systemImage: symbol)
                            }
                        }
                    } label: {
                        Image(systemName: profile.symbolName)
                    }
                    .controlSize(.small).frame(width: 60)
                    .accessibilityLabel("Icon for \(profile.name)")
                }
                Spacer()
            }

            HStack(spacing: 16) {
                ValueStepper(label: "Warmth",
                             isOn: profile.target.temperature != nil,
                             display: profile.target.temperature.map(Format.kelvin) ?? "unchanged",
                             value: profile.target.temperature?.kelvin ?? 4500,
                             range: ColourTemperature.advancedRange, step: 50,
                             onToggle: { on in
                                 var p = profile
                                 p.target.temperature = on ? ColourTemperature(kelvin: 4500) : nil
                                 onChange(p)
                             },
                             onSet: { v in
                                 var p = profile
                                 p.target.temperature = ColourTemperature(kelvin: v)
                                 onChange(p)
                             })
                ValueStepper(label: "Brightness",
                             isOn: profile.target.dimming != nil,
                             display: profile.target.dimming.map { Format.percent($0.factor) } ?? "unchanged",
                             value: (profile.target.dimming?.factor ?? 0.9) * 100,
                             range: SoftwareDimming.safeFloor * 100...100, step: 5,
                             onToggle: { on in
                                 var p = profile
                                 p.target.dimming = on ? SoftwareDimming(factor: 0.9) : nil
                                 onChange(p)
                             },
                             onSet: { v in
                                 var p = profile
                                 p.target.dimming = SoftwareDimming(factor: v / 100)
                                 onChange(p)
                             })
                Spacer()
            }

            Text("A control left unchanged stays with whatever the schedule or a lower-priority rule decided.")
                .font(.system(size: 10)).foregroundStyle(Palette.secondaryText)

            Toggle("Silence break reminders while this is active", isOn: Binding(
                get: { profile.silencesReminders },
                set: { var p = profile; p.silencesReminders = $0; onChange(p) }))
                .toggleStyle(.checkbox).controlSize(.small)

            VStack(alignment: .leading, spacing: 3) {
                Text("Description").font(.system(size: 10)).foregroundStyle(Palette.secondaryText)
                TextField("What this mode does, in one sentence", text: Binding(
                    get: { profile.summary },
                    set: { var p = profile; p.summary = $0; onChange(p) }))
                    .textFieldStyle(.roundedBorder).controlSize(.small)
                Text("Shown wherever this mode appears, so it never has to be guessed at.")
                    .font(.system(size: 10)).foregroundStyle(Palette.tertiaryText)
            }

            if !usedByRules.isEmpty {
                NoticeBanner(kind: .info,
                             message: "Used by \(usedByRules.count == 1 ? "the rule" : "rules") “\(usedByRules.joined(separator: "”, “"))”. Deleting this mode leaves those rules with nothing to apply.")
            }
        }
        .padding(12)
        .background(RoundedRectangle(cornerRadius: Metrics.cornerRadius, style: .continuous)
            .fill(Color.primary.opacity(0.035)))
    }
}

/// A stepper that can also be switched off entirely, for values a mode may
/// deliberately leave alone.
struct ValueStepper: View {
    let label: String
    let isOn: Bool
    let display: String
    let value: Double
    let range: ClosedRange<Double>
    let step: Double
    let onToggle: (Bool) -> Void
    let onSet: (Double) -> Void

    var body: some View {
        HStack(spacing: 6) {
            Toggle("", isOn: Binding(get: { isOn }, set: onToggle))
                .toggleStyle(.checkbox).labelsHidden()
                .accessibilityLabel("Set \(label)")
            Text(label).font(.daylightCaption)
                .foregroundStyle(isOn ? Palette.primaryText : Palette.secondaryText)
            if isOn {
                Stepper(value: Binding(get: { value }, set: onSet), in: range, step: step) {
                    Text(verbatim: display)
                        .font(.system(size: 11, design: .rounded)).monospacedDigit()
                        .frame(width: 56, alignment: .leading)
                }
                .accessibilityLabel(label).accessibilityValue(display)
            } else {
                Text(verbatim: display)
                    .font(.system(size: 11)).foregroundStyle(Palette.tertiaryText)
            }
        }
    }
}

// MARK: - History

final class HistoryModel: ObservableObject {
    @Published var expandedID: UUID?
    @Published var reloadToken = 0
}

/// A plain log of what the app did.
struct HistoryCard: View {
    @ObservedObject var coordinator: LightingCoordinator
    @StateObject private var model = HistoryModel()

    private var entries: [HistoryEntry] {
        _ = model.reloadToken
        return Array(coordinator.history.all().prefix(60))
    }

    var body: some View {
        Card {
            VStack(alignment: .leading, spacing: 10) {
                Toggle("Keep a local history of what Daylight does", isOn: Binding(
                    get: { coordinator.settings.history.isEnabled },
                    set: { coordinator.setHistoryEnabled($0); model.reloadToken += 1 }))
                    .toggleStyle(.switch).font(.daylightTitle)

                Text("""
                A record of schedule changes, modes, overrides and any problems with a display. It stays on this Mac, it is never sent anywhere, and turning it off deletes what has been kept.

                It describes what the software did. It does not measure or infer anything about you.
                """)
                .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                .fixedSize(horizontal: false, vertical: true)

                if coordinator.settings.history.isEnabled {
                    HStack(spacing: 10) {
                        Text("Keep for").font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                        Picker("", selection: Binding(
                            get: { coordinator.settings.history.retentionDays },
                            set: { coordinator.settings.history.retentionDays = $0 })) {
                            ForEach(HistorySettings.retentionChoices, id: \.self) { d in
                                Text(verbatim: d == 1 ? "1 day" : "\(d) days").tag(d)
                            }
                        }
                        .labelsHidden().controlSize(.small).frame(width: 100)
                        .accessibilityLabel("How long to keep history")
                        Spacer()
                        Button("Clear now") {
                            coordinator.clearHistory()
                            model.reloadToken += 1
                        }
                        .controlSize(.small)
                        .disabled(entries.isEmpty)
                    }

                    Divider()

                    if entries.isEmpty {
                        EmptyStateView(symbol: "clock", title: "Nothing recorded yet",
                                       message: "Entries will appear here as your schedule moves through the day.")
                    } else {
                        VStack(alignment: .leading, spacing: 0) {
                            ForEach(entries) { entry in
                                HistoryRow(entry: entry,
                                           isExpanded: model.expandedID == entry.id,
                                           onTap: {
                                               guard entry.detail != nil else { return }
                                               withAnimation(Motion.reveal(coordinator.settings)) {
                                                   model.expandedID = model.expandedID == entry.id ? nil : entry.id
                                               }
                                           })
                            }
                        }
                        .frame(maxHeight: 300)
                    }
                }
            }
        }
        .onAppear { model.reloadToken += 1 }
    }
}

struct HistoryRow: View {
    let entry: HistoryEntry
    let isExpanded: Bool
    let onTap: () -> Void

    private static let time: DateFormatter = {
        let f = DateFormatter(); f.dateFormat = "d MMM, HH:mm"; return f
    }()

    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Image(systemName: entry.kind.symbolName)
                    .font(.system(size: 10))
                    .foregroundStyle(entry.kind.isProblem ? Palette.warning : Palette.tertiaryText)
                    .frame(width: 14)
                    .accessibilityHidden(true)
                Text(verbatim: Self.time.string(from: entry.at))
                    .font(.system(size: 10, design: .rounded)).monospacedDigit()
                    .foregroundStyle(Palette.tertiaryText)
                    .frame(width: 88, alignment: .leading)
                Text(entry.summary)
                    .font(.daylightCaption)
                    .foregroundStyle(entry.kind.isProblem ? Palette.warning : Palette.primaryText)
                    .fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 4)
                if entry.detail != nil {
                    Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                        .font(.system(size: 8)).foregroundStyle(Palette.tertiaryText)
                        .accessibilityHidden(true)
                }
            }
            if isExpanded, let detail = entry.detail {
                Text(detail)
                    .font(.system(size: 10)).foregroundStyle(Palette.secondaryText)
                    .padding(.leading, 110)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(.vertical, 3)
        .contentShape(Rectangle())
        .onTapGesture(perform: onTap)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(Self.time.string(from: entry.at)). \(entry.summary)")
        .accessibilityHint(entry.detail ?? "")
    }
}
