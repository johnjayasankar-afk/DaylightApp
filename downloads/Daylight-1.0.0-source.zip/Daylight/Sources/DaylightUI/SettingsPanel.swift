import SwiftUI
import UniformTypeIdentifiers
import DaylightCore
import DaylightDisplay

final class SettingsPanelModel: ObservableObject {
    @Published var message: String?
    @Published var confirmingReset = false
    @Published var launchAtLogin = false
}

struct SettingsPanel: View {
    @ObservedObject var coordinator: LightingCoordinator
    weak var delegate: AppCommands?
    @StateObject private var model = SettingsPanelModel()

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: Metrics.stackGap) {
                if let m = model.message {
                    NoticeBanner(kind: .info, message: m, action: ("Dismiss", { model.message = nil }))
                }
                behaviourCard
                remindersCard
                HistoryCard(coordinator: coordinator)
                shortcutsCard
                experimentsCard
                dataCard
                TroubleshootingCard(coordinator: coordinator, delegate: delegate)
                privacyCard
                aboutCard
            }
            .padding(Metrics.gutter)
        }
        .navigationTitle("Settings")
        .onAppear { model.launchAtLogin = delegate?.launchAtLoginIsOn ?? false }
    }

    // MARK: Behaviour

    private var behaviourCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 14) {
                SectionLabel(text: "Behaviour")

                VStack(alignment: .leading, spacing: 4) {
                    Picker("Transition speed", selection: Binding(
                        get: { coordinator.settings.transitionSpeed },
                        set: { coordinator.settings.transitionSpeed = $0 })) {
                        ForEach(TransitionSpeed.allCases, id: \.self) { Text($0.displayName).tag($0) }
                    }
                    .pickerStyle(.segmented)
                    Text(coordinator.settings.transitionSpeed.description)
                        .font(.system(size: 10)).foregroundStyle(Palette.tertiaryText)
                }

                Toggle("Start Daylight when I log in", isOn: Binding(
                    get: { model.launchAtLogin },
                    set: { on in
                        model.launchAtLogin = on
                        if let error = delegate?.setLaunchAtLogin(on) {
                            model.message = error
                            model.launchAtLogin = delegate?.launchAtLoginIsOn ?? false
                        }
                        coordinator.settings.launchAtLogin = model.launchAtLogin
                    }))
                    .toggleStyle(.checkbox)

                Toggle("Show the current warmth in the menu bar", isOn: Binding(
                    get: { coordinator.settings.showsMenuBarPercentage },
                    set: { coordinator.settings.showsMenuBarPercentage = $0; delegate?.refreshStatusIcon() }))
                    .toggleStyle(.checkbox)

                VStack(alignment: .leading, spacing: 3) {
                    Toggle("Allow a wider warmth range", isOn: Binding(
                        get: { coordinator.settings.advancedWarmthRange },
                        set: { coordinator.settings.advancedWarmthRange = $0 }))
                        .toggleStyle(.checkbox)
                    Text("Extends the lower limit from \(Int(ColourTemperature.normalRange.lowerBound)) K to \(Int(ColourTemperature.advancedRange.lowerBound)) K. Very warm settings can make text hard to read.")
                        .font(.system(size: 10)).foregroundStyle(Palette.tertiaryText)
                        .fixedSize(horizontal: false, vertical: true)
                }

                Divider()

                VStack(alignment: .leading, spacing: 3) {
                    Toggle("Warn me before saving hard-to-read settings", isOn: Binding(
                        get: { coordinator.settings.warnOnExtremeSettings },
                        set: { coordinator.settings.warnOnExtremeSettings = $0 }))
                        .toggleStyle(.checkbox)
                    Text("Applies to very warm or very dim values in the schedule editor. The change still happens straight away; Daylight just offers you the way back.")
                        .font(.system(size: 10)).foregroundStyle(Palette.secondaryText)
                        .fixedSize(horizontal: false, vertical: true)
                }

                VStack(alignment: .leading, spacing: 3) {
                    Toggle("Follow the system's Reduce Motion setting", isOn: Binding(
                        get: { coordinator.settings.respectsReducedMotion },
                        set: { coordinator.settings.respectsReducedMotion = $0 }))
                        .toggleStyle(.checkbox)
                    Text(reduceMotionExplanation)
                        .font(.system(size: 10)).foregroundStyle(Palette.secondaryText)
                        .fixedSize(horizontal: false, vertical: true)
                }

                Divider()

                VStack(alignment: .leading, spacing: 3) {
                    Text("Closing the main window leaves Daylight running in the menu bar so your schedule keeps working. Quit from the menu bar icon to stop it completely; quitting restores your displays.")
                        .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
        }
    }

    // MARK: Shortcuts

    private var shortcutsCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 10) {
                SectionLabel(text: "Keyboard shortcuts")
                shortcutRow("Restore normal output", GlobalHotKey.restore.description)
                shortcutRow("Open \(Branding.productName)", GlobalHotKey.openDaylight.description)
                shortcutRow("Pause or resume", GlobalHotKey.toggleAutomation.description)
                shortcutRow("Command palette", GlobalHotKey.palette.description)
                if let unavailable = delegate?.unavailableShortcuts, !unavailable.isEmpty {
                    NoticeBanner(kind: .warning,
                                 message: "Another app is already using \(unavailable.joined(separator: ", ")). Those shortcuts are not active.")
                }
                Text("These work anywhere, without Daylight needing accessibility access.")
                    .font(.system(size: 10)).foregroundStyle(Palette.tertiaryText)
            }
        }
    }

    private func shortcutRow(_ title: String, _ keys: String) -> some View {
        HStack {
            Text(title).font(.daylightBody)
            Spacer()
            Text(keys)
                .font(.system(size: 12, design: .rounded))
                .padding(.horizontal, 7).padding(.vertical, 3)
                .background(RoundedRectangle(cornerRadius: 5).fill(Color.primary.opacity(0.06)))
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(title): \(keys)")
    }

    private var reduceMotionExplanation: String {
        let systemIsOn = NSWorkspace.shared.accessibilityDisplayShouldReduceMotion
        if !coordinator.settings.respectsReducedMotion {
            return "Daylight will animate its interface even when macOS asks apps not to."
        }
        return systemIsOn
            ? "Reduce Motion is on in System Settings, so Daylight is not animating its interface. Display transitions themselves are unaffected — those are a comfort setting, not an animation."
            : "Reduce Motion is off in System Settings, so Daylight uses short transitions. Turning it on there will quiet them."
    }

    // MARK: Reminders

    private var remindersCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 12) {
                Toggle("Remind me to look away from the screen", isOn: Binding(
                    get: { coordinator.settings.breakReminders.isEnabled },
                    set: { coordinator.settings.breakReminders.isEnabled = $0 }))
                    .toggleStyle(.switch).font(.daylightTitle)

                Text("A small note appears in the corner. It never takes focus, never blocks anything, and disappears on its own if you ignore it. Daylight keeps no count of how many you took.")
                    .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                    .fixedSize(horizontal: false, vertical: true)

                if coordinator.settings.breakReminders.isEnabled {
                    HStack(spacing: 16) {
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Every").font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                            Picker("", selection: Binding(
                                get: { coordinator.settings.breakReminders.intervalMinutes },
                                set: { coordinator.settings.breakReminders.intervalMinutes = $0 })) {
                                ForEach(BreakReminderSettings.intervalChoices, id: \.self) { m in
                                    Text(verbatim: "\(Int(m)) min").tag(m)
                                }
                            }
                            .labelsHidden().controlSize(.small).frame(width: 100)
                            .accessibilityLabel("Reminder interval")
                        }
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Snooze for").font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                            Picker("", selection: Binding(
                                get: { coordinator.settings.breakReminders.snoozeMinutes },
                                set: { coordinator.settings.breakReminders.snoozeMinutes = $0 })) {
                                ForEach(BreakReminderSettings.snoozeChoices, id: \.self) { m in
                                    Text(verbatim: "\(Int(m)) min").tag(m)
                                }
                            }
                            .labelsHidden().controlSize(.small).frame(width: 100)
                            .accessibilityLabel("Snooze length")
                        }
                        Spacer()
                    }

                    Toggle("Stay quiet at night", isOn: Binding(
                        get: { coordinator.settings.breakReminders.quietStartSeconds != nil },
                        set: { on in
                            coordinator.settings.breakReminders.quietStartSeconds = on ? 22 * 3600 : nil
                            coordinator.settings.breakReminders.quietEndSeconds = on ? 8 * 3600 : nil
                        }))
                        .toggleStyle(.checkbox)

                    if let start = coordinator.settings.breakReminders.quietStartSeconds,
                       let end = coordinator.settings.breakReminders.quietEndSeconds {
                        HStack(spacing: 14) {
                            quietStepper("From", seconds: start) {
                                coordinator.settings.breakReminders.quietStartSeconds = $0
                            }
                            quietStepper("Until", seconds: end) {
                                coordinator.settings.breakReminders.quietEndSeconds = $0
                            }
                            Spacer()
                        }
                    }

                    Toggle("Stay quiet during Presentation and Gaming", isOn: Binding(
                        get: { coordinator.settings.breakReminders.respectsSilencingModes },
                        set: { coordinator.settings.breakReminders.respectsSilencingModes = $0 }))
                        .toggleStyle(.checkbox)

                    if let next = coordinator.nextBreakReminderAt {
                        Text("Next reminder around \(Format.timeOfDay.string(from: next)).")
                            .font(.system(size: 10)).foregroundStyle(Palette.tertiaryText)
                    }
                }
            }
        }
    }

    private func quietStepper(_ label: String, seconds: Int,
                              onSet: @escaping (Int) -> Void) -> some View {
        HStack(spacing: 5) {
            Text(label).font(.daylightCaption).foregroundStyle(Palette.secondaryText)
            Stepper(value: Binding(get: { Double(seconds) }, set: { onSet(Int($0)) }),
                    in: 0...86_340, step: 1800) {
                Text(verbatim: clockString(Double(seconds)))
                    .font(.system(size: 11, design: .rounded)).monospacedDigit()
                    .frame(width: 44, alignment: .leading)
            }
            .accessibilityLabel("Quiet hours \(label.lowercased())")
            .accessibilityValue(clockString(Double(seconds)))
        }
    }

    // MARK: Experiments

    private var experimentsCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 10) {
                SectionLabel(text: "Experimental")
                Toggle("Try to control external monitor backlights", isOn: Binding(
                    get: { coordinator.settings.experimentalDDCBrightness },
                    set: {
                        coordinator.settings.experimentalDDCBrightness = $0
                        coordinator.refreshHardwareBrightnessSupport()
                    }))
                    .toggleStyle(.switch)
                Text("""
                Some external monitors accept brightness commands over their video cable (DDC/CI). Where that works, Daylight can change the real backlight instead of dimming in software.

                This uses parts of macOS that Apple does not document, so it may stop working after a system update, and it does nothing at all on many monitors, docks and cables. Daylight only claims a display supports it after that display has answered a query — it never sends brightness commands blind.

                Everything else in Daylight works exactly the same whether this is on or off.
                """)
                .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                .fixedSize(horizontal: false, vertical: true)

                if coordinator.settings.experimentalDDCBrightness {
                    let supported = coordinator.displayStatuses.filter { $0.capabilities.supportsHardwareBrightness }
                    if supported.isEmpty {
                        NoticeBanner(kind: .info,
                                     message: coordinator.displayStatuses.contains(where: { !$0.isBuiltIn })
                                        ? "No connected display answered a brightness query, so software dimming is still being used everywhere."
                                        : "This only applies to external monitors. Your built-in display's backlight cannot be controlled by an app.")
                    } else {
                        NoticeBanner(kind: .info,
                                     message: "Answered a brightness query: \(supported.map(\.name).joined(separator: ", ")). Turn it on for a display in the Displays tab.")
                    }
                }
            }
        }
    }

    // MARK: Data

    private var dataCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 10) {
                SectionLabel(text: "Your settings")
                Text("Everything Daylight knows is in one file on this Mac. There is no account and no server.")
                    .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                HStack(spacing: 8) {
                    Button("Export…") { export() }
                    Button("Import…") { importSettings() }
                    Button("Reveal in Finder") {
                        NSWorkspace.shared.activateFileViewerSelecting(
                            [SettingsStore.defaultDirectory().appendingPathComponent("settings.json")])
                    }
                    Spacer()
                    Button(model.confirmingReset ? "Really reset?" : "Reset to defaults") {
                        if model.confirmingReset { resetAll() } else { model.confirmingReset = true }
                    }
                    .foregroundStyle(model.confirmingReset ? Palette.warning : Palette.primaryText)
                }
                .controlSize(.small)
            }
        }
    }

    private func export() {
        let panel = NSSavePanel()
        panel.nameFieldStringValue = "Daylight Settings.json"
        panel.allowedContentTypes = [.json]
        guard panel.runModal() == .OK, let url = panel.url else { return }
        do {
            let store = SettingsStore(directory: SettingsStore.defaultDirectory())
            try store.exportData(coordinator.settings).write(to: url)
            model.message = "Settings exported."
        } catch {
            model.message = "Daylight could not write that file."
        }
    }

    private func importSettings() {
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.json]
        panel.allowsMultipleSelection = false
        guard panel.runModal() == .OK, let url = panel.url else { return }
        do {
            let store = SettingsStore(directory: SettingsStore.defaultDirectory())
            let data = try Data(contentsOf: url)
            coordinator.settings = try store.importData(data)
            coordinator.rebuildTimeline()
            model.message = "Settings imported."
        } catch {
            model.message = (error as? LocalizedError)?.errorDescription
                ?? "That file could not be read as Daylight settings."
        }
    }

    private func resetAll() {
        model.confirmingReset = false
        var fresh = Presets.defaultSettings()
        fresh.hasCompletedOnboarding = true
        coordinator.settings = fresh
        coordinator.rebuildTimeline()
        model.message = "Settings reset."
    }

    // MARK: Privacy

    private var privacyCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 8) {
                SectionLabel(text: "Privacy")
                Text("""
                Daylight makes no network requests at all. Sunrise and sunset are worked out on this Mac from a place you choose — picked from a list built into the app, or typed in as coordinates. It never asks macOS where you are.

                It can offer a starting suggestion based on your time zone. A time zone is a setting, not a position, so that costs no permission and is a guess you confirm rather than a lookup.

                It does not collect analytics, read screen contents, record keystrokes, or use the camera. If you turn on app rules, it reads the identifier of the frontmost app while deciding what to do and keeps no record of it. History, if you switch it on, stays on this Mac and is deleted when you switch it off.
                """)
                .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    // MARK: About

    private var aboutCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 10) {
                SectionLabel(text: "About")
                FactRow(label: Branding.productName, value: "Version \(Branding.version)")
                if coordinator.isSimulated {
                    NoticeBanner(kind: .warning,
                                 message: "Running in simulation mode. Displays are fake and nothing on screen is actually being changed.")
                }
                Text("""
                Daylight adjusts how your display looks. It is a comfort and routine tool, not a medical one: it does not prevent eye damage, treat eye strain, or guarantee anything about your sleep.

                Comfort at a screen depends on more than colour — brightness, glare, text size, distance, how long you have been working and the light in the room all matter too.
                """)
                .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                .fixedSize(horizontal: false, vertical: true)
                Link("Healthy sleep habits (US National Heart, Lung, and Blood Institute)",
                     destination: URL(string: "https://www.nhlbi.nih.gov/health/sleep-deprivation/healthy-sleep-habits")!)
                    .font(.daylightCaption)
            }
        }
    }
}
