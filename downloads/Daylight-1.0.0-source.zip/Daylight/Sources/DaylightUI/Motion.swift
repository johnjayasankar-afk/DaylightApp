import SwiftUI
import AppKit
import DaylightCore

/// The app's entire motion vocabulary.
///
/// Four named animations, all short, all in service of showing that something
/// changed. Nothing loops, nothing bounces, nothing animates while the window
/// is closed. Every one of them returns `nil` when motion should be reduced, so
/// a single check at the call site covers both the system setting and the app's
/// own switch.
public enum Motion {

    /// True when the system's Reduce Motion is on, or the person has turned
    /// Daylight's own switch off.
    public static func isReduced(_ settings: DaylightSettings) -> Bool {
        settings.respectsReducedMotion
            && NSWorkspace.shared.accessibilityDisplayShouldReduceMotion
    }

    /// A value settling into place — a slider release, a number updating.
    public static func settle(_ settings: DaylightSettings) -> Animation? {
        isReduced(settings) ? nil : .easeOut(duration: 0.22)
    }

    /// Something appearing or disappearing.
    public static func reveal(_ settings: DaylightSettings) -> Animation? {
        isReduced(settings) ? nil : .easeOut(duration: 0.18)
    }

    /// A selection moving between two places.
    public static func move(_ settings: DaylightSettings) -> Animation? {
        isReduced(settings) ? nil : .spring(response: 0.30, dampingFraction: 0.86)
    }

    /// The current-time marker and other slow, ambient movement. Deliberately
    /// the longest, so it reads as drift rather than as an event.
    public static func drift(_ settings: DaylightSettings) -> Animation? {
        isReduced(settings) ? nil : .easeInOut(duration: 0.6)
    }
}

/// Whether the system is asking for higher contrast.
///
/// Consulted rather than assumed: when it is on, hairlines and secondary text
/// are strengthened instead of the layout changing, so nothing moves.
public enum Contrast {
    public static var isIncreased: Bool {
        NSWorkspace.shared.accessibilityDisplayShouldIncreaseContrast
    }
}
