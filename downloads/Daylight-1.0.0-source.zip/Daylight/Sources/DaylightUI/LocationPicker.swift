import SwiftUI
import DaylightCore
import DaylightDisplay

final class LocationPickerModel: ObservableObject {
    @Published var query = ""
    @Published var showingCoordinates = false
    @Published var latitudeText = ""
    @Published var longitudeText = ""
    @Published var placeText = ""
}

/// Choosing where the sun rises and sets for you.
///
/// Three ways in, in order of how little work they are: accept the suggestion
/// drawn from your time zone, search a bundled list, or type coordinates. None
/// of them asks macOS for your location or touches the network.
struct LocationPicker: View {
    @ObservedObject var coordinator: LightingCoordinator
    @StateObject private var model = LocationPickerModel()

    private var suggestion: City? {
        Cities.suggestion(forTimeZone: coordinator.timeZone.identifier)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionLabel(text: "Location")

            if let location = coordinator.settings.location {
                current(location)
            } else {
                EmptyStateView(
                    symbol: "mappin.slash",
                    title: "No location set",
                    message: "Schedules that follow the sun will use fallback times until you set one. Everything else works without it.")
                if let suggestion {
                    Button {
                        withAnimation(Motion.settle(coordinator.settings)) {
                            coordinator.settings.location = suggestion.location
                        }
                    } label: {
                        Label("Use \(suggestion.label)", systemImage: "clock")
                    }
                    .controlSize(.small)
                    .help("Suggested from your time zone setting, which is not a location lookup")
                }
            }

            Text("Daylight works out sunrise and sunset on this Mac. It never asks macOS where you are and makes no network requests. A suggestion from your time zone is a guess offered for confirmation, not a lookup.")
                .font(.system(size: 10)).foregroundStyle(Palette.secondaryText)
                .fixedSize(horizontal: false, vertical: true)

            search

            DisclosureGroup(isExpanded: $model.showingCoordinates) {
                coordinateEntry
            } label: {
                Text("Enter coordinates instead")
                    .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
            }
            .controlSize(.small)
        }
    }

    // MARK: Current location

    @ViewBuilder
    private func current(_ location: GeoLocation) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Image(systemName: "mappin.and.ellipse")
                    .foregroundStyle(Palette.accent).font(.system(size: 12))
                    .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 1) {
                    Text(location.label).font(.daylightTitle)
                    Text(verbatim: String(format: "%.3f, %.3f", location.latitude, location.longitude))
                        .font(.system(size: 10, design: .rounded)).monospacedDigit()
                        .foregroundStyle(Palette.secondaryText)
                }
                Spacer()
                Button("Remove") {
                    withAnimation(Motion.reveal(coordinator.settings)) {
                        coordinator.settings.location = nil
                    }
                }
                .controlSize(.small)
            }

            // Showing today's actual sunrise and sunset is the quickest way to
            // tell whether the location you picked is the one you meant.
            solarSummary(location)

            if location.disagreesWithSystemClock(coordinator.timeZone) {
                clockMismatchNote(location)
            }
        }
        .padding(10)
        .background(RoundedRectangle(cornerRadius: Metrics.cornerRadius, style: .continuous)
            .fill(Palette.accentSoft.opacity(0.6)))
    }

    /// Times are always shown on the Mac's own clock, because that is the
    /// clock the schedule runs on. When the chosen place keeps a different one,
    /// sunrise can land at an hour that looks like a bug — so say why.
    @ViewBuilder
    private func clockMismatchNote(_ location: GeoLocation) -> some View {
        let placeZone = location.timeZoneIdentifier ?? "another time zone"
        NoticeBanner(
            kind: .warning,
            message: "\(location.label) keeps a different clock from this Mac (\(placeZone) versus \(coordinator.timeZone.identifier)). The times above are shown on your Mac's clock, which is the one your schedule follows — so they will look shifted. If you have moved, updating the time zone in System Settings will line them up.")
    }

    @ViewBuilder
    private func solarSummary(_ location: GeoLocation) -> some View {
        let sunrise = SolarCalculator.event(.sunrise, date: Date(),
                                            location: location, timeZone: coordinator.timeZone)
        let sunset = SolarCalculator.event(.sunset, date: Date(),
                                           location: location, timeZone: coordinator.timeZone)
        HStack(spacing: 14) {
            solarChip(symbol: "sunrise", label: "Sunrise", result: sunrise)
            solarChip(symbol: "sunset", label: "Sunset", result: sunset)
            Text("on this Mac's clock")
                .font(.system(size: 10)).foregroundStyle(Palette.tertiaryText)
            Spacer()
        }
        .font(.daylightCaption)
    }

    @ViewBuilder
    private func solarChip(symbol: String, label: String, result: SolarEventResult) -> some View {
        HStack(spacing: 5) {
            Image(systemName: symbol).font(.system(size: 10))
                .foregroundStyle(Palette.secondaryText)
                .accessibilityHidden(true)
            Text(verbatim: describe(result))
                .font(.system(size: 11, design: .rounded)).monospacedDigit()
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(label) today: \(describe(result))")
    }

    private func describe(_ result: SolarEventResult) -> String {
        switch result {
        case .occurs(let seconds): return clockString(seconds)
        case .polarDay:            return "no sunset today"
        case .polarNight:          return "no sunrise today"
        }
    }

    // MARK: Search

    private var search: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 6) {
                Image(systemName: "magnifyingglass")
                    .font(.system(size: 11)).foregroundStyle(Palette.secondaryText)
                    .accessibilityHidden(true)
                TextField("Search for a city", text: $model.query)
                    .textFieldStyle(.roundedBorder).controlSize(.small)
                    .accessibilityLabel("Search for a city")
            }

            if !model.query.isEmpty {
                let results = Cities.search(model.query, limit: 6)
                if results.isEmpty {
                    Text("Nothing here matches “\(model.query)”. The list is a small selection — anywhere else can be reached by entering coordinates.")
                        .font(.system(size: 10)).foregroundStyle(Palette.secondaryText)
                        .fixedSize(horizontal: false, vertical: true)
                } else {
                    VStack(spacing: 0) {
                        ForEach(results) { city in
                            Button {
                                withAnimation(Motion.settle(coordinator.settings)) {
                                    coordinator.settings.location = city.location
                                    model.query = ""
                                }
                            } label: {
                                HStack(spacing: 8) {
                                    Text(city.name).font(.daylightBody)
                                    Text(city.region).font(.daylightCaption)
                                        .foregroundStyle(Palette.secondaryText)
                                    Spacer()
                                    Text(verbatim: String(format: "%.1f°", city.latitude))
                                        .font(.system(size: 10, design: .rounded)).monospacedDigit()
                                        .foregroundStyle(Palette.tertiaryText)
                                }
                                .padding(.vertical, 4).padding(.horizontal, 6)
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            .accessibilityLabel("\(city.name), \(city.region)")
                        }
                    }
                    .background(RoundedRectangle(cornerRadius: 7, style: .continuous)
                        .fill(Color.primary.opacity(0.04)))
                }
            }
        }
    }

    // MARK: Coordinates

    private var coordinateEntry: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 8) {
                TextField("Place name", text: $model.placeText).frame(width: 150)
                TextField("Latitude", text: $model.latitudeText).frame(width: 90)
                TextField("Longitude", text: $model.longitudeText).frame(width: 90)
                Button("Set", action: saveCoordinates).disabled(!coordinatesAreValid)
            }
            .textFieldStyle(.roundedBorder).controlSize(.small)
            if !model.latitudeText.isEmpty || !model.longitudeText.isEmpty, !coordinatesAreValid {
                Text("Latitude runs from −90 to 90 and longitude from −180 to 180, in decimal degrees.")
                    .font(.system(size: 10)).foregroundStyle(Palette.warning)
            }
        }
        .padding(.top, 4)
    }

    private var coordinatesAreValid: Bool {
        guard let lat = Double(model.latitudeText), let lon = Double(model.longitudeText) else {
            return false
        }
        return GeoLocation(latitude: lat, longitude: lon, label: "").isValid
    }

    private func saveCoordinates() {
        guard let lat = Double(model.latitudeText), let lon = Double(model.longitudeText) else { return }
        let name = model.placeText.trimmingCharacters(in: .whitespaces)
        let location = GeoLocation(latitude: lat, longitude: lon,
                                   label: name.isEmpty ? "My location" : name)
        guard location.isValid else { return }
        withAnimation(Motion.settle(coordinator.settings)) {
            coordinator.settings.location = location
            model.showingCoordinates = false
        }
    }
}
