import Carbon.HIToolbox
import AppKit

/// Registers a system-wide keyboard shortcut.
///
/// Uses the documented Carbon hot-key API, which needs no accessibility
/// permission — important, because the emergency restore shortcut has to work
/// even for someone who has granted Daylight nothing at all.
final class GlobalHotKey {
    struct Combo: Equatable {
        var keyCode: UInt32
        var modifiers: UInt32
        var description: String
    }

    private var ref: EventHotKeyRef?
    private let id: UInt32
    private let handler: () -> Void
    private(set) var isRegistered = false
    let combo: Combo

    nonisolated(unsafe) private static var registry: [UInt32: GlobalHotKey] = [:]
    nonisolated(unsafe) private static var nextID: UInt32 = 1
    nonisolated(unsafe) private static var eventHandlerInstalled = false

    init?(combo: Combo, handler: @escaping () -> Void) {
        self.combo = combo
        self.handler = handler
        self.id = GlobalHotKey.nextID
        GlobalHotKey.nextID += 1
        GlobalHotKey.installEventHandlerIfNeeded()

        var hotKeyID = EventHotKeyID(signature: OSType(0x44594C54), id: id)  // 'DYLT'
        let status = RegisterEventHotKey(combo.keyCode, combo.modifiers, hotKeyID,
                                         GetApplicationEventTarget(), 0, &ref)
        // A non-zero status usually means another app already owns the
        // combination. Daylight reports that rather than silently doing nothing.
        guard status == noErr else { return nil }
        isRegistered = true
        GlobalHotKey.registry[id] = self
        _ = hotKeyID
    }

    deinit { unregister() }

    func unregister() {
        if let ref { UnregisterEventHotKey(ref) }
        ref = nil
        isRegistered = false
        GlobalHotKey.registry[id] = nil
    }

    private static func installEventHandlerIfNeeded() {
        guard !eventHandlerInstalled else { return }
        eventHandlerInstalled = true
        var spec = EventTypeSpec(eventClass: OSType(kEventClassKeyboard),
                                 eventKind: UInt32(kEventHotKeyPressed))
        InstallEventHandler(GetApplicationEventTarget(), { _, event, _ -> OSStatus in
            var hkID = EventHotKeyID()
            GetEventParameter(event, EventParamName(kEventParamDirectObject),
                              EventParamType(typeEventHotKeyID), nil,
                              MemoryLayout<EventHotKeyID>.size, nil, &hkID)
            if let target = GlobalHotKey.registry[hkID.id] {
                DispatchQueue.main.async { target.handler() }
            }
            return noErr
        }, 1, &spec, nil, nil)
    }

    // Combinations Daylight ships with. Both are unusual enough to be free on
    // most systems, and both can be turned off.
    static let restore = Combo(keyCode: UInt32(kVK_ANSI_R),
                               modifiers: UInt32(optionKey | cmdKey | shiftKey),
                               description: "⇧⌥⌘R")
    static let openDaylight = Combo(keyCode: UInt32(kVK_ANSI_D),
                                    modifiers: UInt32(optionKey | cmdKey | shiftKey),
                                    description: "⇧⌥⌘D")
    static let palette = Combo(keyCode: UInt32(kVK_ANSI_K),
                               modifiers: UInt32(optionKey | cmdKey | shiftKey),
                               description: "⇧⌥⌘K")
    static let toggleAutomation = Combo(keyCode: UInt32(kVK_ANSI_P),
                                        modifiers: UInt32(optionKey | cmdKey | shiftKey),
                                        description: "⇧⌥⌘P")
}
