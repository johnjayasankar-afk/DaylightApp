import SwiftUI
import AppKit
import DaylightCore
import DaylightDisplay

final class TroubleshootingModel: ObservableObject {
    @Published var expanded: String?
    @Published var note: String?
}

/// Answers to the things that actually go wrong.
///
/// Written as symptoms rather than as features, because that is how someone
/// arrives here. Each one ends in something to press, not just an explanation —
/// and where Daylight cannot fix it, it says who can.
struct TroubleshootingCard: View {
    @ObservedObject var coordinator: LightingCoordinator
    weak var delegate: AppCommands?
    @StateObject private var model = TroubleshootingModel()

    var body: some View {
        Card {
            VStack(alignment: .leading, spacing: 10) {
                SectionLabel(text: "If something looks wrong")

                Button {
                    coordinator.emergencyRestore()
                    delegate?.refreshStatusIcon()
                    model.note = "Every display is back to its normal output."
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: "arrow.counterclockwise.circle.fill")
                            .foregroundStyle(Palette.accent)
                        VStack(alignment: .leading, spacing: 1) {
                            Text("Restore normal output now").font(.daylightBody)
                            Text("Also \(GlobalHotKey.restore.description), from anywhere, at any time")
                                .font(.system(size: 10)).foregroundStyle(Palette.secondaryText)
                        }
                        Spacer()
                    }
                    .padding(10)
                    .background(RoundedRectangle(cornerRadius: Metrics.cornerRadius, style: .continuous)
                        .fill(Palette.accentSoft))
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityHint("Returns every display to its normal output immediately")

                if let note = model.note {
                    NoticeBanner(kind: .info, message: note,
                                 action: ("Dismiss", { model.note = nil }))
                }

                ForEach(entries, id: \.symptom) { entry in
                    TroubleshootingRow(
                        entry: entry,
                        isExpanded: model.expanded == entry.symptom,
                        onToggle: {
                            withAnimation(Motion.reveal(coordinator.settings)) {
                                model.expanded = model.expanded == entry.symptom ? nil : entry.symptom
                            }
                        })
                }
            }
        }
    }

    struct Entry {
        var symptom: String
        var answer: String
        var action: (title: String, run: () -> Void)?
    }

    private var entries: [Entry] {
        [
            Entry(symptom: "The colour keeps flipping between two settings",
                  answer: conflictAnswer,
                  action: coordinator.conflicts.isEmpty ? nil
                      : ("Turn Daylight's automation off", {
                            coordinator.setAutomation(enabled: false)
                            delegate?.refreshStatusIcon()
                            model.note = "Automation is off. Turn it back on above once the other app is closed."
                        })),

            Entry(symptom: "Nothing is happening at all",
                  answer: nothingHappeningAnswer,
                  action: ("Show me what Daylight thinks", {
                      model.note = engineSummary
                  })),

            Entry(symptom: "It will not get dark enough",
                  answer: """
                  What Daylight calls brightness is software dimming: it lowers the values sent to the panel. It cannot go below what your backlight is already producing, because no application can change a Mac's backlight — macOS provides no public way to do it.

                  For a genuinely darker screen, turn your display's own brightness down as well. Daylight's dimming then works on top of that. There is also a floor at \(Int(SoftwareDimming.safeFloor * 100))% so the screen cannot be made unusable by accident.
                  """,
                  action: nil),

            Entry(symptom: "My schedule seems to be an hour out",
                  answer: """
                  Schedules follow the clock, not elapsed time, so a step set for 19:00 stays at 19:00 across a daylight-saving change. If everything looks shifted by exactly an hour, the Mac's time zone is usually the cause — check System Settings › General › Date & Time.

                  If you have set a location for sunrise and sunset, and that place keeps a different clock from this Mac, Daylight says so on the Schedule tab.
                  """,
                  action: ("Open Schedule", { model.note = "Choose Schedule in the sidebar to check your location." })),

            Entry(symptom: "Daylight quit unexpectedly",
                  answer: """
                  Your display goes back to normal on its own. macOS owns the colour table that Daylight sets and restores it whenever the app's process ends — including if it is force quit or crashes. This was tested directly rather than assumed.

                  What macOS cannot do is put your schedule back, so start Daylight again when convenient. Your settings are on disk and are written whole or not at all, so a crash cannot leave them half-saved.
                  """,
                  action: nil),

            Entry(symptom: "A display is not listed, or says it is not supported",
                  answer: """
                  Daylight can only adjust a display that exposes a colour transfer table. Most do; some adapters, capture devices and virtual displays do not, and for those it will say so rather than pretend.

                  Unplugging and reconnecting usually helps. Settings are remembered per display by a durable identity, so reconnecting the same monitor brings its settings back rather than treating it as new.
                  """,
                  action: ("Re-check my displays", {
                      coordinator.refreshHardwareBrightnessSupport()
                      model.note = "Displays re-checked. See the Displays tab for what each one reports."
                  })),

            Entry(symptom: "I want to start over",
                  answer: """
                  Resetting returns every schedule, mode, rule and display setting to the way it arrived. It does not touch your displays, and nothing is sent anywhere.

                  If you would rather keep a copy first, export your settings from the section above — it is a single readable file.
                  """,
                  action: ("Reset everything", {
                      var fresh = Presets.defaultSettings()
                      fresh.hasCompletedOnboarding = true
                      coordinator.settings = fresh
                      coordinator.rebuildTimeline()
                      model.note = "Settings reset to defaults."
                  })),
        ]
    }

    private var conflictAnswer: String {
        let base = """
        Another application is almost certainly adjusting the same display. f.lux, Night Shift and similar tools write to the same colour table Daylight does, and whichever wrote most recently wins — so the two take turns and the screen flickers between them.

        Only one of them can run at a time. Daylight will not disable another app for you, and it will not fight one.
        """
        guard !coordinator.conflicts.isEmpty else {
            return base + "\n\nNothing is competing for your displays at the moment."
        }
        let names = coordinator.conflicts.map(\.displayName).joined(separator: ", ")
        return base + "\n\nDaylight is seeing this right now on: \(names)."
    }

    private var nothingHappeningAnswer: String {
        var reasons: [String] = []
        if !coordinator.settings.automationEnabled { reasons.append("automation is switched off") }
        if coordinator.pause != nil { reasons.append("Daylight is paused") }
        let excluded = coordinator.displayStatuses.filter(\.isExcluded)
        if !excluded.isEmpty {
            reasons.append("\(excluded.map(\.name).joined(separator: " and ")) is set to be left alone")
        }
        if coordinator.displayStatuses.isEmpty { reasons.append("no displays were detected") }

        let head = reasons.isEmpty
            ? "Nothing obvious is stopping it: automation is on, nothing is paused, and your displays are being managed."
            : "Right now: \(reasons.joined(separator: ", "))."
        return head + """


        The usual causes are automation being off, a pause still running, a mode that holds a neutral setting, or a display set to be left alone in the Displays tab.

        Daylight also does nothing visible in the middle of the day if your schedule asks for a neutral setting then — which is normal, not a fault.
        """
    }

    private var engineSummary: String {
        let t = coordinator.outcome.target
        let displays = coordinator.displayStatuses
            .map { "\($0.name): \(Format.kelvin($0.appliedTarget.temperature)), \($0.confidence.shortLabel.lowercased())" }
            .joined(separator: " · ")
        return "\(coordinator.outcome.explanation) Target \(Format.kelvin(t.temperature)) at \(Format.percent(t.dimming.factor)). \(displays.isEmpty ? "No displays." : displays)"
    }
}

struct TroubleshootingRow: View {
    let entry: TroubleshootingCard.Entry
    let isExpanded: Bool
    let onToggle: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Button(action: onToggle) {
                HStack(spacing: 8) {
                    Image(systemName: isExpanded ? "chevron.down" : "chevron.right")
                        .font(.system(size: 9))
                        .foregroundStyle(Palette.secondaryText)
                        .frame(width: 10)
                        .accessibilityHidden(true)
                    Text(entry.symptom).font(.daylightBody)
                    Spacer()
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityAddTraits(isExpanded ? [.isSelected] : [])
            .accessibilityHint(isExpanded ? "Collapse" : "Expand")

            if isExpanded {
                VStack(alignment: .leading, spacing: 8) {
                    Text(entry.answer)
                        .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                        .fixedSize(horizontal: false, vertical: true)
                    if let action = entry.action {
                        Button(action.title, action: action.run).controlSize(.small)
                    }
                }
                .padding(.leading, 18)
                .transition(.opacity)
            }
        }
        .padding(.vertical, 2)
    }
}
