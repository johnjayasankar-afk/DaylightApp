import SwiftUI
import DaylightCore
import DaylightDisplay

final class PaletteModel: ObservableObject {
    @Published var query = ""
    @Published var selection = 0
}

/// A searchable list of everything Daylight can be told to do.
///
/// Every entry here maps to something the menu bar can already do — it is a
/// faster route, not a second set of features that could drift out of step.
struct CommandPaletteView: View {
    @ObservedObject var coordinator: LightingCoordinator
    let onRun: () -> Void
    @StateObject private var model = PaletteModel()
    @FocusState private var searchFocused: Bool

    private var entries: [(command: Command, run: () -> Void)] {
        var out: [(Command, () -> Void)] = []

        out.append((Command(id: "resume", title: "Resume automatic mode",
                            keywords: ["continue", "auto", "unpause"],
                            subtitle: "Cancel any pause or manual change",
                            symbolName: "play.circle"),
                    { coordinator.resumeAutomation() }))
        for minutes in [15, 30, 60] {
            out.append((Command(id: "pause\(minutes)",
                                title: "Pause for \(minutes) minutes",
                                keywords: ["stop", "off", "hold"],
                                symbolName: "pause.circle"),
                        { coordinator.pauseAutomation(for: Double(minutes) * 60) }))
        }
        out.append((Command(id: "restore", title: "Restore normal output",
                            keywords: ["reset", "undo", "neutral", "emergency"],
                            subtitle: DaylightUI.Shortcuts.restore.description,
                            symbolName: "arrow.counterclockwise"),
                    { coordinator.emergencyRestore() }))

        for profile in coordinator.settings.profiles {
            out.append((Command(id: "profile-\(profile.id)", title: profile.name,
                                keywords: ["mode", "profile"],
                                subtitle: profile.summary,
                                symbolName: profile.symbolName),
                        { coordinator.applyProfile(profile, expiry: .untilNextScheduleChange) }))
        }

        out.append((Command(id: "warmer", title: "Warm the display a little",
                            keywords: ["warmth", "warmer", "orange"],
                            symbolName: "thermometer.sun"),
                    { nudgeWarmth(by: -400) }))
        out.append((Command(id: "cooler", title: "Cool the display a little",
                            keywords: ["cooler", "neutral", "blue"],
                            symbolName: "thermometer.snowflake"),
                    { nudgeWarmth(by: 400) }))

        for schedule in coordinator.settings.schedules {
            out.append((Command(id: "schedule-\(schedule.id)",
                                title: "Switch to \(schedule.name)",
                                keywords: ["schedule"],
                                symbolName: "calendar"),
                        { coordinator.settings.activeScheduleID = schedule.id }))
        }

        if coordinator.settings.breakReminders.isEnabled {
            out.append((Command(id: "snooze", title: "Snooze break reminders",
                                keywords: ["break", "quiet"],
                                symbolName: "bell.slash"),
                        { coordinator.snoozeBreakReminder() }))
        }
        return out.map { (command: $0.0, run: $0.1) }
    }

    private var results: [(command: Command, run: () -> Void)] {
        let ranked = CommandMatcher.rank(entries.map(\.command), query: model.query)
        return ranked.compactMap { c in entries.first { $0.command.id == c.id } }
    }

    private func nudgeWarmth(by delta: Double) {
        let range = coordinator.settings.advancedWarmthRange
            ? ColourTemperature.advancedRange : ColourTemperature.normalRange
        let current = coordinator.outcome.target.temperature.kelvin
        let next = min(max(current + delta, range.lowerBound), range.upperBound)
        coordinator.setManualTarget(temperature: ColourTemperature(kelvin: next),
                                    expiry: .untilNextScheduleChange)
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 8) {
                Image(systemName: "magnifyingglass")
                    .foregroundStyle(Palette.secondaryText)
                    .accessibilityHidden(true)
                TextField("What would you like Daylight to do?", text: $model.query)
                    .textFieldStyle(.plain)
                    .font(.system(size: 15))
                    .focused($searchFocused)
                    .onSubmit(runSelected)
                    .accessibilityLabel("Search commands")
            }
            .padding(.horizontal, 14).padding(.vertical, 12)

            Divider()

            if results.isEmpty {
                Text("Nothing matches “\(model.query)”.")
                    .font(.daylightBody).foregroundStyle(Palette.secondaryText)
                    .padding(20)
            } else {
                ScrollView {
                    LazyVStack(spacing: 0) {
                        ForEach(Array(results.enumerated()), id: \.element.command.id) { index, entry in
                            Button {
                                entry.run(); onRun()
                            } label: {
                                HStack(spacing: 10) {
                                    Image(systemName: entry.command.symbolName)
                                        .frame(width: 18)
                                        .foregroundStyle(Palette.secondaryText)
                                    VStack(alignment: .leading, spacing: 1) {
                                        Text(entry.command.title).font(.daylightBody)
                                        if let sub = entry.command.subtitle {
                                            Text(sub).font(.system(size: 10))
                                                .foregroundStyle(Palette.secondaryText)
                                                .lineLimit(1)
                                        }
                                    }
                                    Spacer()
                                }
                                .padding(.horizontal, 14).padding(.vertical, 7)
                                .background(index == model.selection
                                            ? Palette.accentSoft : Color.clear)
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            .accessibilityLabel(entry.command.title)
                            .accessibilityHint(entry.command.subtitle ?? "")
                        }
                    }
                }
                .frame(maxHeight: 320)
            }
        }
        .frame(width: 460)
        .background(Palette.raised)
        .onAppear { searchFocused = true }
        .onChange(of: model.query) { _, _ in model.selection = 0 }
        .onKeyPress(.downArrow) { move(1); return .handled }
        .onKeyPress(.upArrow) { move(-1); return .handled }
        .onKeyPress(.escape) { onRun(); return .handled }
    }

    private func move(_ delta: Int) {
        guard !results.isEmpty else { return }
        model.selection = min(max(model.selection + delta, 0), results.count - 1)
    }

    private func runSelected() {
        guard results.indices.contains(model.selection) else { return }
        results[model.selection].run()
        onRun()
    }
}

/// The break reminder itself.
///
/// Small, quiet, dismissible, and deliberately dark so it does not flash a
/// bright panel at someone working late. It never blocks anything.
struct BreakReminderView: View {
    let message: String
    let onSnooze: () -> Void
    let onDismiss: () -> Void

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: "cup.and.saucer")
                .font(.system(size: 16))
                .foregroundStyle(Palette.accent)
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 8) {
                Text(message)
                    .font(.system(size: 13))
                    .fixedSize(horizontal: false, vertical: true)
                HStack(spacing: 8) {
                    Button("Snooze", action: onSnooze)
                    Button("Dismiss", action: onDismiss)
                        .keyboardShortcut(.defaultAction)
                }
                .controlSize(.small)
            }
        }
        .padding(16)
        .frame(width: 300, alignment: .leading)
        .background(Palette.raised)
        .accessibilityElement(children: .contain)
        .accessibilityLabel("Break reminder. \(message)")
    }
}
