import SwiftUI
import DaylightCore
import DaylightDisplay

final class OnboardingModel: ObservableObject {
    @Published var step = 0
    @Published var presetName = "Balanced"
    @Published var wakeHour = 7.0
    @Published var bedHour = 23.0
    @Published var usesRoutine = true
    @Published var launchAtLogin = false
    @Published var previewRunning = false
    @Published var previewCountdown = 0
    private var timer: Timer?

    let steps = ["Welcome", "Your displays", "Your day", "How warm", "Ready"]

    func runPreview(seconds: Int, onEnd: @escaping () -> Void) {
        timer?.invalidate()
        previewRunning = true
        previewCountdown = seconds
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] t in
            guard let self else { return }
            self.previewCountdown -= 1
            if self.previewCountdown <= 0 {
                t.invalidate(); self.timer = nil
                self.previewRunning = false
                onEnd()
            }
        }
    }
    func cancelPreview(onEnd: @escaping () -> Void) {
        timer?.invalidate(); timer = nil
        guard previewRunning else { return }
        previewRunning = false
        previewCountdown = 0
        onEnd()
    }
    deinit { timer?.invalidate() }
}

struct OnboardingView: View {
    @ObservedObject var coordinator: LightingCoordinator
    weak var delegate: AppCommands?
    var initialStep: Int = 0
    @StateObject private var model = OnboardingModel()

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            progress
            Divider()
            ScrollView {
                Group {
                    switch model.step {
                    case 0: welcome
                    case 1: displays
                    case 2: routine
                    case 3: warmth
                    default: ready
                    }
                }
                .padding(26)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            Divider()
            footer
        }
        .frame(width: 640, height: 560)
        .background(Palette.surface)
        // Whatever happens — cancel, error, closing the window — the display
        // must not be left holding a preview value.
        .onAppear { if initialStep != 0 && model.step == 0 { model.step = initialStep } }
        .onDisappear { model.cancelPreview { coordinator.cancelPreview() } }
    }

    private var progress: some View {
        HStack(spacing: 6) {
            ForEach(Array(model.steps.enumerated()), id: \.offset) { index, name in
                HStack(spacing: 5) {
                    Circle()
                        .fill(index <= model.step ? Palette.accent : Palette.hairline)
                        .frame(width: 6, height: 6)
                    Text(name)
                        .font(.system(size: 11))
                        .foregroundStyle(index == model.step ? Palette.primaryText : Palette.tertiaryText)
                }
                if index < model.steps.count - 1 {
                    Rectangle().fill(Palette.hairline).frame(height: 1).frame(maxWidth: 20)
                }
            }
            Spacer()
        }
        .padding(.horizontal, 26).padding(.vertical, 14)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Step \(model.step + 1) of \(model.steps.count): \(model.steps[model.step])")
    }

    // MARK: Steps

    private var welcome: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(Branding.productName).font(.system(size: 30, weight: .medium, design: .rounded))
            Text(Branding.tagline).font(.system(size: 17)).foregroundStyle(Palette.secondaryText)
            Text("""
            Daylight gradually shifts your screen towards warmer, gentler settings as the evening goes on, and back again in the morning. You can change it whenever you like, and pause or undo it instantly.

            It works entirely on this Mac. No account, no network, no location permission — if you want it to follow the sun, you pick the place yourself.
            """)
            .font(.daylightBody).foregroundStyle(Palette.secondaryText)
            .fixedSize(horizontal: false, vertical: true)

            VStack(alignment: .leading, spacing: 6) {
                Text("A typical day").font(.daylightSectionLabel).kerning(0.6)
                    .foregroundStyle(Palette.secondaryText)
                TimelineStrip(timeline: previewTimeline)
                HStack {
                    Text("12 AM"); Spacer(); Text("Noon"); Spacer(); Text("12 AM")
                }
                .font(.system(size: 9)).foregroundStyle(Palette.tertiaryText)
            }

            NoticeBanner(kind: .info, message: "Daylight is about comfort and routine. It does not make medical claims about your eyes or your sleep.")
            Spacer(minLength: 0)
        }
    }

    private var previewTimeline: Timeline {
        ScheduleResolver.timeline(for: presetSchedule(), on: Date(),
                                  timeZone: coordinator.timeZone,
                                  location: coordinator.settings.location)
    }

    /// The schedule as the current answers would build it — the same function
    /// `apply()` uses, so the preview cannot drift from what gets saved.
    private var shapedTimeline: Timeline {
        ScheduleResolver.timeline(for: shapedSchedule(), on: Date(),
                                  timeZone: coordinator.timeZone,
                                  location: coordinator.settings.location)
    }

    private var displays: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Your displays").font(.system(size: 22, weight: .medium))
            Text("Here is what Daylight found, and what it can actually control on each one.")
                .font(.daylightBody).foregroundStyle(Palette.secondaryText)
            ForEach(coordinator.displayStatuses) { d in
                Card(padding: 14) {
                    VStack(alignment: .leading, spacing: 6) {
                        HStack(spacing: 8) {
                            Image(systemName: d.isBuiltIn ? "laptopcomputer" : "display")
                                .foregroundStyle(Palette.secondaryText)
                            Text(d.name).font(.daylightTitle)
                            Spacer()
                            Text(d.connection.displayName).font(.daylightCaption)
                                .foregroundStyle(Palette.secondaryText)
                        }
                        FactRow(label: "Warmth and dimming",
                                value: d.capabilities.supportsColourTransform ? "Supported" : "Not supported",
                                tone: d.capabilities.supportsColourTransform ? .positive : .warning)
                        FactRow(label: "Backlight brightness", value: "Not available",
                                detail: "No public macOS API lets an app change this")
                    }
                }
            }
            if coordinator.displayStatuses.isEmpty {
                NoticeBanner(kind: .warning, message: "No displays were detected yet. Daylight will pick them up as soon as one appears.")
            }
        }
    }

    private var routine: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Your day").font(.system(size: 22, weight: .medium))
            Text("Daylight can follow the clock, or follow the sun where you are. You can change this later, and mix the two.")
                .font(.daylightBody).foregroundStyle(Palette.secondaryText)
                .fixedSize(horizontal: false, vertical: true)

            Picker("", selection: $model.usesRoutine) {
                Text("Follow my routine").tag(true)
                Text("Follow the sun").tag(false)
            }
            .pickerStyle(.segmented).labelsHidden().frame(width: 320)

            if model.usesRoutine {
                VStack(alignment: .leading, spacing: 12) {
                    hourSlider("I usually wake up around", value: $model.wakeHour)
                    hourSlider("I usually go to bed around", value: $model.bedHour)

                    // The curve updates as the sliders move, so the answer to
                    // "what am I actually setting up?" is on screen throughout.
                    VStack(alignment: .leading, spacing: 5) {
                        Text("Your day would look like this")
                            .font(.daylightSectionLabel).kerning(0.6)
                            .foregroundStyle(Palette.secondaryText)
                        TimelineStrip(timeline: shapedTimeline, height: 48)
                        HStack {
                            Text("12 AM"); Spacer(); Text("Noon"); Spacer(); Text("12 AM")
                        }
                        .font(.system(size: 9)).foregroundStyle(Palette.tertiaryText)
                    }
                    .animation(Motion.settle(coordinator.settings), value: model.wakeHour)
                    .animation(Motion.settle(coordinator.settings), value: model.bedHour)

                    Text("Daylight will be at its brightest during your day and reach its warmest setting by bedtime. Nothing here assumes you sleep at night — set the times you actually keep.")
                        .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                        .fixedSize(horizontal: false, vertical: true)
                }
            } else {
                VStack(alignment: .leading, spacing: 8) {
                    NoticeBanner(kind: .info, message: "Pick your place on the Schedule tab once setup is done — there is a list built in, so there are no coordinates to look up. Until then Daylight uses sensible fallback times, and nothing breaks if you skip it.")
                    if let suggestion = Cities.suggestion(forTimeZone: coordinator.timeZone.identifier) {
                        Text("Your time zone suggests \(suggestion.label). Daylight will offer that later for you to confirm; it does not assume it.")
                            .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
            }
        }
    }

    private func hourSlider(_ title: String, value: Binding<Double>) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            HStack {
                Text(title).font(.daylightBody)
                Spacer()
                Text(clockString(value.wrappedValue * 3600))
                    .font(.system(size: 13, design: .rounded)).monospacedDigit()
            }
            Slider(value: value, in: 0...23.5, step: 0.5)
                .accessibilityLabel(title)
                .accessibilityValue(clockString(value.wrappedValue * 3600))
        }
    }

    private var warmth: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("How warm").font(.system(size: 22, weight: .medium))
            Text("A starting point, not a recommendation. Every one of these is fully editable afterwards.")
                .font(.daylightBody).foregroundStyle(Palette.secondaryText)

            ForEach(["Subtle", "Balanced", "Extra Warm"], id: \.self) { name in
                Button {
                    model.presetName = name
                } label: {
                    HStack(spacing: 12) {
                        Image(systemName: model.presetName == name ? "largecircle.fill.circle" : "circle")
                            .foregroundStyle(model.presetName == name ? Palette.accent : Palette.tertiaryText)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(name).font(.daylightTitle)
                            Text(presetDescription(name))
                                .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                        }
                        Spacer()
                    }
                    .padding(12)
                    .background(RoundedRectangle(cornerRadius: 9, style: .continuous)
                        .fill(model.presetName == name ? Palette.accentSoft : Color.primary.opacity(0.03)))
                    .overlay(RoundedRectangle(cornerRadius: 9, style: .continuous)
                        .strokeBorder(model.presetName == name ? Palette.accent.opacity(0.5) : Palette.hairline))
                }
                .buttonStyle(.plain)
                .accessibilityAddTraits(model.presetName == name ? [.isSelected] : [])
            }

            VStack(alignment: .leading, spacing: 5) {
                Text("Your day with \(model.presetName)")
                    .font(.daylightSectionLabel).kerning(0.6)
                    .foregroundStyle(Palette.secondaryText)
                TimelineStrip(timeline: shapedTimeline, height: 48)
                HStack {
                    Text("12 AM"); Spacer(); Text("Noon"); Spacer(); Text("12 AM")
                }
                .font(.system(size: 9)).foregroundStyle(Palette.tertiaryText)
            }
            .animation(Motion.settle(coordinator.settings), value: model.presetName)

            HStack(spacing: 10) {
                if model.previewRunning {
                    Button("Stop preview") { stopPreview() }
                    Text("Showing your evening setting for \(model.previewCountdown)s")
                        .font(.daylightCaption).foregroundStyle(Palette.accent).monospacedDigit()
                } else {
                    Button("Preview on my display for 5 seconds") { startPreview() }
                }
                Spacer()
            }
            Text("The preview changes your real display briefly, then puts it back on its own.")
                .font(.system(size: 10)).foregroundStyle(Palette.tertiaryText)
        }
    }

    private func presetDescription(_ name: String) -> String {
        switch name {
        case "Subtle": return "A gentle shift. Barely noticeable during the day, mildly warm at night."
        case "Extra Warm": return "A pronounced shift, quite warm and dim late in the evening."
        default: return "A moderate shift towards warmer, dimmer evenings."
        }
    }

    private func startPreview() {
        let schedule = presetSchedule()
        let evening = schedule.weekdayAnchors.last?.target ?? .neutral
        coordinator.startPreview(label: "Setup preview", target: evening, seconds: 5.5)
        model.runPreview(seconds: 5) { coordinator.cancelPreview() }
    }

    private func stopPreview() {
        model.cancelPreview { coordinator.cancelPreview() }
        coordinator.cancelPreview()
    }

    private var ready: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("You're set").font(.system(size: 22, weight: .medium))
            Text("Daylight lives in your menu bar. Click the icon for warmth and brightness, modes, and a pause button.")
                .font(.daylightBody).foregroundStyle(Palette.secondaryText)
                .fixedSize(horizontal: false, vertical: true)

            Card(padding: 14) {
                VStack(alignment: .leading, spacing: 8) {
                    FactRow(label: "Schedule", value: model.presetName)
                    if model.usesRoutine {
                        FactRow(label: "Your day",
                                value: "\(clockString(model.wakeHour * 3600)) – \(clockString(model.bedHour * 3600))")
                    }
                    FactRow(label: "Restore shortcut", value: GlobalHotKey.restore.description,
                            detail: "Works anywhere, any time")
                }
            }

            Toggle("Start Daylight when I log in", isOn: $model.launchAtLogin)
                .toggleStyle(.checkbox)

            Text("Closing the main window keeps Daylight running in the menu bar. Quitting it restores your displays.")
                .font(.daylightCaption).foregroundStyle(Palette.tertiaryText)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    // MARK: Footer

    private var footer: some View {
        HStack {
            if model.step > 0 {
                Button("Back") { model.step -= 1 }
            }
            Spacer()
            Button(model.step == model.steps.count - 1 ? "Start using \(Branding.productName)" : "Continue") {
                advance()
            }
            .keyboardShortcut(.defaultAction)
        }
        .padding(.horizontal, 26).padding(.vertical, 14)
    }

    private func advance() {
        stopPreview()
        if model.step < model.steps.count - 1 {
            model.step += 1
            return
        }
        apply()
        delegate?.finishOnboarding()
    }

    private func presetSchedule() -> Schedule {
        switch model.presetName {
        case "Subtle": return Presets.subtle()
        case "Extra Warm": return Presets.extraWarm()
        default: return Presets.balanced()
        }
    }

    /// Turn the answers into a real schedule.
    ///
    /// Used both to draw the previews and to save, so what is shown during
    /// setup is exactly what ends up in the Schedule tab afterwards.
    private func shapedSchedule() -> Schedule {
        var schedule = model.usesRoutine ? presetSchedule() : Presets.solar()
        guard model.usesRoutine else {
            schedule.name = "Follow the sun"
            return schedule
        }
        let wake = Int(model.wakeHour * 3600)
        let bed = Int(model.bedHour * 3600)
        // Space the day's anchors around the stated routine rather than leaving
        // the preset's generic times in place.
        let windDown = bed - 2 * 3600
        for i in schedule.weekdayAnchors.indices {
            switch schedule.weekdayAnchors[i].name {
            case "Morning":   schedule.weekdayAnchors[i].time = .clock(secondsFromMidnight: max(0, wake))
            case "Day":       schedule.weekdayAnchors[i].time = .clock(secondsFromMidnight: min(86_340, wake + 9000))
            case "Wind down": schedule.weekdayAnchors[i].time = .clock(secondsFromMidnight: (windDown + 86_400) % 86_400)
            case "Night":     schedule.weekdayAnchors[i].time = .clock(secondsFromMidnight: bed % 86_400)
            default: break
            }
        }
        schedule.name = model.presetName
        return schedule
    }

    private func apply() {
        var settings = coordinator.settings
        let schedule = shapedSchedule()
        settings.schedules = [schedule] + Presets.all().filter { $0.name != schedule.name }
        settings.activeScheduleID = schedule.id
        settings.hasCompletedOnboarding = true
        settings.launchAtLogin = model.launchAtLogin
        coordinator.settings = settings
        coordinator.rebuildTimeline()

        if model.launchAtLogin { _ = delegate?.setLaunchAtLogin(true) }
    }
}
