import SwiftUI
import DaylightCore
import DaylightDisplay

enum ManualDuration: String, CaseIterable, Identifiable {
    case fifteen = "15 minutes"
    case thirty = "30 minutes"
    case hour = "1 hour"
    case untilNextChange = "Until the next change"
    case untilResumed = "Until I resume"
    var id: String { rawValue }

    var expiry: OverrideExpiry {
        switch self {
        case .fifteen:         return .duration(15 * 60)
        case .thirty:          return .duration(30 * 60)
        case .hour:            return .duration(3600)
        case .untilNextChange: return .untilNextScheduleChange
        case .untilResumed:    return .untilResumed
        }
    }
}

final class MenuBarModel: ObservableObject {
    @Published var warmth: Double = 6500
    @Published var dimming: Double = 1.0
    @Published var duration: ManualDuration = .untilNextChange
    @Published var isDragging = false
    @Published var scope: OverrideScope = .allDisplays
    let debouncer = Debouncer(interval: 1.0 / 30.0)
}

/// The compact control surface. A first-class product rather than a shortcut
/// into the "real" app: everything done daily is here, one or two interactions
/// deep.
struct MenuBarView: View {
    static let width: CGFloat = 324

    @ObservedObject var coordinator: LightingCoordinator
    weak var delegate: AppCommands?
    @StateObject private var model = MenuBarModel()

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            header
            Divider().padding(.vertical, 8)
            controls
            Divider().padding(.vertical, 8)
            profiles
            Divider().padding(.vertical, 8)
            footer
        }
        .padding(14)
        .frame(width: Self.width)
        .onAppear(perform: sync)
        .onReceive(coordinator.$outcome) { _ in if !model.isDragging { sync() } }
    }

    // MARK: Header

    private var header: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .firstTextBaseline) {
                Text(statusTitle).font(.system(size: 15, weight: .semibold))
                Spacer()
                Toggle("", isOn: Binding(
                    get: { coordinator.settings.automationEnabled },
                    set: { coordinator.setAutomation(enabled: $0); delegate?.refreshStatusIcon() }))
                    .toggleStyle(.switch).controlSize(.mini).labelsHidden()
                    .accessibilityLabel("Automation")
            }
            Text(coordinator.outcome.explanation)
                .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                .fixedSize(horizontal: false, vertical: true)
            if let next = nextChangeSentence {
                Text(next).font(.daylightCaption).foregroundStyle(Palette.secondaryText)
            }
            if let override = coordinator.activeOverride {
                Text(override.statusSentence(now: Date(),
                                             nextScheduleChange: coordinator.evaluation.nextChangeAt,
                                             formatter: Format.timeOfDay))
                    .font(.daylightCaption).foregroundStyle(Palette.accent)
                    .fixedSize(horizontal: false, vertical: true)
            }
            ForEach(coordinator.conflicts) { c in
                Text(c.message).font(.daylightCaption).foregroundStyle(Palette.warning)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private var statusTitle: String {
        if !coordinator.settings.automationEnabled { return "Automation off" }
        if coordinator.pause != nil { return "Paused" }
        return "\(Format.partOfDay(nowSeconds)) · about \(Format.kelvin(coordinator.outcome.target.temperature))"
    }

    private var nowSeconds: Double { Timeline.wallClockSeconds(of: Date(), in: coordinator.timeZone) }

    private var nextChangeSentence: String? {
        guard coordinator.settings.automationEnabled, coordinator.pause == nil,
              let next = coordinator.evaluation.nextChangeAt else { return nil }
        let when = Format.timeOfDay.string(from: next)
        if let name = coordinator.evaluation.nextAnchor?.anchor.name { return "Next: \(name) at \(when)" }
        return "Next change at \(when)"
    }

    // MARK: Controls

    /// Only shown when there is a genuine choice to make. A picker with one
    /// option is clutter.
    @ViewBuilder
    private var scopePicker: some View {
        let displays = coordinator.displayStatuses
        let groups = coordinator.settings.groups
        if displays.count > 1 {
            HStack(spacing: 8) {
                Text("Applies to").font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                Picker("", selection: Binding(
                    get: { model.scope },
                    set: { model.scope = $0; push() })) {
                    Text("All displays").tag(OverrideScope.allDisplays)
                    ForEach(groups) { g in
                        Text(g.name).tag(OverrideScope.group(id: g.id))
                    }
                    ForEach(displays) { d in
                        Text(d.name).tag(OverrideScope.display(key: d.id))
                    }
                }
                .labelsHidden().controlSize(.small)
                .accessibilityLabel("Which displays manual changes apply to")
            }
        }
    }

    private var controls: some View {
        VStack(alignment: .leading, spacing: 12) {
            scopePicker

            // Bound as "amount of warmth" so dragging right gets warmer, which
            // is what the labels say and what people reach for. Kelvin is still
            // the number on display, because that is the value people compare.
            sliderRow(title: "Warmth",
                      value: Binding(
                        get: { warmthFraction(model.warmth) },
                        set: { model.warmth = kelvin(fromFraction: $0); push() }),
                      range: 0...1,
                      display: Format.kelvin(ColourTemperature(kelvin: model.warmth)),
                      lowLabel: "Neutral", highLabel: "Warm",
                      accessibilityValue: Format.kelvin(ColourTemperature(kelvin: model.warmth)))

            sliderRow(title: "Brightness",
                      value: Binding(get: { model.dimming }, set: { model.dimming = $0; push() }),
                      range: SoftwareDimming.range,
                      display: Format.percent(model.dimming),
                      lowLabel: "Dim", highLabel: "Full",
                      accessibilityValue: "\(Int(model.dimming * 100)) percent")

            Text("Brightness here is software dimming, not your display's backlight.")
                .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                .fixedSize(horizontal: false, vertical: true)

            HStack(spacing: 8) {
                Text("Lasts").font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                Picker("", selection: $model.duration) {
                    ForEach(ManualDuration.allCases) { Text($0.rawValue).tag($0) }
                }
                .labelsHidden().controlSize(.small)
                .accessibilityLabel("How long manual changes last")
            }
        }
    }

    @ViewBuilder
    private func sliderRow(title: String, value: Binding<Double>, range: ClosedRange<Double>,
                           display: String, lowLabel: String, highLabel: String,
                           accessibilityValue: String) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            HStack {
                Text(title).font(.daylightBody)
                Spacer()
                Text(display).font(.system(size: 12, design: .rounded)).monospacedDigit()
                    .foregroundStyle(Palette.secondaryText)
            }
            Slider(value: value, in: range) { model.isDragging = $0 }
                .controlSize(.small)
                .accessibilityLabel(title)
                .accessibilityValue(accessibilityValue)
            HStack {
                Text(lowLabel); Spacer(); Text(highLabel)
            }
            .font(.system(size: 9)).foregroundStyle(Palette.tertiaryText)
            .accessibilityHidden(true)
        }
    }

    private var warmthRange: ClosedRange<Double> {
        coordinator.settings.advancedWarmthRange
            ? ColourTemperature.advancedRange : ColourTemperature.normalRange
    }

    private func warmthFraction(_ kelvin: Double) -> Double {
        let r = warmthRange
        return min(max((r.upperBound - kelvin) / (r.upperBound - r.lowerBound), 0), 1)
    }
    private func kelvin(fromFraction f: Double) -> Double {
        let r = warmthRange
        return r.upperBound - f * (r.upperBound - r.lowerBound)
    }

    /// Drags are coalesced so a fast slider sweep does not queue hundreds of
    /// hardware writes.
    private func push() {
        model.debouncer.submit {
            coordinator.setManualTarget(temperature: ColourTemperature(kelvin: model.warmth),
                                        dimming: SoftwareDimming(factor: model.dimming),
                                        expiry: model.duration.expiry,
                                        scope: model.scope)
            delegate?.refreshStatusIcon()
        }
    }

    private func sync() {
        model.warmth = coordinator.outcome.target.temperature.kelvin
        model.dimming = coordinator.outcome.target.dimming.factor
    }

    // MARK: Modes

    private var profiles: some View {
        VStack(alignment: .leading, spacing: 7) {
            SectionLabel(text: "Modes")
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 92), spacing: 6)], spacing: 6) {
                ForEach(coordinator.settings.profiles) { profile in
                    Button {
                        coordinator.applyProfile(profile, expiry: model.duration.expiry,
                                                 scope: model.scope)
                        delegate?.refreshStatusIcon()
                    } label: {
                        HStack(spacing: 4) {
                            Image(systemName: profile.symbolName).font(.system(size: 10))
                            Text(profile.name).font(.system(size: 11)).lineLimit(1)
                        }
                        .frame(maxWidth: .infinity).padding(.vertical, 5)
                        .background(RoundedRectangle(cornerRadius: 7, style: .continuous)
                            .fill(isActive(profile) ? Palette.accentSoft : Color.primary.opacity(0.05)))
                        .overlay(RoundedRectangle(cornerRadius: 7, style: .continuous)
                            .strokeBorder(isActive(profile) ? Palette.accent.opacity(0.55) : .clear))
                    }
                    .buttonStyle(.plain)
                    .help(profile.summary)
                    .accessibilityLabel("\(profile.name). \(profile.summary)")
                    .accessibilityAddTraits(isActive(profile) ? [.isSelected] : [])
                }
            }
        }
    }

    private func isActive(_ p: Profile) -> Bool { coordinator.activeOverride?.label == p.name }

    // MARK: Footer

    /// A two-by-two grid of equal buttons.
    ///
    /// `Menu` and `Button` size themselves differently, so the column width is
    /// stated rather than inferred — otherwise the second row does not line up
    /// with the first, which is exactly the sort of thing that makes an
    /// otherwise careful panel look unfinished.
    private var footer: some View {
        let column = (Self.width - 28 - 6) / 2
        return VStack(spacing: 6) {
            HStack(spacing: 6) {
                if coordinator.pause == nil {
                    Menu {
                        Button("For 15 minutes") { pause(15 * 60) }
                        Button("For 30 minutes") { pause(30 * 60) }
                        Button("For 1 hour") { pause(3600) }
                        Button("Until I resume") { pause(nil) }
                    } label: {
                        // Centred like the buttons beside it; a menu's label is
                        // leading-aligned unless told otherwise.
                        Text("Pause…").frame(maxWidth: .infinity)
                    }
                    .menuIndicator(.hidden)
                    .frame(width: column)
                    .help("Hold the current output and stop following the schedule")
                } else {
                    WideButton(title: "Resume", help: "Follow the schedule again") {
                        coordinator.resumeAutomation(); delegate?.refreshStatusIcon()
                    }
                    .frame(width: column)
                }
                WideButton(title: "Restore",
                           help: "Return every display to its normal output now (\(GlobalHotKey.restore.description))") {
                    coordinator.emergencyRestore(); delegate?.refreshStatusIcon()
                }
                .frame(width: column)
            }
            HStack(spacing: 6) {
                WideButton(title: "Open \(Branding.productName)…") { delegate?.showMainWindow() }
                    .frame(width: column)
                WideButton(title: "Quit", help: "Stop Daylight and restore your displays") {
                    NSApp.terminate(nil)
                }
                .frame(width: column)
            }
        }
        .controlSize(.small)
    }

    private func pause(_ seconds: TimeInterval?) {
        coordinator.pauseAutomation(for: seconds)
        delegate?.refreshStatusIcon()
    }
}
