import SwiftUI
import DaylightCore
import DaylightDisplay

/// The main window's sections.
///
/// Each one exists because there is functionality behind it. Lights, which the
/// original plan sketched, is deliberately absent: no lighting integration is
/// implemented, and an empty tab promising one would be a lie.
enum Panel: String, CaseIterable, Identifiable {
    case today = "Today"
    case schedule = "Schedule"
    case displays = "Displays"
    case modes = "Modes"
    case rules = "Rules"
    case settings = "Settings"
    var id: String { rawValue }

    var symbol: String {
        switch self {
        case .today: return "sun.horizon"
        case .schedule: return "calendar"
        case .displays: return "display"
        case .modes: return "square.stack"
        case .rules: return "slider.horizontal.3"
        case .settings: return "gearshape"
        }
    }
}

final class WindowModel: ObservableObject {
    @Published var panel: Panel = .today
    /// Ticks once a minute so relative times stay honest without the window
    /// redrawing continuously.
    @Published var now = Date()
    private var timer: Timer?

    init() {
        timer = Timer.scheduledTimer(withTimeInterval: 30, repeats: true) { [weak self] _ in
            self?.now = Date()
        }
        timer?.tolerance = 10
    }
    deinit { timer?.invalidate() }
}

struct MainWindowView: View {
    @ObservedObject var coordinator: LightingCoordinator
    weak var delegate: AppCommands?
    @StateObject private var model = WindowModel()

    var body: some View {
        NavigationSplitView {
            List(Panel.allCases, selection: $model.panel) { panel in
                Label(panel.rawValue, systemImage: panel.symbol).tag(panel)
            }
            .navigationSplitViewColumnWidth(min: 160, ideal: 178, max: 220)
            .safeAreaInset(edge: .bottom) { sidebarFooter }
        } detail: {
            Group {
                switch model.panel {
                case .today:    TodayPanel(coordinator: coordinator, window: model)
                case .schedule: SchedulePanel(coordinator: coordinator, window: model)
                case .displays: DisplaysPanel(coordinator: coordinator)
                case .modes:    ModesPanel(coordinator: coordinator)
                case .rules:    RulesPanel(coordinator: coordinator)
                case .settings: SettingsPanel(coordinator: coordinator, delegate: delegate)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
            .background(Palette.surface)
            .animation(Motion.move(coordinator.settings), value: model.panel)
        }
        .frame(minWidth: 720, minHeight: 520)
    }

    private var sidebarFooter: some View {
        VStack(alignment: .leading, spacing: 6) {
            Divider()
            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 6) {
                    Circle().fill(statusColour).frame(width: 7, height: 7)
                        .accessibilityHidden(true)
                    Text(statusWord)
                        .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                    Spacer()
                }
                if let workspace = coordinator.activeWorkspace {
                    Text("at \(workspace.name)")
                        .font(.system(size: 10)).foregroundStyle(Palette.tertiaryText)
                }
            }
            .accessibilityElement(children: .combine)
            .accessibilityLabel(coordinator.activeWorkspace.map { "\(statusWord), at \($0.name)" } ?? statusWord)
            Button {
                coordinator.emergencyRestore()
                delegate?.refreshStatusIcon()
            } label: {
                Label("Restore normal output", systemImage: "arrow.counterclockwise")
                    .font(.daylightCaption)
            }
            .buttonStyle(.plain)
            .foregroundStyle(Palette.secondaryText)
            .help("Return every display to its normal output now (\(GlobalHotKey.restore.description))")
        }
        .padding(.horizontal, 14)
        .padding(.bottom, 12)
        .accessibilityElement(children: .contain)
    }

    private var statusWord: String {
        if !coordinator.settings.automationEnabled { return "Automation off" }
        if coordinator.pause != nil { return "Paused" }
        return "Active"
    }
    private var statusColour: Color {
        if !coordinator.settings.automationEnabled { return Palette.tertiaryText }
        if coordinator.pause != nil { return Palette.warning }
        return Palette.positive
    }
}

// MARK: - Today

/// Answers, in order and without scrolling: what is active, why, what changes
/// next, and how to adjust or pause it.
struct TodayPanel: View {
    @ObservedObject var coordinator: LightingCoordinator
    @ObservedObject var window: WindowModel
    @StateObject private var timelineModel = TimelineModel()

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: Metrics.stackGap) {
                headline
                if !coordinator.conflicts.isEmpty { conflictNotices }
                if !coordinator.timeline.diagnostics.isEmpty { scheduleNotices }
                timelineCard
                controlsCard
                displaySummary
            }
            .padding(Metrics.gutter)
        }
        .navigationTitle("Today")
    }

    // MARK: Headline

    private var headline: some View {
        Card {
            VStack(alignment: .leading, spacing: 10) {
                HStack(alignment: .firstTextBaseline, spacing: 10) {
                    Text(Format.kelvin(coordinator.outcome.target.temperature))
                        .font(.daylightHero)
                        .contentTransition(.numericText())
                        .animation(Motion.settle(coordinator.settings),
                                   value: coordinator.outcome.target.temperature.kelvin)
                    Text(PrecedenceResolver.describeWarmth(coordinator.outcome.target.temperature))
                        .font(.daylightTitle)
                        .foregroundStyle(Palette.secondaryText)
                    Spacer()
                    statusPill
                }
                Text(coordinator.outcome.explanation)
                    .font(.daylightBody)
                    .foregroundStyle(Palette.secondaryText)
                    .fixedSize(horizontal: false, vertical: true)
                    .animation(Motion.reveal(coordinator.settings), value: coordinator.outcome.explanation)

                // Side by side when there is room, stacked when there is not,
                // rather than letting the labels wrap mid-phrase.
                ViewThatFits(in: .horizontal) {
                    HStack(spacing: 24) { factRows }
                    VStack(spacing: 7) { factRows }
                }
                if let override = coordinator.activeOverride {
                    NoticeBanner(kind: .info,
                                 message: override.statusSentence(
                                    now: window.now,
                                    nextScheduleChange: coordinator.evaluation.nextChangeAt,
                                    formatter: Format.timeOfDay),
                                 action: ("Resume now", { coordinator.clearOverride() }))
                }
                if let pause = coordinator.pause {
                    NoticeBanner(kind: .info, message: pauseSentence(pause),
                                 action: ("Resume", { coordinator.resumeAutomation() }))
                }
            }
        }
    }

    @ViewBuilder
    private var factRows: some View {
        FactRow(label: "Brightness",
                value: Format.percent(coordinator.outcome.target.dimming.factor),
                detail: "software dimming")
        if let next = coordinator.evaluation.nextChangeAt {
            FactRow(label: "Next change",
                    value: Format.timeOfDay.string(from: next),
                    detail: nextDetail(next))
        }
    }

    private func nextDetail(_ next: Date) -> String {
        let rel = Format.relative(next, from: window.now)
        if let name = coordinator.evaluation.nextAnchor?.anchor.name { return "\(name), \(rel)" }
        return rel
    }

    private func pauseSentence(_ p: PauseState) -> String {
        guard let until = p.until else { return "Daylight is paused until you resume it." }
        return "Daylight is paused until \(Format.timeOfDay.string(from: until)) (\(Format.relative(until, from: window.now)))."
    }

    private var statusPill: some View {
        Text(coordinator.outcome.dominant.layer.displayName)
            .font(.daylightCaption)
            .padding(.horizontal, 9).padding(.vertical, 4)
            .background(Capsule().fill(Palette.accentSoft))
            .overlay(Capsule().strokeBorder(Palette.accent.opacity(0.35)))
            .accessibilityLabel("Currently controlled by: \(coordinator.outcome.dominant.layer.displayName)")
    }

    // MARK: Notices

    private var conflictNotices: some View {
        VStack(spacing: 8) {
            ForEach(coordinator.conflicts) { c in
                NoticeBanner(kind: .warning, message: "\(c.displayName): \(c.message)")
            }
        }
    }

    private var scheduleNotices: some View {
        VStack(spacing: 8) {
            ForEach(coordinator.timeline.diagnostics) { d in
                NoticeBanner(kind: d.severity == .warning ? .warning : .info, message: d.message)
            }
        }
    }

    // MARK: Timeline

    private var timelineCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    SectionLabel(text: "Your day")
                    Spacer()
                    Text("Warmth above, brightness below")
                        .font(.system(size: 10))
                        .foregroundStyle(Palette.tertiaryText)
                }
                DayTimelineView(timeline: coordinator.timeline, now: window.now,
                                editable: false, model: timelineModel)
                TimeScrubber(model: timelineModel, timeline: coordinator.timeline,
                             now: window.now, animation: Motion.settle(coordinator.settings))
                Divider()
                TimelineTextSummary(timeline: coordinator.timeline, now: window.now)
            }
        }
    }

    // MARK: Controls

    private var controlsCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 12) {
                SectionLabel(text: "Right now")
                HStack(spacing: 8) {
                    if coordinator.pause == nil {
                        Menu("Pause…") {
                            Button("For 15 minutes") { coordinator.pauseAutomation(for: 900) }
                            Button("For 30 minutes") { coordinator.pauseAutomation(for: 1800) }
                            Button("For 1 hour") { coordinator.pauseAutomation(for: 3600) }
                            Button("Until I resume") { coordinator.pauseAutomation(for: nil) }
                        }
                        .frame(width: 120)
                    } else {
                        Button("Resume automation") { coordinator.resumeAutomation() }
                    }
                    Button("Restore normal output") { coordinator.emergencyRestore() }
                    Spacer()
                }
                Divider()
                SectionLabel(text: "Modes")
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 216), spacing: 8)],
                          alignment: .leading, spacing: 8) {
                    ForEach(coordinator.settings.profiles) { profile in
                        ModeCard(profile: profile,
                                 isActive: coordinator.activeOverride?.label == profile.name,
                                 action: {
                                     coordinator.applyProfile(profile, expiry: .untilNextScheduleChange)
                                 })
                    }
                }
            }
        }
    }

    // MARK: Displays

    private var displaySummary: some View {
        Card {
            VStack(alignment: .leading, spacing: 10) {
                SectionLabel(text: "Displays")
                if coordinator.displayStatuses.isEmpty {
                    Text("No displays detected.")
                        .font(.daylightBody).foregroundStyle(Palette.secondaryText)
                } else {
                    ForEach(coordinator.displayStatuses) { d in
                        HStack(spacing: 10) {
                            Image(systemName: d.isBuiltIn ? "laptopcomputer" : "display")
                                .foregroundStyle(Palette.secondaryText)
                                .accessibilityHidden(true)
                            VStack(alignment: .leading, spacing: 1) {
                                Text(d.name).font(.daylightBody)
                                Text(subtitle(d)).font(.system(size: 10))
                                    .foregroundStyle(Palette.secondaryText)
                            }
                            Spacer()
                            Text(d.isExcluded ? "Not managed" : Format.kelvin(d.appliedTarget.temperature))
                                .font(.system(size: 12, design: .rounded)).monospacedDigit()
                                .foregroundStyle(d.isExcluded ? Palette.tertiaryText : Palette.primaryText)
                        }
                        .accessibilityElement(children: .combine)
                    }
                }
            }
        }
    }

    private func subtitle(_ d: DisplayStatus) -> String {
        var bits: [String] = [d.connection.displayName]
        if let e = d.lastErrorMessage { bits.append(e) }
        else { bits.append(d.confidence.shortLabel) }
        return bits.joined(separator: " · ")
    }
}


/// One mode, as a button.
///
/// Shows the values it will apply, not only a description: the whole point of
/// a mode is that it is a transparent combination of settings, so hiding the
/// numbers would undercut it. Cards in a row share a height so the grid does
/// not come out ragged.
struct ModeCard: View {
    let profile: Profile
    let isActive: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 5) {
                HStack(alignment: .firstTextBaseline, spacing: 7) {
                    Image(systemName: profile.symbolName)
                        .font(.system(size: 12))
                        .frame(width: 16)
                        .foregroundStyle(isActive ? Palette.accent : Palette.secondaryText)
                        .accessibilityHidden(true)
                    Text(profile.name)
                        .font(.system(size: 13, weight: .medium))
                    Spacer(minLength: 6)
                    Text(verbatim: values)
                        .font(.system(size: 10, design: .rounded)).monospacedDigit()
                        .foregroundStyle(Palette.secondaryText)
                }
                Text(profile.summary)
                    .font(.system(size: 10))
                    .foregroundStyle(Palette.secondaryText)
                    .multilineTextAlignment(.leading)
                    .fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 0)
            }
            .padding(10)
            .frame(maxWidth: .infinity, minHeight: 74, alignment: .topLeading)
            .background(RoundedRectangle(cornerRadius: 9, style: .continuous)
                .fill(isActive ? Palette.accentSoft : Color.primary.opacity(0.04)))
            .overlay(RoundedRectangle(cornerRadius: 9, style: .continuous)
                .strokeBorder(isActive ? Palette.accent.opacity(0.55) : Palette.hairline))
        }
        .buttonStyle(.plain)
        .accessibilityLabel("\(profile.name), \(values)")
        .accessibilityHint(profile.summary)
        .accessibilityAddTraits(isActive ? [.isSelected] : [])
    }

    private var values: String {
        var parts: [String] = []
        if let t = profile.target.temperature { parts.append(Format.kelvin(t)) }
        if let d = profile.target.dimming { parts.append(Format.percent(d.factor)) }
        return parts.isEmpty ? "—" : parts.joined(separator: " · ")
    }
}
