import SwiftUI
import DaylightCore

/// The visual vocabulary. Everything the interface draws comes from here, so
/// the whole app changes character by editing one file.
public enum Palette {
    /// A warm amber, used sparingly — for the current-time marker, the active
    /// selection, and little else. Restraint is what keeps it meaningful.
    static let accent = Color(red: 0.85, green: 0.55, blue: 0.20)
    static let accentSoft = Color(red: 0.85, green: 0.55, blue: 0.20).opacity(0.14)

    public static let surface = Color(nsColor: .controlBackgroundColor)
    static let raised = Color(nsColor: .textBackgroundColor)

    /// Borders and dividers. Strengthened when the system asks for higher
    /// contrast — a change of weight rather than of layout, so nothing moves.
    static var hairline: Color {
        Contrast.isIncreased
            ? Color(nsColor: .separatorColor).opacity(1.0)
            : Color(nsColor: .separatorColor)
    }

    static let primaryText = Color(nsColor: .labelColor)

    /// Under increased contrast this steps up to the full label colour, so the
    /// explanatory text the app leans on stays comfortably readable.
    static var secondaryText: Color {
        Contrast.isIncreased ? Color(nsColor: .labelColor) : Color(nsColor: .secondaryLabelColor)
    }
    /// Reserved for genuinely incidental marks (axis ticks). Anything a person
    /// needs to read uses `secondaryText`.
    static var tertiaryText: Color {
        Contrast.isIncreased
            ? Color(nsColor: .secondaryLabelColor) : Color(nsColor: .tertiaryLabelColor)
    }

    static let warning = Color(nsColor: .systemOrange)
    static let positive = Color(nsColor: .systemGreen)

    /// The colour a given temperature is *shown* as in the timeline.
    ///
    /// Deliberately not the literal gains: a true 6500 K swatch is plain white,
    /// which disappears against a light background and makes the middle of the
    /// day look like missing data. This maps the same range onto a cool-to-warm
    /// scale that stays visible in both themes. It illustrates relative warmth
    /// and is not a colour-managed rendering of what the display will emit.
    static func swatch(for t: ColourTemperature) -> Color {
        let lo = ColourTemperature.advancedRange.lowerBound
        let hi = ColourTemperature.neutral.kelvin
        let f = min(max((hi - t.kelvin) / (hi - lo), 0), 1)
        let cool = (r: 0.62, g: 0.74, b: 0.88)
        let warm = (r: 0.94, g: 0.55, b: 0.24)
        return Color(red: cool.r + (warm.r - cool.r) * f,
                     green: cool.g + (warm.g - cool.g) * f,
                     blue: cool.b + (warm.b - cool.b) * f)
    }
}

enum Metrics {
    static let cornerRadius: CGFloat = 10
    static let cardRadius: CGFloat = 12
    static let gutter: CGFloat = 20
    static let stackGap: CGFloat = 14
}

extension Font {
    /// A single display face used for the one number that matters on each
    /// screen. Monospaced digits so it does not jitter as it counts.
    static let daylightHero = Font.system(size: 34, weight: .medium, design: .rounded)
        .monospacedDigit()
    static let daylightTitle = Font.system(size: 15, weight: .semibold)
    static let daylightBody = Font.system(size: 13)
    static let daylightCaption = Font.system(size: 11)
    static let daylightSectionLabel = Font.system(size: 11, weight: .semibold)
}

/// A plain surface with a hairline. No glass, no gradients, no shadow theatre.
struct Card<Content: View>: View {
    var padding: CGFloat = Metrics.gutter
    @ViewBuilder var content: Content

    var body: some View {
        content
            .padding(padding)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(
                RoundedRectangle(cornerRadius: Metrics.cardRadius, style: .continuous)
                    .fill(Palette.raised)
            )
            .overlay(
                RoundedRectangle(cornerRadius: Metrics.cardRadius, style: .continuous)
                    .strokeBorder(Palette.hairline, lineWidth: 1)
            )
    }
}

struct SectionLabel: View {
    let text: String
    var body: some View {
        Text(text.uppercased())
            .font(.daylightSectionLabel)
            .kerning(0.6)
            .foregroundStyle(Palette.secondaryText)
            .accessibilityAddTraits(.isHeader)
    }
}

/// A row that states a fact and, where relevant, how confident we are in it.
struct FactRow: View {
    let label: String
    let value: String
    var detail: String?
    var tone: Tone = .normal

    enum Tone { case normal, warning, positive }

    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 12) {
            Text(label)
                .font(.daylightBody)
                .foregroundStyle(Palette.secondaryText)
            Spacer(minLength: 12)
            VStack(alignment: .trailing, spacing: 2) {
                Text(value)
                    .font(.daylightBody)
                    .foregroundStyle(colour)
                if let detail {
                    Text(detail)
                        .font(.daylightCaption)
                        .foregroundStyle(Palette.tertiaryText)
                        .multilineTextAlignment(.trailing)
                }
            }
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(label): \(value)\(detail.map { ". \($0)" } ?? "")")
    }

    private var colour: Color {
        switch tone {
        case .normal: return Palette.primaryText
        case .warning: return Palette.warning
        case .positive: return Palette.positive
        }
    }
}

/// Used wherever the app has to admit a limitation. Never a bare error code.
struct NoticeBanner: View {
    enum Kind { case info, warning }
    let kind: Kind
    let message: String
    var action: (title: String, run: () -> Void)?

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: kind == .warning ? "exclamationmark.triangle.fill" : "info.circle.fill")
                .foregroundStyle(kind == .warning ? Palette.warning : Palette.secondaryText)
                .font(.system(size: 12))
                .padding(.top, 1)
                .accessibilityHidden(true)
            Text(message)
                .font(.daylightCaption)
                .foregroundStyle(Palette.secondaryText)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
            if let action {
                Button(action.title, action: action.run)
                    .buttonStyle(.link)
                    .font(.daylightCaption)
            }
        }
        .padding(12)
        .background(
            RoundedRectangle(cornerRadius: Metrics.cornerRadius, style: .continuous)
                .fill(kind == .warning ? Palette.warning.opacity(0.10) : Palette.hairline.opacity(0.25))
        )
        .accessibilityElement(children: .combine)
    }
}

// MARK: - Shared formatting

enum Format {
    static let timeOfDay: DateFormatter = {
        let f = DateFormatter()
        f.timeStyle = .short
        f.dateStyle = .none
        return f
    }()

    /// Rounded to the nearest 50 K. Presenting a warmth target to four
    /// significant figures would imply a precision this does not have.
    static func kelvin(_ t: ColourTemperature) -> String {
        String(format: "%.0f K", (t.kelvin / 50).rounded() * 50)
    }

    static func percent(_ v: Double) -> String {
        String(format: "%.0f%%", (v * 100).rounded())
    }

    static func minutes(_ m: Double) -> String {
        String(format: "%.0f min", m.rounded())
    }

    static func relative(_ date: Date, from now: Date = Date()) -> String {
        let seconds = Int(date.timeIntervalSince(now))
        if seconds <= 0 { return "now" }
        if seconds < 60 { return "in under a minute" }
        let minutes = seconds / 60
        if minutes < 60 { return "in \(minutes) minute\(minutes == 1 ? "" : "s")" }
        let hours = minutes / 60, rest = minutes % 60
        if rest == 0 { return "in \(hours) hour\(hours == 1 ? "" : "s")" }
        return "in \(hours)h \(rest)m"
    }

    /// Time-of-day words used consistently across the interface.
    static func partOfDay(_ secondsFromMidnight: Double) -> String {
        switch secondsFromMidnight {
        case ..<(5 * 3600):  return "Night"
        case ..<(9 * 3600):  return "Morning"
        case ..<(12 * 3600): return "Late morning"
        case ..<(17 * 3600): return "Afternoon"
        case ..<(20 * 3600): return "Evening"
        case ..<(23 * 3600): return "Late evening"
        default:             return "Night"
        }
    }
}

// MARK: - Small shared pieces
//
// Defined once so a pill in the Rules panel is the same object as a pill in the
// Today view. Consistency at this scale is most of what "considered" looks like.

/// A short status word attached to something else — "matching now", "here now".
struct Pill: View {
    enum Tone { case accent, neutral, warning, positive }
    let text: String
    var tone: Tone = .neutral

    var body: some View {
        Text(text)
            .font(.system(size: 10, weight: .medium))
            .padding(.horizontal, 6).padding(.vertical, 2)
            .background(Capsule().fill(background))
            .foregroundStyle(foreground)
            .accessibilityLabel(text)
    }

    private var background: Color {
        switch tone {
        case .accent: return Palette.accentSoft
        case .neutral: return Color.primary.opacity(0.07)
        case .warning: return Palette.warning.opacity(0.14)
        case .positive: return Palette.positive.opacity(0.14)
        }
    }
    private var foreground: Color {
        switch tone {
        case .accent: return Palette.accent
        case .neutral: return Palette.secondaryText
        case .warning: return Palette.warning
        case .positive: return Palette.positive
        }
    }
}

/// A borderless icon button with a real accessibility label.
///
/// Icon-only controls are where accessibility usually quietly breaks, so the
/// label is a required argument rather than an optional modifier.
struct IconButton: View {
    let symbol: String
    let label: String
    var action: () -> Void

    @Environment(\.isEnabled) private var isEnabled

    var body: some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 12))
                .frame(width: 22, height: 22)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .foregroundStyle(isEnabled ? Palette.secondaryText : Palette.tertiaryText)
        .help(label)
        .accessibilityLabel(label)
    }
}

/// What a list looks like before there is anything in it.
///
/// Every list in the app has one. An empty panel with no explanation is the
/// most common way a considered interface stops feeling considered.
struct EmptyStateView: View {
    let symbol: String
    let title: String
    let message: String
    var action: (title: String, run: () -> Void)?

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 8) {
                Image(systemName: symbol)
                    .font(.system(size: 15))
                    .foregroundStyle(Palette.tertiaryText)
                    .accessibilityHidden(true)
                Text(title).font(.daylightBody).foregroundStyle(Palette.primaryText)
            }
            Text(message)
                .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                .fixedSize(horizontal: false, vertical: true)
            if let action {
                Button(action.title, action: action.run)
                    .controlSize(.small).padding(.top, 2)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.vertical, 10)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(title). \(message)")
    }
}

/// A button that fills the width it is given.
///
/// A plain `Button` inside a fixed-width frame stays content-sized and sits
/// centred, which is why rows of buttons come out ragged. Expanding the *label*
/// is what actually widens the control, so that is done here once rather than
/// remembered at each call site.
struct WideButton: View {
    let title: String
    var help: String?
    var isProminent = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .frame(maxWidth: .infinity)
                .lineLimit(1)
        }
        .help(help ?? title)
        .modifier(ProminenceModifier(isProminent: isProminent))
    }
}

private struct ProminenceModifier: ViewModifier {
    let isProminent: Bool
    func body(content: Content) -> some View {
        if isProminent { content.buttonStyle(.borderedProminent) }
        else { content }
    }
}
