import SwiftUI
import DaylightCore
import DaylightDisplay

final class SchedulePanelModel: ObservableObject {
    @Published var editingWeekend = false
    /// A change that has landed on screen but not yet been accepted. Edits
    /// apply straight away so the controls stay responsive; this offers the way
    /// back rather than blocking the way forward.
    @Published var pendingConcern: ExtremeSettings.Concern?
    @Published var dayPreviewProgress: Double?
    @Published var applyPreviewToDisplays = false
    @Published var previewCountdown: Int?
    private var previewTimer: Timer?

    /// Runs the day past in about twelve seconds. By default this only moves
    /// the marker on screen; sending it to real displays is a separate,
    /// explicit choice with a visible countdown.
    func startDayPreview(onTick: @escaping (Double) -> Void, onFinish: @escaping () -> Void) {
        stopDayPreview()
        let duration = 12.0
        let started = Date()
        dayPreviewProgress = 0
        previewTimer = Timer.scheduledTimer(withTimeInterval: 1.0 / 30.0, repeats: true) { [weak self] t in
            guard let self else { return }
            let f = min(Date().timeIntervalSince(started) / duration, 1)
            self.dayPreviewProgress = f
            self.previewCountdown = Int((duration - duration * f).rounded(.up))
            onTick(f * 86_400)
            if f >= 1 {
                t.invalidate()
                self.previewTimer = nil
                self.dayPreviewProgress = nil
                self.previewCountdown = nil
                onFinish()
            }
        }
    }

    func stopDayPreview() {
        previewTimer?.invalidate(); previewTimer = nil
        dayPreviewProgress = nil
        previewCountdown = nil
    }

    deinit { previewTimer?.invalidate() }
}

struct SchedulePanel: View {
    @ObservedObject var coordinator: LightingCoordinator
    @ObservedObject var window: WindowModel
    @StateObject private var model = SchedulePanelModel()
    @StateObject private var timelineModel = TimelineModel()

    private var schedule: Schedule { coordinator.settings.activeSchedule ?? Presets.balanced() }

    private var anchors: [ScheduleAnchor] {
        model.editingWeekend ? schedule.weekendAnchors : schedule.weekdayAnchors
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: Metrics.stackGap) {
                schedulePicker
                timelineCard
                anchorList
                locationCard
            }
            .padding(Metrics.gutter)
        }
        .navigationTitle("Schedule")
        .onDisappear { endPreview() }
    }

    // MARK: Schedule selection

    private var schedulePicker: some View {
        Card {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    SectionLabel(text: "Active schedule")
                    Spacer()
                    if timelineModel.canUndo {
                        Button("Undo") {
                            if let previous = timelineModel.undo() { replaceSchedule(previous) }
                        }
                        .buttonStyle(.link).font(.daylightCaption)
                    }
                }
                Picker("", selection: Binding(
                    get: { coordinator.settings.activeScheduleID },
                    set: { coordinator.settings.activeScheduleID = $0; timelineModel.clearUndo() })) {
                    ForEach(coordinator.settings.schedules) { Text($0.name).tag($0.id) }
                }
                .labelsHidden().pickerStyle(.segmented)
                .accessibilityLabel("Active schedule")

                HStack(spacing: 8) {
                    Button("Duplicate") { duplicateSchedule() }
                    Button("Reset this schedule") { resetSchedule() }
                        .help("Return only this schedule to its original anchors. Nothing else changes.")
                    Spacer()
                    Toggle("Separate weekend", isOn: Binding(
                        get: { schedule.usesSeparateWeekend },
                        set: { on in
                            mutate { s in
                                s.usesSeparateWeekend = on
                                if on && s.weekendAnchors.isEmpty { s.weekendAnchors = s.weekdayAnchors }
                            }
                        }))
                        .toggleStyle(.checkbox)
                }
                .controlSize(.small)

                if schedule.usesSeparateWeekend {
                    Picker("", selection: $model.editingWeekend) {
                        Text("Weekdays").tag(false)
                        Text("Weekend").tag(true)
                    }
                    .labelsHidden().pickerStyle(.segmented).frame(width: 220)
                    .accessibilityLabel("Which days you are editing")
                }
            }
        }
    }

    // MARK: Timeline

    private var timelineCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    SectionLabel(text: "Drag to adjust")
                    Spacer()
                    previewControls
                }
                DayTimelineView(
                    timeline: previewTimeline, now: window.now, editable: true,
                    onDrag: { id, seconds in dragAnchor(id: id, to: seconds) },
                    onDragEnd: { coordinator.persist() },
                    model: timelineModel)
                Text("Handles set the time each step is reached. Anchors that follow the sun are shown faded, because their time comes from your location rather than from dragging.")
                    .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private var previewTimeline: Timeline {
        ScheduleResolver.timeline(for: schedule, on: window.now,
                                  timeZone: coordinator.timeZone,
                                  location: coordinator.settings.location)
    }

    private var previewControls: some View {
        HStack(spacing: 10) {
            Toggle("Apply preview to displays", isOn: $model.applyPreviewToDisplays)
                .toggleStyle(.checkbox).controlSize(.small)
                .help("Off by default: the preview animates this window only.")
            if let countdown = model.previewCountdown {
                Text("\(countdown)s")
                    .font(.system(size: 11, design: .rounded)).monospacedDigit()
                    .foregroundStyle(Palette.accent)
                Button("Stop") { endPreview() }.controlSize(.small)
            } else {
                Button("Preview my day") { startPreview() }.controlSize(.small)
            }
        }
    }

    private func startPreview() {
        let tl = previewTimeline
        model.startDayPreview(onTick: { seconds in
            timelineModel.previewSeconds = seconds
            if model.applyPreviewToDisplays {
                let target = tl.evaluateAtWallClock(seconds: seconds).target
                coordinator.startPreview(label: "Day preview", target: target, seconds: 3)
            }
        }, onFinish: {
            endPreview()
        })
    }

    /// Cleanup runs on finish, on cancel, on leaving the panel, and on quit, so
    /// a preview can never be what your display is left showing.
    private func endPreview() {
        model.stopDayPreview()
        timelineModel.previewSeconds = nil
        coordinator.cancelPreview()
    }

    // MARK: Anchors

    private var anchorList: some View {
        Card {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    SectionLabel(text: model.editingWeekend ? "Weekend anchors" : "Weekday anchors")
                    Spacer()
                    Button("Add anchor") { addAnchor() }.controlSize(.small)
                }
                if anchors.isEmpty {
                    EmptyStateView(
                        symbol: "point.topleft.down.curvedto.point.bottomright.up",
                        title: "No steps yet",
                        message: "An anchor is a time of day and the warmth and brightness to reach by then. Without any, Daylight leaves this display neutral.",
                        action: ("Add the first one", { addAnchor() }))
                }
                if let concern = model.pendingConcern {
                    ExtremeConfirmStrip(
                        concern: concern,
                        onUndo: {
                            if let previous = timelineModel.undo() { replaceSchedule(previous) }
                            model.pendingConcern = nil
                        },
                        onKeep: { model.pendingConcern = nil },
                        onStopWarning: {
                            coordinator.settings.warnOnExtremeSettings = false
                            model.pendingConcern = nil
                        })
                }
                ForEach(anchors) { anchor in
                    AnchorRow(
                        anchor: anchor,
                        isSelected: timelineModel.selectedAnchorID == anchor.id,
                        onChange: { updated in update(anchor: updated) },
                        onDelete: { delete(anchor: anchor) },
                        onSelect: { timelineModel.selectedAnchorID = anchor.id })
                    if anchor.id != anchors.last?.id { Divider() }
                }
            }
        }
    }

    // MARK: Location

    private var locationCard: some View {
        Card { LocationPicker(coordinator: coordinator) }
    }

    // MARK: Mutations

    private func mutate(_ change: (inout Schedule) -> Void) {
        guard let index = coordinator.settings.schedules.firstIndex(where: { $0.id == schedule.id })
        else { return }
        timelineModel.snapshot(coordinator.settings.schedules[index])
        change(&coordinator.settings.schedules[index])
    }

    private func replaceSchedule(_ new: Schedule) {
        guard let index = coordinator.settings.schedules.firstIndex(where: { $0.id == new.id }) else { return }
        coordinator.settings.schedules[index] = new
    }

    private func dragAnchor(id: UUID, to seconds: Double) {
        guard let index = coordinator.settings.schedules.firstIndex(where: { $0.id == schedule.id })
        else { return }
        let snapped = (seconds / DayTimelineView.dragSnapSeconds).rounded() * DayTimelineView.dragSnapSeconds
        let clamped = min(max(snapped, 0), 86_340)
        let path = \Schedule.weekdayAnchors
        if model.editingWeekend {
            if let i = coordinator.settings.schedules[index].weekendAnchors.firstIndex(where: { $0.id == id }) {
                coordinator.settings.schedules[index].weekendAnchors[i].time =
                    .clock(secondsFromMidnight: Int(clamped))
            }
        } else if let i = coordinator.settings.schedules[index][keyPath: path].firstIndex(where: { $0.id == id }) {
            coordinator.settings.schedules[index].weekdayAnchors[i].time =
                .clock(secondsFromMidnight: Int(clamped))
        }
    }

    private func update(anchor: ScheduleAnchor) {
        // Warn only on the crossing, not on every nudge once already there.
        if coordinator.settings.warnOnExtremeSettings {
            let before = anchors.first { $0.id == anchor.id }
            let wasExtreme = before.flatMap {
                ExtremeSettings.concern(temperature: $0.temperature, dimming: $0.dimming)
            } != nil
            let concern = ExtremeSettings.concern(temperature: anchor.temperature,
                                                  dimming: anchor.dimming,
                                                  restoreShortcut: GlobalHotKey.restore.description)
            if let concern, !wasExtreme {
                model.pendingConcern = concern
            } else if concern == nil {
                model.pendingConcern = nil
            }
        }
        mutate { s in
            if model.editingWeekend {
                if let i = s.weekendAnchors.firstIndex(where: { $0.id == anchor.id }) { s.weekendAnchors[i] = anchor }
            } else if let i = s.weekdayAnchors.firstIndex(where: { $0.id == anchor.id }) {
                s.weekdayAnchors[i] = anchor
            }
        }
    }

    private func delete(anchor: ScheduleAnchor) {
        mutate { s in
            if model.editingWeekend { s.weekendAnchors.removeAll { $0.id == anchor.id } }
            else { s.weekdayAnchors.removeAll { $0.id == anchor.id } }
        }
    }

    private func addAnchor() {
        let new = Presets.anchor("New step", 15, 0, 5000, 1.0, transition: 30)
        mutate { s in
            if model.editingWeekend { s.weekendAnchors.append(new) } else { s.weekdayAnchors.append(new) }
        }
        timelineModel.selectedAnchorID = new.id
    }

    private func duplicateSchedule() {
        var copy = schedule
        copy.id = UUID()
        copy.name = "\(schedule.name) copy"
        copy.weekdayAnchors = copy.weekdayAnchors.map { var a = $0; a.id = UUID(); return a }
        copy.weekendAnchors = copy.weekendAnchors.map { var a = $0; a.id = UUID(); return a }
        coordinator.settings.schedules.append(copy)
        coordinator.settings.activeScheduleID = copy.id
        timelineModel.clearUndo()
    }

    /// Resets only the selected schedule, never the whole app.
    private func resetSchedule() {
        let fresh: Schedule
        switch schedule.name {
        case "Subtle": fresh = Presets.subtle()
        case "Extra Warm": fresh = Presets.extraWarm()
        case "Follow the sun": fresh = Presets.solar()
        default: fresh = Presets.balanced()
        }
        mutate { s in
            s.weekdayAnchors = fresh.weekdayAnchors
            s.weekendAnchors = fresh.weekendAnchors
        }
    }
}

// MARK: - One anchor

struct AnchorRow: View {
    let anchor: ScheduleAnchor
    let isSelected: Bool
    let onChange: (ScheduleAnchor) -> Void
    let onDelete: () -> Void
    let onSelect: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack(spacing: 8) {
                TextField("Name", text: Binding(
                    get: { anchor.name },
                    set: { var a = anchor; a.name = $0; onChange(a) }))
                    .textFieldStyle(.plain)
                    .font(.daylightBody)
                    .frame(width: 130, alignment: .leading)
                    .accessibilityLabel("Anchor name")

                timeControl

                Spacer()

                Toggle("", isOn: Binding(
                    get: { anchor.isEnabled },
                    set: { var a = anchor; a.isEnabled = $0; onChange(a) }))
                    .toggleStyle(.switch).controlSize(.mini).labelsHidden()
                    .accessibilityLabel("\(anchor.name) enabled")

                Button {
                    onDelete()
                } label: {
                    Image(systemName: "minus.circle").foregroundStyle(Palette.secondaryText)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Remove \(anchor.name)")
            }

            HStack(spacing: 14) {
                numericField(label: "Warmth", value: anchor.temperature.kelvin,
                             range: ColourTemperature.advancedRange, step: 50,
                             display: Format.kelvin(anchor.temperature)) { v in
                    var a = anchor; a.temperature = ColourTemperature(kelvin: v); onChange(a)
                }
                numericField(label: "Brightness", value: anchor.dimming.factor * 100,
                             range: SoftwareDimming.safeFloor * 100...100, step: 1,
                             display: Format.percent(anchor.dimming.factor)) { v in
                    var a = anchor; a.dimming = SoftwareDimming(factor: v / 100); onChange(a)
                }
                numericField(label: "Fade", value: anchor.transitionMinutes,
                             range: 0...360, step: 5,
                             display: Format.minutes(anchor.transitionMinutes)) { v in
                    var a = anchor; a.transitionMinutes = v; onChange(a)
                }
                Spacer()
            }
            if ExtremeSettings.concern(temperature: anchor.temperature,
                                       dimming: anchor.dimming) != nil {
                Label("Hard to read at this setting", systemImage: "exclamationmark.triangle")
                    .font(.system(size: 10)).foregroundStyle(Palette.warning)
            }
        }
        .padding(.vertical, 4)
        .background(isSelected ? Palette.accentSoft.opacity(0.5) : .clear)
        .contentShape(Rectangle())
        .onTapGesture(perform: onSelect)
    }

    @ViewBuilder
    private var timeControl: some View {
        switch anchor.time {
        case .clock(let seconds):
            HStack(spacing: 3) {
                Stepper(value: Binding(
                    get: { Double(seconds) },
                    set: { var a = anchor; a.time = .clock(secondsFromMidnight: Int($0)); onChange(a) }),
                        in: 0...86_340, step: 300) {
                    Text(clockString(Double(seconds)))
                        .font(.system(size: 12, design: .rounded)).monospacedDigit()
                        .frame(width: 46)
                }
                .accessibilityLabel("\(anchor.name) time")
                .accessibilityValue(clockString(Double(seconds)))
            }
        case .solar(let event, let offset, _, _):
            HStack(spacing: 4) {
                Image(systemName: event.isMorning ? "sunrise" : "sunset")
                    .font(.system(size: 10)).foregroundStyle(Palette.secondaryText)
                Text(offset == 0 ? event.friendlyName
                     : "\(event.friendlyName) \(offset > 0 ? "+" : "")\(offset)m")
                    .font(.system(size: 11)).foregroundStyle(Palette.secondaryText)
            }
            .accessibilityLabel("Follows \(event.friendlyName)")
        }
    }

    @ViewBuilder
    private func numericField(label: String, value: Double, range: ClosedRange<Double>,
                              step: Double, display: String,
                              onSet: @escaping (Double) -> Void) -> some View {
        HStack(spacing: 4) {
            Text(label).font(.system(size: 10)).foregroundStyle(Palette.secondaryText)
            Stepper(value: Binding(get: { value }, set: onSet), in: range, step: step) {
                // `verbatim` so the value is not re-formatted with locale
                // grouping separators, which would make "6500 K" read as
                // "6,500 K" here and "6500 K" everywhere else.
                Text(verbatim: display)
                    .font(.system(size: 11, design: .rounded)).monospacedDigit()
                    .frame(width: 56, alignment: .leading)
            }
            .accessibilityLabel("\(label) for \(anchor.name)")
            .accessibilityValue(display)
        }
    }
}


/// Shown when an edit lands on a value that will be hard to read.
///
/// Deliberately after the fact rather than a dialog in front of it: the change
/// is already visible, which is the most useful information anyone could have
/// when deciding whether to keep it.
struct ExtremeConfirmStrip: View {
    let concern: ExtremeSettings.Concern
    let onUndo: () -> Void
    let onKeep: () -> Void
    let onStopWarning: () -> Void

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundStyle(Palette.warning)
                .font(.system(size: 12))
                .padding(.top, 1)
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 6) {
                Text(concern.title).font(.daylightBody)
                Text(concern.detail)
                    .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                    .fixedSize(horizontal: false, vertical: true)
                HStack(spacing: 8) {
                    Button("Undo", action: onUndo)
                    Button("Keep it", action: onKeep).keyboardShortcut(.defaultAction)
                    Spacer()
                    Button("Stop warning me", action: onStopWarning)
                        .buttonStyle(.link).font(.daylightCaption)
                }
                .controlSize(.small)
            }
        }
        .padding(12)
        .background(RoundedRectangle(cornerRadius: Metrics.cornerRadius, style: .continuous)
            .fill(Palette.warning.opacity(0.10)))
        .overlay(RoundedRectangle(cornerRadius: Metrics.cornerRadius, style: .continuous)
            .strokeBorder(Palette.warning.opacity(0.30)))
        .accessibilityElement(children: .contain)
        .accessibilityLabel("\(concern.title). \(concern.detail)")
    }
}
