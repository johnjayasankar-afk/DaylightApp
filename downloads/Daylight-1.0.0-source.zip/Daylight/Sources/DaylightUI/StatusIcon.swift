import AppKit
import DaylightCore

/// The menu bar icon.
///
/// Drawn as a template image so the system handles light and dark menu bars,
/// and so it stays legible in both. It reflects state through shape — a filled
/// disc when active, an outline when paused — rather than through colour
/// alone, and it never animates.
enum StatusIcon {

    enum State { case active, paused, off }

    static func image(for state: State, warmth: Double) -> NSImage {
        let size = NSSize(width: 18, height: 18)
        let image = NSImage(size: size, flipped: false) { rect in
            let centre = CGPoint(x: rect.midX, y: rect.midY)
            let radius: CGFloat = 5.0

            switch state {
            case .active:
                // A disc whose lower portion is filled in proportion to how
                // warm the current setting is: a quiet, glanceable indicator.
                let circle = NSBezierPath(ovalIn: NSRect(x: centre.x - radius, y: centre.y - radius,
                                                         width: radius * 2, height: radius * 2))
                NSColor.black.withAlphaComponent(0.30).setFill()
                circle.fill()
                let fillHeight = radius * 2 * CGFloat(min(max(warmth, 0), 1))
                let clip = NSBezierPath(rect: NSRect(x: centre.x - radius, y: centre.y - radius,
                                                     width: radius * 2, height: fillHeight))
                NSGraphicsContext.saveGraphicsState()
                clip.addClip()
                NSColor.black.setFill()
                circle.fill()
                NSGraphicsContext.restoreGraphicsState()
                NSColor.black.setStroke()
                circle.lineWidth = 1.3
                circle.stroke()

            case .paused:
                let circle = NSBezierPath(ovalIn: NSRect(x: centre.x - radius, y: centre.y - radius,
                                                         width: radius * 2, height: radius * 2))
                NSColor.black.setStroke()
                circle.lineWidth = 1.3
                circle.stroke()
                // Two bars: the universal "paused" shape, readable at 18pt.
                for dx in [-1.6, 1.6] as [CGFloat] {
                    let bar = NSBezierPath(rect: NSRect(x: centre.x + dx - 0.7, y: centre.y - 2.4,
                                                        width: 1.4, height: 4.8))
                    NSColor.black.setFill()
                    bar.fill()
                }

            case .off:
                let circle = NSBezierPath(ovalIn: NSRect(x: centre.x - radius, y: centre.y - radius,
                                                         width: radius * 2, height: radius * 2))
                NSColor.black.withAlphaComponent(0.55).setStroke()
                circle.lineWidth = 1.3
                circle.setLineDash([2, 2], count: 2, phase: 0)
                circle.stroke()
            }
            return true
        }
        image.isTemplate = true
        return image
    }

    /// 0 = neutral, 1 = as warm as the app will go.
    static func warmthFraction(_ t: ColourTemperature) -> Double {
        let lo = ColourTemperature.advancedRange.lowerBound
        let hi = ColourTemperature.neutral.kelvin
        return min(max((hi - t.kelvin) / (hi - lo), 0), 1)
    }

    static func accessibilityDescription(state: State, temperature: ColourTemperature) -> String {
        switch state {
        case .active: return "Daylight, active, about \(Format.kelvin(temperature))"
        case .paused: return "Daylight, paused"
        case .off:    return "Daylight, automation off"
        }
    }
}
