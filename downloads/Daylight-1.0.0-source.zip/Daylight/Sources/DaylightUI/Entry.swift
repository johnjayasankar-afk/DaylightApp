import SwiftUI
import DaylightCore
import DaylightDisplay

/// The whole public surface of the interface module.
///
/// Views themselves stay internal. Exposing three entry points instead of two
/// dozen types keeps the module's boundary meaningful, and means adding or
/// reshaping a panel is not a breaking change to anything outside it.
public enum DaylightUI {

    public static func mainWindow(coordinator: LightingCoordinator,
                                  commands: AppCommands?) -> AnyView {
        AnyView(MainWindowView(coordinator: coordinator, delegate: commands))
    }

    public static func menuBar(coordinator: LightingCoordinator,
                               commands: AppCommands?) -> AnyView {
        AnyView(MenuBarView(coordinator: coordinator, delegate: commands))
    }

    /// `step` opens the flow partway through, for review passes.
    public static func onboarding(coordinator: LightingCoordinator,
                                  commands: AppCommands?,
                                  step: Int = 0) -> AnyView {
        AnyView(OnboardingView(coordinator: coordinator, delegate: commands, initialStep: step))
    }

    public static func commandPalette(coordinator: LightingCoordinator,
                                      onRun: @escaping () -> Void) -> AnyView {
        AnyView(CommandPaletteView(coordinator: coordinator, onRun: onRun))
    }

    public static func breakReminder(message: String,
                                     onSnooze: @escaping () -> Void,
                                     onDismiss: @escaping () -> Void) -> AnyView {
        AnyView(BreakReminderView(message: message, onSnooze: onSnooze, onDismiss: onDismiss))
    }

    /// Individual panels, for rendering the interface to images during review.
    /// Not used by the shipping app, which always shows the whole window.
    public enum Review {
        public static let panelNames: [String] = Panel.allCases.map(\.rawValue)

        /// `expanded` opens disclosure-style editors that are closed by
        /// default, so a review pass can see them without clicking.
        public static func panel(named name: String,
                                 coordinator: LightingCoordinator,
                                 expanded: Bool = false) -> AnyView? {
            guard let panel = Panel.allCases.first(where: { $0.rawValue == name }) else { return nil }
            let window = WindowModel()
            window.panel = panel
            switch panel {
            case .today:    return AnyView(TodayPanel(coordinator: coordinator, window: window))
            case .schedule: return AnyView(SchedulePanel(coordinator: coordinator, window: window))
            case .displays: return AnyView(DisplaysPanel(coordinator: coordinator))
            case .modes:    return AnyView(ModesPanel(coordinator: coordinator))
            case .rules:    return AnyView(RulesPanel(coordinator: coordinator,
                                                      initiallyExpandedRuleID: expanded
                                                        ? coordinator.settings.rules.first?.id : nil))
            case .settings: return AnyView(SettingsPanel(coordinator: coordinator, delegate: nil))
            }
        }
    }

    /// Shortcut descriptions, so the shell can register the same combinations
    /// the Settings panel documents.
    public enum Shortcuts {
        public static var restore: (keyCode: UInt32, modifiers: UInt32, description: String) {
            (GlobalHotKey.restore.keyCode, GlobalHotKey.restore.modifiers, GlobalHotKey.restore.description)
        }
        public static var openApp: (keyCode: UInt32, modifiers: UInt32, description: String) {
            (GlobalHotKey.openDaylight.keyCode, GlobalHotKey.openDaylight.modifiers, GlobalHotKey.openDaylight.description)
        }
        public static var toggleAutomation: (keyCode: UInt32, modifiers: UInt32, description: String) {
            (GlobalHotKey.toggleAutomation.keyCode, GlobalHotKey.toggleAutomation.modifiers, GlobalHotKey.toggleAutomation.description)
        }
        public static var palette: (keyCode: UInt32, modifiers: UInt32, description: String) {
            (GlobalHotKey.palette.keyCode, GlobalHotKey.palette.modifiers, GlobalHotKey.palette.description)
        }
    }

    /// Registers a system-wide shortcut. Returns nil if another application
    /// already owns the combination.
    public static func registerShortcut(keyCode: UInt32, modifiers: UInt32,
                                        description: String,
                                        action: @escaping () -> Void) -> Any? {
        GlobalHotKey(combo: GlobalHotKey.Combo(keyCode: keyCode, modifiers: modifiers,
                                               description: description),
                     handler: action)
    }

    /// The menu bar icon, drawn as a template image.
    public static func statusImage(paused: Bool, automationOff: Bool,
                                   temperature: ColourTemperature) -> NSImage {
        let state: StatusIcon.State = automationOff ? .off : (paused ? .paused : .active)
        return StatusIcon.image(for: state, warmth: StatusIcon.warmthFraction(temperature))
    }

    public static func statusAccessibilityLabel(paused: Bool, automationOff: Bool,
                                                temperature: ColourTemperature) -> String {
        let state: StatusIcon.State = automationOff ? .off : (paused ? .paused : .active)
        return StatusIcon.accessibilityDescription(state: state, temperature: temperature)
    }
}
