import SwiftUI
import AppKit
import UniformTypeIdentifiers
import DaylightCore
import DaylightDisplay

final class RulesPanelModel: ObservableObject {
    @Published var expandedRuleID: UUID?
}

struct RulesPanel: View {
    @ObservedObject var coordinator: LightingCoordinator
    var initiallyExpandedRuleID: UUID?
    @StateObject private var model = RulesPanelModel()

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: Metrics.stackGap) {
                appRulesToggle
                rulesList
                precedenceCard
            }
            .padding(Metrics.gutter)
        }
        .navigationTitle("Rules")
        .onAppear {
            if model.expandedRuleID == nil { model.expandedRuleID = initiallyExpandedRuleID }
        }
    }

    // MARK: Permission-free app awareness

    private var appRulesToggle: some View {
        Card {
            VStack(alignment: .leading, spacing: 8) {
                Toggle("Let rules react to the app in front", isOn: Binding(
                    get: { coordinator.settings.appRulesEnabled },
                    set: { coordinator.settings.appRulesEnabled = $0 }))
                    .toggleStyle(.switch)
                    .font(.daylightTitle)
                Text("""
                Daylight reads only the identifier of the frontmost application, and only while this is on. Nothing about which apps you use is written to disk, and no history is kept.

                A rule about an app changes what the whole display shows while that app is in front. It cannot recolour a single window.
                """)
                .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    // MARK: The rules themselves

    private var rulesList: some View {
        Card {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    SectionLabel(text: "Your rules")
                    Spacer()
                    Menu("Add rule") {
                        Button("When an app is in front…") { add(newAppRule()) }
                        Button("Between two times…") { add(newTimeRule()) }
                        Button("On certain days…") { add(newWeekdayRule()) }
                        Button("While on battery…") { add(newBatteryRule()) }
                        if !coordinator.displayStatuses.isEmpty {
                            Button("When a display is connected…") { add(newDisplayRule()) }
                        }
                        if !coordinator.settings.workspaces.isEmpty {
                            Divider()
                            ForEach(coordinator.settings.workspaces) { w in
                                Button("While at \(w.name)…") { add(newWorkspaceRule(w)) }
                            }
                        }
                    }
                    .controlSize(.small).frame(width: 110)
                }

                if coordinator.settings.rules.isEmpty {
                    EmptyStateView(
                        symbol: "slider.horizontal.3",
                        title: "No rules yet",
                        message: "Rules let Daylight behave differently for a particular app, time of day, set of days, power source, or workspace. Add one above.")
                } else {
                    ForEach(Array(coordinator.settings.rules.enumerated()), id: \.element.id) { index, rule in
                        RuleRow(
                            rule: rule,
                            index: index,
                            total: coordinator.settings.rules.count,
                            isExpanded: model.expandedRuleID == rule.id,
                            isMatching: isMatching(rule),
                            coordinator: coordinator,
                            onToggleExpanded: {
                                withAnimation(Motion.reveal(coordinator.settings)) {
                                    model.expandedRuleID = model.expandedRuleID == rule.id ? nil : rule.id
                                }
                            },
                            onChange: { update($0) },
                            onDelete: { delete(rule) },
                            onMove: { move(rule, by: $0) })
                        if rule.id != coordinator.settings.rules.last?.id {
                            Divider().padding(.vertical, 2)
                        }
                    }
                }
            }
        }
    }

    private func isMatching(_ rule: Rule) -> Bool {
        RulesEngine.evaluate(rules: [rule], context: currentContext(),
                             profiles: coordinator.settings.profiles).proposal != nil
    }

    private func currentContext() -> RuleContext {
        var cal = Calendar(identifier: .gregorian); cal.timeZone = coordinator.timeZone
        let now = Date()
        return RuleContext(
            frontmostBundleID: coordinator.settings.appRulesEnabled
                ? NSWorkspace.shared.frontmostApplication?.bundleIdentifier : nil,
            secondsFromMidnight: Int(Timeline.wallClockSeconds(of: now, in: coordinator.timeZone)),
            weekday: cal.component(.weekday, from: now),
            onBattery: false,
            connectedDisplayKeys: Set(coordinator.displayStatuses.map(\.id)),
            workspaceName: coordinator.activeWorkspace?.name)
    }

    // MARK: Precedence

    private var precedenceCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 10) {
                SectionLabel(text: "What wins when two things disagree")
                Text("Daylight decides each control separately, so a rule that only sets brightness will not undo the schedule's warmth. Where two things set the same control, the one higher in this list wins.")
                    .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                    .fixedSize(horizontal: false, vertical: true)
                VStack(alignment: .leading, spacing: 5) {
                    let ladder = Array(ControlLayer.allCases.sorted { $0 > $1 })
                    ForEach(ladder, id: \.self) { layer in
                        HStack(spacing: 8) {
                            Text(verbatim: "\((ladder.firstIndex(of: layer) ?? 0) + 1)")
                                .font(.system(size: 10, design: .rounded)).monospacedDigit()
                                .foregroundStyle(Palette.tertiaryText).frame(width: 14)
                            Text(layer.displayName).font(.daylightBody)
                            if coordinator.outcome.dominant.layer == layer {
                                Pill(text: "active now", tone: .accent)
                            }
                            Spacer()
                        }
                        .accessibilityElement(children: .combine)
                    }
                }
                Text("Among rules, the lower one in your list wins — so ordering them is how you break a tie.")
                    .font(.system(size: 10)).foregroundStyle(Palette.secondaryText)
            }
        }
    }

    // MARK: Mutations

    private func add(_ rule: Rule) {
        var rule = rule
        rule.order = coordinator.settings.rules.count
        coordinator.settings.rules.append(rule)
        model.expandedRuleID = rule.id
        if case .frontmostApp = rule.triggers.first { coordinator.settings.appRulesEnabled = true }
    }

    private func update(_ rule: Rule) {
        guard let i = coordinator.settings.rules.firstIndex(where: { $0.id == rule.id }) else { return }
        coordinator.settings.rules[i] = rule
    }

    private func delete(_ rule: Rule) {
        withAnimation(Motion.reveal(coordinator.settings)) {
            coordinator.settings.rules.removeAll { $0.id == rule.id }
        }
        renumber()
    }

    private func move(_ rule: Rule, by delta: Int) {
        guard let i = coordinator.settings.rules.firstIndex(where: { $0.id == rule.id }) else { return }
        let j = i + delta
        guard coordinator.settings.rules.indices.contains(j) else { return }
        withAnimation(Motion.move(coordinator.settings)) {
            coordinator.settings.rules.swapAt(i, j)
        }
        renumber()
    }

    /// `order` is what the engine uses to break ties, so it has to keep matching
    /// the order shown.
    private func renumber() {
        for i in coordinator.settings.rules.indices {
            coordinator.settings.rules[i].order = i
        }
    }

    // MARK: Templates

    private func newAppRule() -> Rule {
        let app = NSWorkspace.shared.runningApplications.first {
            $0.activationPolicy == .regular && $0.bundleIdentifier != nil
                && $0 != NSRunningApplication.current
        }
        let bundle = app?.bundleIdentifier ?? "com.apple.Preview"
        let name = app?.localizedName ?? "Preview"
        let colourWork = coordinator.settings.profiles.first { $0.name == "Colour Work" }
        return Rule(name: "\(name) stays neutral",
                    triggers: [.frontmostApp(bundleIdentifier: bundle, displayName: name)],
                    actions: colourWork.map { [.applyProfile(profileID: $0.id, profileName: $0.name)] }
                        ?? [.pauseWarmth])
    }

    private func newTimeRule() -> Rule {
        Rule(name: "Late night dimming",
             triggers: [.timeRange(startSeconds: 23 * 3600, endSeconds: 5 * 3600)],
             actions: [.setDimming(SoftwareDimming(factor: 0.5))])
    }

    private func newWeekdayRule() -> Rule {
        Rule(name: "Weekend mornings",
             triggers: [.weekdays([1, 7]), .timeRange(startSeconds: 6 * 3600, endSeconds: 11 * 3600)],
             actions: [.setTemperature(ColourTemperature(kelvin: 5200))])
    }

    private func newBatteryRule() -> Rule {
        Rule(name: "Dim on battery", triggers: [.onBatteryPower],
             actions: [.setDimming(SoftwareDimming(factor: 0.75))])
    }

    private func newDisplayRule() -> Rule {
        let d = coordinator.displayStatuses[0]
        return Rule(name: "\(d.name) connected",
                    triggers: [.displayConnected(identityKey: d.id, displayName: d.name)],
                    actions: [.setTemperature(ColourTemperature(kelvin: 5000))])
    }

    private func newWorkspaceRule(_ w: Workspace) -> Rule {
        Rule(name: "\(w.name) dimming", triggers: [.workspace(name: w.name)],
             actions: [.setDimming(SoftwareDimming(factor: 0.85))])
    }
}

// MARK: - One rule

struct RuleRow: View {
    let rule: Rule
    let index: Int
    let total: Int
    let isExpanded: Bool
    let isMatching: Bool
    @ObservedObject var coordinator: LightingCoordinator
    let onToggleExpanded: () -> Void
    let onChange: (Rule) -> Void
    let onDelete: () -> Void
    let onMove: (Int) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .top, spacing: 10) {
                Toggle("", isOn: Binding(
                    get: { rule.isEnabled },
                    set: { var r = rule; r.isEnabled = $0; onChange(r) }))
                    .toggleStyle(.switch).controlSize(.mini).labelsHidden()
                    .accessibilityLabel("\(rule.name) enabled")

                VStack(alignment: .leading, spacing: 2) {
                    HStack(spacing: 6) {
                        Text(rule.name).font(.daylightBody)
                            .foregroundStyle(rule.isEnabled ? Palette.primaryText : Palette.secondaryText)
                        if isMatching && rule.isEnabled { Pill(text: "matching now", tone: .accent) }
                    }
                    Text(rule.summary)
                        .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                        .fixedSize(horizontal: false, vertical: true)
                }

                Spacer(minLength: 8)

                HStack(spacing: 2) {
                    IconButton(symbol: "chevron.up", label: "Move \(rule.name) earlier") { onMove(-1) }
                        .disabled(index == 0)
                    IconButton(symbol: "chevron.down", label: "Move \(rule.name) later") { onMove(1) }
                        .disabled(index == total - 1)
                    IconButton(symbol: isExpanded ? "chevron.up.circle.fill" : "pencil",
                               label: isExpanded ? "Close editor" : "Edit \(rule.name)",
                               action: onToggleExpanded)
                    IconButton(symbol: "minus.circle", label: "Delete rule \(rule.name)", action: onDelete)
                }
            }

            if isExpanded {
                RuleEditor(rule: rule, coordinator: coordinator, onChange: onChange)
                    .padding(.leading, 32)
                    .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
        .padding(.vertical, 4)
        .accessibilityElement(children: .contain)
    }
}

// MARK: - Editing a rule

struct RuleEditor: View {
    let rule: Rule
    @ObservedObject var coordinator: LightingCoordinator
    let onChange: (Rule) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                Text("Name").font(.system(size: 10)).foregroundStyle(Palette.secondaryText)
                TextField("Rule name", text: Binding(
                    get: { rule.name },
                    set: { var r = rule; r.name = $0; onChange(r) }))
                    .textFieldStyle(.roundedBorder).controlSize(.small).frame(width: 240)
            }

            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Text("When all of these are true").font(.system(size: 10))
                        .foregroundStyle(Palette.secondaryText)
                    Spacer()
                    Menu("Add") {
                        Button("An app is in front") { addTrigger(defaultAppTrigger()) }
                        Button("A time range") { addTrigger(.timeRange(startSeconds: 9 * 3600, endSeconds: 17 * 3600)) }
                        Button("Certain days") { addTrigger(.weekdays([2, 3, 4, 5, 6])) }
                        Button("On battery") { addTrigger(.onBatteryPower) }
                        ForEach(coordinator.displayStatuses) { d in
                            Button("\(d.name) connected") {
                                addTrigger(.displayConnected(identityKey: d.id, displayName: d.name))
                            }
                        }
                        ForEach(coordinator.settings.workspaces) { w in
                            Button("At \(w.name)") { addTrigger(.workspace(name: w.name)) }
                        }
                    }
                    .controlSize(.mini).frame(width: 60)
                }
                if rule.triggers.isEmpty {
                    Text("A rule with no conditions never runs.")
                        .font(.system(size: 10)).foregroundStyle(Palette.warning)
                }
                ForEach(Array(rule.triggers.enumerated()), id: \.offset) { i, trigger in
                    TriggerEditor(trigger: trigger,
                                  coordinator: coordinator,
                                  onChange: { replaceTrigger(at: i, with: $0) },
                                  onDelete: { removeTrigger(at: i) })
                }
            }

            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Text("Do this").font(.system(size: 10)).foregroundStyle(Palette.secondaryText)
                    Spacer()
                    Menu("Add") {
                        Button("Set warmth") { addAction(.setTemperature(ColourTemperature(kelvin: 4500))) }
                        Button("Set brightness") { addAction(.setDimming(SoftwareDimming(factor: 0.8))) }
                        Button("Pause warmth") { addAction(.pauseWarmth) }
                        Button("Silence reminders") { addAction(.silenceReminders) }
                        Divider()
                        ForEach(coordinator.settings.profiles) { p in
                            Button("Use \(p.name)") {
                                addAction(.applyProfile(profileID: p.id, profileName: p.name))
                            }
                        }
                        if !coordinator.displayStatuses.isEmpty { Divider() }
                        ForEach(coordinator.displayStatuses) { d in
                            Button("Leave \(d.name) alone") { addAction(.excludeDisplay(identityKey: d.id)) }
                        }
                    }
                    .controlSize(.mini).frame(width: 60)
                }
                if rule.actions.isEmpty {
                    Text("A rule with nothing to do has no effect.")
                        .font(.system(size: 10)).foregroundStyle(Palette.warning)
                }
                ForEach(Array(rule.actions.enumerated()), id: \.offset) { i, action in
                    ActionEditor(action: action,
                                 coordinator: coordinator,
                                 onChange: { replaceAction(at: i, with: $0) },
                                 onDelete: { removeAction(at: i) })
                }
            }
        }
        .padding(12)
        .background(RoundedRectangle(cornerRadius: Metrics.cornerRadius, style: .continuous)
            .fill(Color.primary.opacity(0.035)))
    }

    private func defaultAppTrigger() -> RuleTrigger {
        let app = NSWorkspace.shared.runningApplications.first {
            $0.activationPolicy == .regular && $0.bundleIdentifier != nil
                && $0 != NSRunningApplication.current
        }
        return .frontmostApp(bundleIdentifier: app?.bundleIdentifier ?? "com.apple.Preview",
                             displayName: app?.localizedName ?? "Preview")
    }

    private func addTrigger(_ t: RuleTrigger) { var r = rule; r.triggers.append(t); onChange(r) }
    private func removeTrigger(at i: Int) { var r = rule; r.triggers.remove(at: i); onChange(r) }
    private func replaceTrigger(at i: Int, with t: RuleTrigger) {
        var r = rule; r.triggers[i] = t; onChange(r)
    }
    private func addAction(_ a: RuleAction) { var r = rule; r.actions.append(a); onChange(r) }
    private func removeAction(at i: Int) { var r = rule; r.actions.remove(at: i); onChange(r) }
    private func replaceAction(at i: Int, with a: RuleAction) {
        var r = rule; r.actions[i] = a; onChange(r)
    }
}

struct TriggerEditor: View {
    let trigger: RuleTrigger
    @ObservedObject var coordinator: LightingCoordinator
    let onChange: (RuleTrigger) -> Void
    let onDelete: () -> Void

    var body: some View {
        HStack(spacing: 8) {
            switch trigger {
            case .frontmostApp(let bundle, let name):
                AppPicker(bundleIdentifier: bundle, displayName: name) { b, n in
                    onChange(.frontmostApp(bundleIdentifier: b, displayName: n))
                }
            case .timeRange(let start, let end):
                Text("Between").font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                TimeStepper(seconds: start, label: "Start time") {
                    onChange(.timeRange(startSeconds: $0, endSeconds: end))
                }
                Text("and").font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                TimeStepper(seconds: end, label: "End time") {
                    onChange(.timeRange(startSeconds: start, endSeconds: $0))
                }
            case .weekdays(let days):
                WeekdayPicker(days: days) { onChange(.weekdays($0)) }
            case .onBatteryPower:
                Label("Running on battery", systemImage: "battery.50")
                    .font(.daylightCaption)
            case .displayConnected(_, let name):
                Menu {
                    ForEach(coordinator.displayStatuses) { d in
                        Button(d.name) { onChange(.displayConnected(identityKey: d.id, displayName: d.name)) }
                    }
                } label: {
                    Label("\(name) is connected", systemImage: "display")
                }
                .controlSize(.small).frame(maxWidth: 240)
            case .workspace(let name):
                Menu {
                    ForEach(coordinator.settings.workspaces) { w in
                        Button(w.name) { onChange(.workspace(name: w.name)) }
                    }
                } label: {
                    Label("At \(name)", systemImage: "mappin.and.ellipse")
                }
                .controlSize(.small).frame(maxWidth: 200)
            }
            Spacer(minLength: 4)
            IconButton(symbol: "minus.circle", label: "Remove this condition", action: onDelete)
        }
        .accessibilityElement(children: .contain)
        .accessibilityLabel(trigger.describes)
    }
}

struct ActionEditor: View {
    let action: RuleAction
    @ObservedObject var coordinator: LightingCoordinator
    let onChange: (RuleAction) -> Void
    let onDelete: () -> Void

    var body: some View {
        HStack(spacing: 8) {
            switch action {
            case .setTemperature(let t):
                Text("Warmth").font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                Stepper(value: Binding(
                    get: { t.kelvin },
                    set: { onChange(.setTemperature(ColourTemperature(kelvin: $0))) }),
                        in: ColourTemperature.advancedRange, step: 50) {
                    Text(verbatim: Format.kelvin(t))
                        .font(.system(size: 11, design: .rounded)).monospacedDigit()
                        .frame(width: 56, alignment: .leading)
                }
                .accessibilityLabel("Warmth").accessibilityValue(Format.kelvin(t))
            case .setDimming(let d):
                Text("Brightness").font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                Stepper(value: Binding(
                    get: { d.factor * 100 },
                    set: { onChange(.setDimming(SoftwareDimming(factor: $0 / 100))) }),
                        in: SoftwareDimming.safeFloor * 100...100, step: 5) {
                    Text(verbatim: Format.percent(d.factor))
                        .font(.system(size: 11, design: .rounded)).monospacedDigit()
                        .frame(width: 48, alignment: .leading)
                }
                .accessibilityLabel("Brightness").accessibilityValue(Format.percent(d.factor))
            case .applyProfile(_, let name):
                Menu {
                    ForEach(coordinator.settings.profiles) { p in
                        Button(p.name) { onChange(.applyProfile(profileID: p.id, profileName: p.name)) }
                    }
                } label: {
                    Label("Use \(name)", systemImage: "square.stack")
                }
                .controlSize(.small).frame(maxWidth: 200)
            case .pauseWarmth:
                Label("Pause warmth", systemImage: "pause.circle").font(.daylightCaption)
            case .silenceReminders:
                Label("Silence reminders", systemImage: "bell.slash").font(.daylightCaption)
            case .excludeDisplay(let key):
                Menu {
                    ForEach(coordinator.displayStatuses) { d in
                        Button(d.name) { onChange(.excludeDisplay(identityKey: d.id)) }
                    }
                } label: {
                    Label("Leave \(displayName(for: key)) alone", systemImage: "display.trianglebadge.exclamationmark")
                }
                .controlSize(.small).frame(maxWidth: 240)
            }
            Spacer(minLength: 4)
            IconButton(symbol: "minus.circle", label: "Remove this action", action: onDelete)
        }
        .accessibilityElement(children: .contain)
        .accessibilityLabel(action.describes)
    }

    private func displayName(for key: String) -> String {
        coordinator.displayStatuses.first { $0.id == key }?.name ?? "a display"
    }
}

// MARK: - Small shared controls

struct AppPicker: View {
    let bundleIdentifier: String
    let displayName: String
    let onPick: (String, String) -> Void

    private var runningApps: [NSRunningApplication] {
        NSWorkspace.shared.runningApplications
            .filter { $0.activationPolicy == .regular && $0.bundleIdentifier != nil }
            .sorted { ($0.localizedName ?? "") < ($1.localizedName ?? "") }
    }

    var body: some View {
        Menu {
            Section("Running now") {
                ForEach(runningApps, id: \.processIdentifier) { app in
                    Button(app.localizedName ?? app.bundleIdentifier ?? "App") {
                        onPick(app.bundleIdentifier ?? "", app.localizedName ?? "App")
                    }
                }
            }
            Divider()
            Button("Choose an app…") { chooseApp() }
        } label: {
            Label("\(displayName) is in front", systemImage: "app.badge")
        }
        .controlSize(.small)
        .frame(maxWidth: 260)
        .help(bundleIdentifier)
    }

    /// Browsing for an app reads only its bundle identifier and name.
    private func chooseApp() {
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.application]
        panel.directoryURL = URL(fileURLWithPath: "/Applications")
        panel.allowsMultipleSelection = false
        panel.prompt = "Choose"
        guard panel.runModal() == .OK, let url = panel.url,
              let bundle = Bundle(url: url), let identifier = bundle.bundleIdentifier else { return }
        let name = (bundle.object(forInfoDictionaryKey: "CFBundleDisplayName") as? String)
            ?? (bundle.object(forInfoDictionaryKey: "CFBundleName") as? String)
            ?? url.deletingPathExtension().lastPathComponent
        onPick(identifier, name)
    }
}

struct TimeStepper: View {
    let seconds: Int
    let label: String
    let onChange: (Int) -> Void

    var body: some View {
        Stepper(value: Binding(get: { Double(seconds) }, set: { onChange(Int($0)) }),
                in: 0...86_340, step: 900) {
            Text(verbatim: clockString(Double(seconds)))
                .font(.system(size: 11, design: .rounded)).monospacedDigit()
                .frame(width: 46, alignment: .leading)
        }
        .accessibilityLabel(label)
        .accessibilityValue(clockString(Double(seconds)))
    }
}

struct WeekdayPicker: View {
    let days: Set<Int>
    let onChange: (Set<Int>) -> Void

    private let names = [(1, "S"), (2, "M"), (3, "T"), (4, "W"), (5, "T"), (6, "F"), (7, "S")]
    private let full = [1: "Sunday", 2: "Monday", 3: "Tuesday", 4: "Wednesday",
                        5: "Thursday", 6: "Friday", 7: "Saturday"]

    var body: some View {
        HStack(spacing: 3) {
            ForEach(names, id: \.0) { day, letter in
                let isOn = days.contains(day)
                Button {
                    var next = days
                    if isOn { next.remove(day) } else { next.insert(day) }
                    // Never leave a day-of-week condition that can never match.
                    if !next.isEmpty { onChange(next) }
                } label: {
                    Text(verbatim: letter)
                        .font(.system(size: 10, weight: isOn ? .semibold : .regular))
                        .frame(width: 20, height: 18)
                        .background(RoundedRectangle(cornerRadius: 5, style: .continuous)
                            .fill(isOn ? Palette.accentSoft : Color.primary.opacity(0.05)))
                        .overlay(RoundedRectangle(cornerRadius: 5, style: .continuous)
                            .strokeBorder(isOn ? Palette.accent.opacity(0.5) : .clear))
                        .foregroundStyle(isOn ? Palette.accent : Palette.secondaryText)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(full[day] ?? "")
                .accessibilityAddTraits(isOn ? [.isSelected] : [])
            }
        }
    }
}
