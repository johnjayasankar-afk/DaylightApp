import SwiftUI
import DaylightCore
import DaylightDisplay

struct DisplaysPanel: View {
    @ObservedObject var coordinator: LightingCoordinator

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: Metrics.stackGap) {
                if coordinator.displayStatuses.isEmpty {
                    Card {
                        EmptyStateView(
                            symbol: "display.trianglebadge.exclamationmark",
                            title: "No displays detected",
                            message: "Daylight watches for displays continuously, so one will appear here as soon as macOS reports it. If a monitor is connected, unplugging and reconnecting it usually helps.")
                    }
                }
                ForEach(coordinator.displayStatuses) { status in
                    DisplayCard(coordinator: coordinator, status: status)
                }
                GroupsCard(coordinator: coordinator)
                WorkspacesCard(coordinator: coordinator)
                capabilityLegend
            }
            .padding(Metrics.gutter)
        }
        .navigationTitle("Displays")
    }

    private var capabilityLegend: some View {
        Card {
            VStack(alignment: .leading, spacing: 8) {
                SectionLabel(text: "What Daylight can and cannot control")
                Text("""
                Warmth and dimming are applied through each display's colour transfer table. That is a real change to what the display shows, and it is removed when Daylight quits.

                By default Daylight does not change your display's backlight. macOS provides no public way for an app to do that, so what this app calls brightness is software dimming: it lowers the values sent to the panel. The screen looks dimmer, but the backlight, its power draw and any flicker are unchanged.

                Some external monitors accept brightness commands over their video cable. That is off by default and can be switched on under Settings › Experimental; it never applies to a built-in display.

                Daylight does not alter your colour profiles or calibration data.
                """)
                .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                .fixedSize(horizontal: false, vertical: true)
            }
        }
    }
}

struct DisplayCard: View {
    @ObservedObject var coordinator: LightingCoordinator
    let status: DisplayStatus

    private var settings: DisplaySettings {
        coordinator.settings.settings(forDisplay: status.id)
    }

    var body: some View {
        Card {
            VStack(alignment: .leading, spacing: 12) {
                header
                Divider()
                facts
                if !status.capabilities.notes.isEmpty || status.isAmbiguous || status.isMirrored
                    || status.foreignChangeDetected || status.lastErrorMessage != nil
                    || coordinator.settings.group(containing: status.id) != nil {
                    notices
                }
                Divider()
                controls
            }
        }
    }

    private var header: some View {
        HStack(spacing: 10) {
            Image(systemName: status.isBuiltIn ? "laptopcomputer" : "display")
                .font(.system(size: 18)).foregroundStyle(Palette.secondaryText)
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 2) {
                TextField("Display name", text: Binding(
                    get: { settings.customName ?? status.name },
                    set: { name in
                        update { $0.customName = name.isEmpty ? nil : name }
                    }))
                    .textFieldStyle(.plain).font(.daylightTitle)
                    .accessibilityLabel("Name for this display")
                Text(status.isBuiltIn ? "Built-in display" : "External display")
                    .font(.daylightCaption).foregroundStyle(Palette.tertiaryText)
            }
            Spacer()
            Text(status.connection.displayName)
                .font(.daylightCaption)
                .padding(.horizontal, 8).padding(.vertical, 3)
                .background(Capsule().fill(connectionColour.opacity(0.15)))
                .foregroundStyle(connectionColour)
        }
    }

    private var connectionColour: Color {
        switch status.connection {
        case .connected: return Palette.positive
        case .asleep: return Palette.warning
        case .disconnected: return Palette.tertiaryText
        }
    }

    private var facts: some View {
        VStack(spacing: 7) {
            FactRow(label: "Warmth now",
                    value: status.isExcluded ? "Not managed" : Format.kelvin(status.appliedTarget.temperature),
                    detail: status.isExcluded ? "This display is excluded from automation" : nil)
            FactRow(label: "Software dimming",
                    value: status.isExcluded ? "—" : Format.percent(status.appliedTarget.dimming.factor))
            FactRow(label: "Colour control",
                    value: status.capabilities.supportsColourTransform ? "Supported" : "Not supported",
                    detail: status.capabilities.supportsColourTransform
                        ? "\(status.capabilities.transferTableCapacity)-entry transfer table" : nil,
                    tone: status.capabilities.supportsColourTransform ? .normal : .warning)
            FactRow(label: "Hardware brightness",
                    value: status.capabilities.supportsHardwareBrightness ? "Available over DDC" : "Not available",
                    detail: hardwareBrightnessDetail,
                    tone: status.capabilities.supportsHardwareBrightness ? .positive : .normal)
            FactRow(label: "Last change",
                    value: status.confidence.shortLabel,
                    detail: confidenceDetail,
                    tone: status.confidence == .readbackConfirmed ? .positive : .normal)
        }
    }

    private var confidenceDetail: String {
        switch status.confidence {
        case .readbackConfirmed:
            return "Daylight read the setting back and it matches"
        case .acceptedBySystem:
            return "macOS accepted the change, but it could not be read back to confirm"
        case .requested:
            return "No change has been applied yet"
        }
    }

    private var hardwareBrightnessDetail: String {
        if status.capabilities.supportsHardwareBrightness {
            return "This display answered a DDC query. Experimental."
        }
        if status.isBuiltIn {
            return "macOS offers no public way for an app to change a built-in backlight"
        }
        if coordinator.settings.experimentalDDCBrightness {
            return "This display did not answer a DDC brightness query"
        }
        return "macOS offers no public way for an app to change the backlight"
    }

    private var notices: some View {
        VStack(spacing: 8) {
            if let error = status.lastErrorMessage {
                NoticeBanner(kind: .warning, message: error)
            }
            if status.foreignChangeDetected {
                NoticeBanner(kind: .warning,
                             message: "Another display utility may be changing this display too. While both are running they will keep overwriting each other.")
            }
            if status.isAmbiguous {
                NoticeBanner(kind: .info,
                             message: "Another connected display reports exactly the same identity as this one, so the two share these settings. Daylight will not guess which is which.")
            }
            if status.isMirrored {
                NoticeBanner(kind: .info,
                             message: "This display is mirrored, so it shares its output with the display it mirrors.")
            }
            if let group = coordinator.settings.group(containing: status.id) {
                NoticeBanner(kind: .info,
                             message: "Linked into “\(group.name)”. The limits below are shared with the other displays in that group; its name and whether it is left alone stay separate.")
            }
            if status.baselineSource == .rejectedForeignTransform {
                NoticeBanner(kind: .info,
                             message: "This display's colour table did not look neutral when Daylight started, so a plain baseline is being used instead of adopting another app's adjustment.")
            }
            ForEach(status.capabilities.notes, id: \.self) { note in
                NoticeBanner(kind: .info, message: note)
            }
        }
    }

    private var controls: some View {
        VStack(alignment: .leading, spacing: 12) {
            Toggle("Leave this display alone", isOn: Binding(
                get: { settings.isExcluded },
                set: { on in update { $0.isExcluded = on } }))
                .toggleStyle(.checkbox)
                .help("Daylight will not write to this display at all.")

            if !settings.isExcluded, status.capabilities.supportsHardwareBrightness {
                Toggle("Use this display's backlight instead of software dimming", isOn: Binding(
                    get: { settings.prefersHardwareBrightness },
                    set: { on in update { $0.prefersHardwareBrightness = on } }))
                    .toggleStyle(.checkbox)
                    .help("Changes the real backlight over DDC. Experimental.")
            }

            if !settings.isExcluded {
                VStack(alignment: .leading, spacing: 3) {
                    HStack {
                        Text("Warmth range").font(.daylightCaption)
                            .foregroundStyle(Palette.secondaryText)
                        Spacer()
                        Text(verbatim: "\(Int(settings.minimumKelvin)) K – \(Int(settings.maximumKelvin)) K")
                            .font(.system(size: 11, design: .rounded)).monospacedDigit()
                    }
                    limitSlider(title: "Warmest allowed",
                                value: settings.minimumKelvin,
                                range: ColourTemperature.advancedRange,
                                format: { "\(Int($0)) K" }) { v in
                        // Keep the pair ordered rather than letting the ends
                        // cross and silently swap on the next validate().
                        update {
                            $0.minimumKelvin = min(v, $0.maximumKelvin)
                        }
                    }
                    limitSlider(title: "Coolest allowed",
                                value: settings.maximumKelvin,
                                range: ColourTemperature.advancedRange,
                                format: { "\(Int($0)) K" }) { v in
                        update { $0.maximumKelvin = max(v, $0.minimumKelvin) }
                    }
                    Text("Daylight will never take this display outside this range, whatever the schedule or a rule asks for.")
                        .font(.system(size: 10)).foregroundStyle(Palette.secondaryText)
                        .fixedSize(horizontal: false, vertical: true)
                }

                limitSlider(title: "Dimmest allowed",
                            value: settings.minimumDimming,
                            range: SoftwareDimming.range,
                            format: { Format.percent($0) }) { v in update { $0.minimumDimming = v } }

                limitSlider(title: "Brightness offset",
                            value: settings.dimmingOffset,
                            range: -0.5...0.5,
                            format: { String(format: "%+.0f%%", $0 * 100) }) { v in
                    update { $0.dimmingOffset = v }
                }
            }
        }
    }

    @ViewBuilder
    private func limitSlider(title: String, value: Double, range: ClosedRange<Double>,
                             format: @escaping (Double) -> String,
                             onSet: @escaping (Double) -> Void) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack {
                Text(title).font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                Spacer()
                Text(format(value)).font(.system(size: 11, design: .rounded)).monospacedDigit()
            }
            Slider(value: Binding(get: { value }, set: onSet), in: range)
                .controlSize(.small)
                .accessibilityLabel("\(title) for \(status.name)")
                .accessibilityValue(format(value))
        }
    }

    /// Writes go wherever the value is actually read from.
    ///
    /// For a linked display the limits live on the group, so editing them here
    /// has to update the group — otherwise the edit would be written to the
    /// display's own settings, immediately overridden by the group's, and
    /// appear to do nothing.
    private func update(_ change: (inout DisplaySettings) -> Void) {
        if let group = coordinator.settings.group(containing: status.id),
           let gi = coordinator.settings.groups.firstIndex(where: { $0.id == group.id }) {
            // Name and exclusion stay per-display even inside a group.
            var probe = group.settings
            let before = (probe.customName, probe.isExcluded)
            change(&probe)
            let nameOrExclusionChanged = (probe.customName, probe.isExcluded) != before
            if nameOrExclusionChanged {
                writeOwn(change)
            } else {
                coordinator.settings.groups[gi].settings = probe
            }
            return
        }
        writeOwn(change)
    }

    private func writeOwn(_ change: (inout DisplaySettings) -> Void) {
        var all = coordinator.settings.displays
        if let i = all.firstIndex(where: { $0.id == status.id }) {
            change(&all[i])
        } else {
            var fresh = DisplaySettings(id: status.id)
            change(&fresh)
            all.append(fresh)
        }
        coordinator.settings.displays = all
    }
}


// MARK: - Groups

/// Linking displays so they behave identically.
struct GroupsCard: View {
    @ObservedObject var coordinator: LightingCoordinator

    var body: some View {
        Card {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    SectionLabel(text: "Linked displays")
                    Spacer()
                    if coordinator.displayStatuses.count >= 2 {
                        Button("Link all displays") { linkAll() }.controlSize(.small)
                    }
                }
                Text("Linked displays share one set of limits. Names and exclusions stay separate, so you can still leave one of them alone.")
                    .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                    .fixedSize(horizontal: false, vertical: true)

                if coordinator.displayStatuses.count < 2 {
                    Text("Linking needs at least two displays connected.")
                        .font(.daylightCaption).foregroundStyle(Palette.tertiaryText)
                }

                ForEach(coordinator.settings.groups) { group in
                    HStack(alignment: .top, spacing: 8) {
                        Image(systemName: "link").foregroundStyle(Palette.secondaryText)
                            .accessibilityHidden(true)
                        VStack(alignment: .leading, spacing: 2) {
                            TextField("Group name", text: Binding(
                                get: { group.name },
                                set: { rename(group, to: $0) }))
                                .textFieldStyle(.plain).font(.daylightBody)
                                .accessibilityLabel("Group name")
                            Text(memberNames(group))
                                .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                        }
                        Spacer()
                        Button("Unlink") { unlink(group) }.controlSize(.small)
                    }
                    .padding(.vertical, 3)
                    .accessibilityElement(children: .contain)
                }
            }
        }
    }

    private func memberNames(_ group: DisplayGroup) -> String {
        let names = group.memberKeys.map { key in
            coordinator.displayStatuses.first { $0.id == key }?.name ?? "A display that is not connected"
        }
        return names.joined(separator: " and ")
    }

    private func linkAll() {
        let keys = coordinator.displayStatuses.map(\.id)
        guard keys.count >= 2 else { return }
        var group = DisplayGroup(name: "Linked displays", memberKeys: keys)
        // Seed the shared limits from the first member, so linking does not
        // silently change how anything looks.
        group.settings = coordinator.settings.settings(forDisplay: keys[0])
        coordinator.settings.groups = [group]
    }

    private func rename(_ group: DisplayGroup, to name: String) {
        guard let i = coordinator.settings.groups.firstIndex(where: { $0.id == group.id }) else { return }
        coordinator.settings.groups[i].name = name
    }

    /// Unlinking hands each display the group's limits as its own starting
    /// point, so nothing jumps at the moment you unlink.
    private func unlink(_ group: DisplayGroup) {
        var displays = coordinator.settings.displays
        for key in group.memberKeys {
            var seeded = group.settings
            seeded.id = key
            seeded.groupID = nil
            if let existing = displays.firstIndex(where: { $0.id == key }) {
                seeded.customName = displays[existing].customName
                seeded.isExcluded = displays[existing].isExcluded
                displays[existing] = seeded
            } else {
                displays.append(seeded)
            }
        }
        coordinator.settings.displays = displays
        coordinator.settings.groups.removeAll { $0.id == group.id }
    }
}

// MARK: - Workspaces

/// Places you work, recognised by which displays are attached.
struct WorkspacesCard: View {
    @ObservedObject var coordinator: LightingCoordinator

    var body: some View {
        Card {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    SectionLabel(text: "Workspaces")
                    Spacer()
                    Button("Add this setup") { addCurrent() }
                        .controlSize(.small)
                        .disabled(coordinator.displayStatuses.isEmpty)
                }
                Text("A workspace is recognised by which displays are connected — nothing else. Daylight never asks macOS where you are.")
                    .font(.daylightCaption).foregroundStyle(Palette.secondaryText)
                    .fixedSize(horizontal: false, vertical: true)

                if coordinator.settings.workspaces.isEmpty {
                    EmptyStateView(
                        symbol: "mappin.and.ellipse",
                        title: "No workspaces yet",
                        message: "Add one while you are set up somewhere, and Daylight will recognise the same arrangement of displays next time.")
                }

                ForEach(coordinator.settings.workspaces) { workspace in
                    WorkspaceRow(
                        workspace: workspace,
                        isActive: coordinator.activeWorkspace?.id == workspace.id,
                        schedules: coordinator.settings.schedules,
                        onChange: { update($0) },
                        onDelete: { coordinator.settings.workspaces.removeAll { $0.id == workspace.id } })
                    if workspace.id != coordinator.settings.workspaces.last?.id { Divider() }
                }
            }
        }
    }

    private func addCurrent() {
        let keys = Set(coordinator.displayStatuses.map(\.id))
        guard !coordinator.settings.workspaces.contains(where: { $0.requiredDisplayKeys == keys }) else { return }
        let name = keys.count > 1 ? "Desk (\(keys.count) displays)" : "This setup"
        coordinator.settings.workspaces.append(
            Workspace(name: name, requiredDisplayKeys: keys))
    }

    private func update(_ workspace: Workspace) {
        guard let i = coordinator.settings.workspaces.firstIndex(where: { $0.id == workspace.id })
        else { return }
        coordinator.settings.workspaces[i] = workspace
    }
}

struct WorkspaceRow: View {
    let workspace: Workspace
    let isActive: Bool
    let schedules: [Schedule]
    let onChange: (Workspace) -> Void
    let onDelete: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 8) {
                Toggle("", isOn: Binding(
                    get: { workspace.isEnabled },
                    set: { var w = workspace; w.isEnabled = $0; onChange(w) }))
                    .toggleStyle(.switch).controlSize(.mini).labelsHidden()
                    .accessibilityLabel("\(workspace.name) enabled")
                TextField("Name", text: Binding(
                    get: { workspace.name },
                    set: { var w = workspace; w.name = $0; onChange(w) }))
                    .textFieldStyle(.plain).font(.daylightBody).frame(width: 150, alignment: .leading)
                    .accessibilityLabel("Workspace name")
                if isActive {
                    Text("here now")
                        .font(.system(size: 10))
                        .padding(.horizontal, 6).padding(.vertical, 2)
                        .background(Capsule().fill(Palette.accentSoft))
                        .foregroundStyle(Palette.accent)
                }
                Spacer()
                Button { onDelete() } label: {
                    Image(systemName: "minus.circle").foregroundStyle(Palette.secondaryText)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Delete workspace \(workspace.name)")
            }
            Text(workspace.summary)
                .font(.system(size: 10)).foregroundStyle(Palette.secondaryText)
            HStack(spacing: 8) {
                Text("Schedule").font(.system(size: 10)).foregroundStyle(Palette.secondaryText)
                Picker("", selection: Binding(
                    get: { workspace.scheduleID },
                    set: { var w = workspace; w.scheduleID = $0; onChange(w) })) {
                    Text("Keep the active one").tag(UUID?.none)
                    ForEach(schedules) { Text($0.name).tag(UUID?.some($0.id)) }
                }
                .labelsHidden().controlSize(.small).frame(width: 190)
                .accessibilityLabel("Schedule for \(workspace.name)")
            }
        }
        .padding(.vertical, 3)
    }
}
