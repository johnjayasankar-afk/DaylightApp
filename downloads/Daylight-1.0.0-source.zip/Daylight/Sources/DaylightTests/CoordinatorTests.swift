import Foundation
import DaylightCore
import DaylightDisplay

/// End-to-end tests of the real coordinator driving simulated devices.
///
/// These exercise the paths that only appear once scheduling, rules, overrides
/// and hardware writes are wired together — expiry, pausing, restoration and
/// per-display limits.
final class CoordinatorIntegrationTests: DaylightTestCase {

    var dir: URL!
    var store: SettingsStore!
    var coordinator: LightingCoordinator!

    override func setUp() {
        dir = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent("daylight-coord-\(UUID().uuidString)")
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        store = SettingsStore(directory: dir)

        var settings = Presets.defaultSettings()
        settings.hasCompletedOnboarding = true
        settings.transitionSpeed = .immediate
        // A single all-day anchor makes the expected value unambiguous.
        let schedule = Schedule(name: "Fixed", weekdayAnchors: [
            Presets.anchor("All day", 0, 0, 3000, 0.8, transition: 0)
        ])
        settings.schedules = [schedule]
        settings.activeScheduleID = schedule.id
        try? store.save(settings)

        coordinator = LightingCoordinator(store: store, useSimulation: true)
        coordinator.start()
        pump()
    }

    override func tearDown() {
        coordinator.shutdown(restore: true)
        try? FileManager.default.removeItem(at: dir)
    }

    /// Lets the coordinator's main-queue work run.
    func pump(_ seconds: TimeInterval = 0.25) {
        RunLoop.current.run(until: Date().addingTimeInterval(seconds))
    }

    func testScheduleReachesTheDevices() {
        coordinator.tick(force: true); pump()
        XCTAssertFalse(coordinator.displayStatuses.isEmpty, "simulated displays should be present")
        for status in coordinator.displayStatuses {
            XCTAssertEqual(status.appliedTarget.temperature.kelvin, 3000, accuracy: 1)
            XCTAssertEqual(status.appliedTarget.dimming.factor, 0.8, accuracy: 0.001)
        }
    }

    func testPauseGoesNeutralAndResumeReturns() {
        coordinator.pauseAutomation(for: 3600); pump()
        XCTAssertEqual(coordinator.outcome.target.temperature.kelvin,
                       ColourTemperature.neutral.kelvin, accuracy: 1)
        XCTAssertTrue(coordinator.outcome.explanation.contains("paused"))

        coordinator.resumeAutomation(); pump()
        XCTAssertEqual(coordinator.outcome.target.temperature.kelvin, 3000, accuracy: 1)
    }

    func testOverrideAppliesThenExpiresBackToTheSchedule() {
        coordinator.setManualTarget(temperature: ColourTemperature(kelvin: 5200),
                                    expiry: .duration(0.4))
        pump(0.1)
        XCTAssertEqual(coordinator.outcome.target.temperature.kelvin, 5200, accuracy: 1)
        XCTAssertNotNil(coordinator.activeOverride)

        pump(0.8)
        coordinator.tick(force: true); pump()
        XCTAssertNil(coordinator.activeOverride, "the override should have expired on its own")
        XCTAssertEqual(coordinator.outcome.target.temperature.kelvin, 3000, accuracy: 1,
                       "the schedule should be recomputed, not replayed")
    }

    func testProfileOverrideIsAttributedInThePlainLanguageExplanation() {
        let reading = coordinator.settings.profiles.first { $0.name == "Reading" }!
        coordinator.applyProfile(reading, expiry: .untilResumed); pump()
        XCTAssertEqual(coordinator.activeOverride?.label, "Reading")
        XCTAssertTrue(coordinator.outcome.explanation.contains("manually")
                      || coordinator.outcome.explanation.contains("Reading"),
                      coordinator.outcome.explanation)
    }

    func testEmergencyRestoreGoesNeutralImmediately() {
        coordinator.setManualTarget(temperature: ColourTemperature(kelvin: 2400),
                                    expiry: .untilResumed)
        pump()
        coordinator.emergencyRestore(); pump()
        XCTAssertEqual(coordinator.outcome.target.temperature.kelvin,
                       ColourTemperature.neutral.kelvin, accuracy: 1)
        XCTAssertTrue(coordinator.outcome.explanation.contains("Restore"),
                      coordinator.outcome.explanation)
    }

    func testResumeClearsAnEmergencyRestore() {
        coordinator.emergencyRestore(); pump()
        coordinator.resumeAutomation(); pump()
        XCTAssertEqual(coordinator.outcome.target.temperature.kelvin, 3000, accuracy: 1)
    }

    func testAutomationOffHoldsNeutralAcrossTicks() {
        coordinator.setAutomation(enabled: false); pump()
        coordinator.tick(force: true); pump()
        XCTAssertEqual(coordinator.outcome.target.temperature.kelvin,
                       ColourTemperature.neutral.kelvin, accuracy: 1)
        coordinator.setAutomation(enabled: true); pump()
        XCTAssertEqual(coordinator.outcome.target.temperature.kelvin, 3000, accuracy: 1)
    }

    func testPreviewAppliesThenCleansUpOnCancel() {
        coordinator.startPreview(label: "Test",
                                 target: ResolvedTarget(temperature: ColourTemperature(kelvin: 2200),
                                                        dimming: SoftwareDimming(factor: 0.5)),
                                 seconds: 30)
        pump()
        XCTAssertEqual(coordinator.outcome.target.temperature.kelvin, 2200, accuracy: 1)
        XCTAssertNotNil(coordinator.preview)

        coordinator.cancelPreview(); pump()
        XCTAssertNil(coordinator.preview)
        XCTAssertEqual(coordinator.outcome.target.temperature.kelvin, 3000, accuracy: 1,
                       "cancelling a preview must return to the schedule, not leave the preview value")
    }

    func testPreviewExpiresOnItsOwn() {
        coordinator.startPreview(label: "Test", target: ResolvedTarget(
            temperature: ColourTemperature(kelvin: 2200), dimming: .none), seconds: 0.3)
        pump(0.1)
        XCTAssertNotNil(coordinator.preview)
        pump(0.6)
        XCTAssertNil(coordinator.preview, "a preview must clean itself up without being told")
        XCTAssertEqual(coordinator.outcome.target.temperature.kelvin, 3000, accuracy: 1)
    }

    func testPerDisplayLimitsAreApplied() {
        guard let first = coordinator.displayStatuses.first else { return XCTFail("no displays") }
        coordinator.settings.displays = [
            DisplaySettings(id: first.id, minimumDimming: 0.9, minimumKelvin: 4000, maximumKelvin: 6500)
        ]
        pump()
        coordinator.tick(force: true); pump()
        guard let updated = coordinator.displayStatuses.first(where: { $0.id == first.id }) else {
            return XCTFail("display disappeared")
        }
        XCTAssertEqual(updated.appliedTarget.temperature.kelvin, 4000, accuracy: 1,
                       "the display's own warmth limit should win over the schedule")
        XCTAssertEqual(updated.appliedTarget.dimming.factor, 0.9, accuracy: 0.001)
    }

    func testExcludedDisplayIsLeftAlone() {
        guard let first = coordinator.displayStatuses.first else { return XCTFail("no displays") }
        coordinator.settings.displays = [DisplaySettings(id: first.id, isExcluded: true)]
        pump()
        coordinator.tick(force: true); pump()
        let updated = coordinator.displayStatuses.first { $0.id == first.id }
        XCTAssertEqual(updated?.isExcluded, true)
    }

    func testSettingsSurviveARestart() {
        coordinator.settings.transitionSpeed = .veryGentle
        coordinator.settings.advancedWarmthRange = true
        pump(0.3)
        coordinator.shutdown(restore: true)

        let second = LightingCoordinator(store: store, useSimulation: true)
        XCTAssertEqual(second.settings.transitionSpeed, TransitionSpeed.veryGentle)
        XCTAssertTrue(second.settings.advancedWarmthRange)
        second.shutdown(restore: false)
        // Re-established so tearDown has something valid to shut down.
        coordinator = LightingCoordinator(store: store, useSimulation: true)
        coordinator.start()
    }

    func testWakeRecomputesRatherThanReplaying() {
        // Simulate the wake path directly: it must land on the current
        // scheduled value in one step.
        coordinator.setManualTarget(temperature: ColourTemperature(kelvin: 5500),
                                    expiry: .duration(0.1))
        pump(0.4)
        coordinator.displayManagerDidWake(DisplayManager(useSimulation: true))
        pump(0.4)
        XCTAssertEqual(coordinator.outcome.target.temperature.kelvin, 3000, accuracy: 1)
    }

    func testTimelineExposesTheNextChange() {
        var settings = coordinator.settings
        let schedule = Schedule(name: "Two step", weekdayAnchors: [
            Presets.anchor("Day", 9, 0, 6500, 1.0, transition: 0),
            Presets.anchor("Evening", 19, 0, 3000, 0.8, transition: 30),
        ])
        settings.schedules = [schedule]
        settings.activeScheduleID = schedule.id
        coordinator.settings = settings
        pump(0.3)
        XCTAssertNotNil(coordinator.evaluation.nextChangeAt)
        XCTAssertGreaterThan(coordinator.evaluation.nextChangeAt ?? .distantPast, Date())
    }
}

final class ExperimentalBrightnessTests: DaylightTestCase {

    func testDDCIsOffByDefault() {
        XCTAssertFalse(Presets.defaultSettings().experimentalDDCBrightness,
                       "an experiment that uses private API must not be on by default")
    }

    func testNoDisplayPrefersHardwareBrightnessByDefault() {
        let s = Presets.defaultSettings()
        XCTAssertFalse(s.settings(forDisplay: "anything").prefersHardwareBrightness)
    }

    func testTheFlagSurvivesSaveAndLoad() {
        let dir = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent("daylight-ddc-\(UUID().uuidString)")
        defer { try? FileManager.default.removeItem(at: dir) }
        let store = SettingsStore(directory: dir)
        var s = Presets.defaultSettings()
        s.experimentalDDCBrightness = true
        s.displays = [DisplaySettings(id: "x", prefersHardwareBrightness: true)]
        try? store.save(s)
        let back = store.load().settings
        XCTAssertTrue(back.experimentalDDCBrightness)
        XCTAssertTrue(back.settings(forDisplay: "x").prefersHardwareBrightness)
    }

    func testSimulatedDevicesNeverClaimHardwareBrightness() {
        // Simulation must not imply a capability the real path has not proven.
        let d = SimulatedDisplayDevice()
        XCTAssertFalse(d.capabilities.supportsHardwareBrightness)
    }

    func testHardwareRoutingReplacesSoftwareDimmingRatherThanCompounding() {
        // The rule the coordinator implements: when brightness goes to the
        // backlight, software dimming is left at full, or the screen would be
        // darker than either setting asks for.
        let base = ResolvedTarget(temperature: ColourTemperature(kelvin: 3000),
                                  dimming: SoftwareDimming(factor: 0.6))
        let routed = ResolvedTarget(temperature: base.temperature,
                                    dimming: .none,
                                    hardwareBrightness: HardwareBrightness(level: base.dimming.factor))
        XCTAssertEqual(routed.hardwareBrightness?.level ?? 0, 0.6, accuracy: 0.001)
        XCTAssertEqual(routed.dimming.factor, 1.0, accuracy: 0.001)
        XCTAssertEqual(routed.gains.red, base.gains.red / 0.6, accuracy: 0.01,
                       "the gamma path must no longer be dimming")
    }
}

/// Scoped manual changes, driven through the real coordinator.
final class ScopedOverrideIntegrationTests: DaylightTestCase {

    var dir: URL!
    var coordinator: LightingCoordinator!

    override func setUp() {
        dir = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent("daylight-scope-\(UUID().uuidString)")
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let store = SettingsStore(directory: dir)
        var settings = Presets.defaultSettings()
        settings.hasCompletedOnboarding = true
        settings.transitionSpeed = .immediate
        let schedule = Schedule(name: "Fixed", weekdayAnchors: [
            Presets.anchor("All day", 0, 0, 4000, 0.9, transition: 0)
        ])
        settings.schedules = [schedule]
        settings.activeScheduleID = schedule.id
        try? store.save(settings)
        coordinator = LightingCoordinator(store: store, useSimulation: true)
        coordinator.start()
        pump()
    }

    override func tearDown() {
        coordinator.shutdown(restore: true)
        try? FileManager.default.removeItem(at: dir)
    }

    func pump(_ seconds: TimeInterval = 0.3) {
        RunLoop.current.run(until: Date().addingTimeInterval(seconds))
    }

    func testBothDisplaysFollowTheScheduleToBeginWith() {
        XCTAssertEqual(coordinator.displayStatuses.count, 2)
        for status in coordinator.displayStatuses {
            XCTAssertEqual(status.appliedTarget.temperature.kelvin, 4000, accuracy: 1)
        }
    }

    func testAChangeScopedToOneDisplayLeavesTheOtherAlone() {
        guard let first = coordinator.displayStatuses.first else { return XCTFail("no displays") }
        coordinator.setManualTarget(temperature: ColourTemperature(kelvin: 2800),
                                    expiry: .untilResumed,
                                    scope: .display(key: first.id))
        pump()
        for status in coordinator.displayStatuses {
            if status.id == first.id {
                XCTAssertEqual(status.appliedTarget.temperature.kelvin, 2800, accuracy: 1,
                               "the targeted display should change")
            } else {
                XCTAssertEqual(status.appliedTarget.temperature.kelvin, 4000, accuracy: 1,
                               "the other display must keep following the schedule")
            }
        }
    }

    func testAnUnscopedChangeMovesEverything() {
        coordinator.setManualTarget(temperature: ColourTemperature(kelvin: 3000),
                                    expiry: .untilResumed, scope: .allDisplays)
        pump()
        for status in coordinator.displayStatuses {
            XCTAssertEqual(status.appliedTarget.temperature.kelvin, 3000, accuracy: 1)
        }
    }

    func testAGroupScopedChangeMovesOnlyItsMembers() {
        let keys = coordinator.displayStatuses.map(\.id)
        guard keys.count == 2 else { return XCTFail("expected two displays") }
        let group = DisplayGroup(name: "Pair", memberKeys: [keys[0]])
        // A group of one is dropped by validation, so pair it with a key that
        // is not attached — the point is that the second display is excluded.
        var settings = coordinator.settings
        settings.groups = [DisplayGroup(name: "Pair", memberKeys: [keys[0], "uuid:absent"])]
        coordinator.settings = settings
        pump()
        _ = group

        guard let groupID = coordinator.settings.groups.first?.id else { return XCTFail("no group") }
        coordinator.setManualTarget(temperature: ColourTemperature(kelvin: 3200),
                                    expiry: .untilResumed, scope: .group(id: groupID))
        pump()
        let a = coordinator.displayStatuses.first { $0.id == keys[0] }
        let b = coordinator.displayStatuses.first { $0.id == keys[1] }
        XCTAssertEqual(a?.appliedTarget.temperature.kelvin ?? 0, 3200, accuracy: 1)
        XCTAssertEqual(b?.appliedTarget.temperature.kelvin ?? 0, 4000, accuracy: 1)
    }

    func testChangingScopeStartsFreshRatherThanCarryingValuesAcross() {
        guard let first = coordinator.displayStatuses.first else { return XCTFail("no displays") }
        coordinator.setManualTarget(temperature: ColourTemperature(kelvin: 2500),
                                    expiry: .untilResumed, scope: .display(key: first.id))
        pump()
        // Switching to "all displays" and setting only brightness must not drag
        // the previous per-display warmth along with it.
        coordinator.setManualTarget(dimming: SoftwareDimming(factor: 0.5),
                                    expiry: .untilResumed, scope: .allDisplays)
        pump()
        XCTAssertNil(coordinator.activeOverride?.target.temperature,
                     "a fresh scope starts from nothing")
        for status in coordinator.displayStatuses {
            XCTAssertEqual(status.appliedTarget.temperature.kelvin, 4000, accuracy: 1)
            XCTAssertEqual(status.appliedTarget.dimming.factor, 0.5, accuracy: 0.01)
        }
    }

    func testAValueBelowADisplaysOwnFloorIsClampedNotApplied() {
        guard let first = coordinator.displayStatuses.first else { return XCTFail("no displays") }
        // The default floor is the normal range's lower bound. Asking for
        // something warmer than a display allows must be clamped, not obeyed.
        coordinator.setManualTarget(temperature: ColourTemperature(kelvin: 2000),
                                    expiry: .untilResumed, scope: .display(key: first.id))
        pump()
        let applied = coordinator.displayStatuses.first { $0.id == first.id }?.appliedTarget
        XCTAssertEqual(applied?.temperature.kelvin ?? 0,
                       ColourTemperature.normalRange.lowerBound, accuracy: 1)
    }

    func testResumingClearsAScopedChangeEverywhere() {
        guard let first = coordinator.displayStatuses.first else { return XCTFail("no displays") }
        coordinator.setManualTarget(temperature: ColourTemperature(kelvin: 2800),
                                    expiry: .untilResumed, scope: .display(key: first.id))
        pump()
        coordinator.resumeAutomation()
        pump()
        for status in coordinator.displayStatuses {
            XCTAssertEqual(status.appliedTarget.temperature.kelvin, 4000, accuracy: 1)
        }
    }
}
