import Foundation
import DaylightCore

final class PersistenceTests: DaylightTestCase {

    var dir: URL!
    var store: SettingsStore!

    override func setUp() {
        dir = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent("daylight-tests-\(UUID().uuidString)")
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        store = SettingsStore(directory: dir)
    }

    override func tearDown() {
        try? FileManager.default.removeItem(at: dir)
    }

    func testFirstRunReturnsDefaultsAndSaysSo() {
        let o = store.load()
        XCTAssertTrue(o.isFirstRun)
        XCTAssertFalse(o.recoveredFromCorruption)
        XCTAssertFalse(o.settings.hasCompletedOnboarding)
        XCTAssertFalse(o.settings.schedules.isEmpty)
    }

    func testRoundTripPreservesSettings() {
        var s = Presets.defaultSettings()
        s.hasCompletedOnboarding = true
        s.transitionSpeed = .veryGentle
        s.location = GeoLocation(latitude: 51.5, longitude: -0.12, label: "London")
        s.displays = [DisplaySettings(id: "uuid:abc", customName: "Desk monitor", minimumDimming: 0.4)]
        XCTAssertNoThrow(try store.save(s))
        let loaded = store.load().settings
        XCTAssertTrue(loaded.hasCompletedOnboarding)
        XCTAssertEqual(loaded.transitionSpeed, TransitionSpeed.veryGentle)
        XCTAssertEqual(loaded.location?.label, "London")
        XCTAssertEqual(loaded.displays.first?.customName, "Desk monitor")
    }

    func testWriteIsAtomicAndLeavesNoTemporaryFiles() {
        try? store.save(Presets.defaultSettings())
        let files = try! FileManager.default.contentsOfDirectory(atPath: dir.path)
        XCTAssertFalse(files.contains { $0.hasSuffix(".tmp") }, "temporary files must not survive a save")
        XCTAssertTrue(files.contains("settings.json"))
    }

    func testCorruptedFileRecoversFromBackup() {
        var s = Presets.defaultSettings()
        s.hasCompletedOnboarding = true
        try? store.save(s)              // creates settings.json
        s.transitionSpeed = .immediate
        try? store.save(s)              // copies the previous file to the backup
        try! Data("{ not json at all".utf8).write(to: dir.appendingPathComponent("settings.json"))

        let o = store.load()
        XCTAssertTrue(o.recoveredFromCorruption)
        XCTAssertTrue(o.settings.hasCompletedOnboarding, "the recovered settings are the user's, not defaults")
    }

    func testTotallyUnrecoverableStateFallsBackToDefaultsAndSaysSo() {
        try! Data("garbage".utf8).write(to: dir.appendingPathComponent("settings.json"))
        let o = store.load()
        XCTAssertTrue(o.recoveredFromCorruption)
        XCTAssertFalse(o.settings.schedules.isEmpty)
    }

    func testMigrationFromOlderSchemaVersion() {
        var s = Presets.defaultSettings()
        s.schemaVersion = 0
        let changed = SettingsStore.migrate(&s)
        XCTAssertTrue(changed)
        XCTAssertEqual(s.schemaVersion, DaylightSettings.currentSchemaVersion)
    }

    func testSettingsFromANewerBuildLoadRatherThanBeingRejected() {
        var s = Presets.defaultSettings()
        s.schemaVersion = 99
        SettingsStore.migrate(&s)
        XCTAssertEqual(s.schemaVersion, DaylightSettings.currentSchemaVersion)
    }

    func testValidationRepairsOutOfRangeValues() {
        var s = Presets.defaultSettings()
        s.schedules[0].weekdayAnchors[0].temperature = ColourTemperature(kelvin: 99_000)
        s.schedules[0].weekdayAnchors[0].dimming = SoftwareDimming(factor: -3)
        s.schedules[0].weekdayAnchors[0].transitionMinutes = 99_999
        s.displays = [DisplaySettings(id: "d", minimumDimming: 5, minimumKelvin: 9000, maximumKelvin: 100)]
        s.validate()
        let a = s.schedules[0].weekdayAnchors[0]
        XCTAssertLessThanOrEqual(a.temperature.kelvin, ColourTemperature.advancedRange.upperBound)
        XCTAssertGreaterThanOrEqual(a.dimming.factor, SoftwareDimming.safeFloor)
        XCTAssertLessThanOrEqual(a.transitionMinutes, 360)
        XCTAssertLessThanOrEqual(s.displays[0].minimumDimming, 1.0)
        XCTAssertLessThanOrEqual(s.displays[0].minimumKelvin, s.displays[0].maximumKelvin)
    }

    func testValidationRestoresAMissingActiveSchedule() {
        var s = Presets.defaultSettings()
        s.activeScheduleID = UUID()      // points at nothing
        s.validate()
        XCTAssertTrue(s.schedules.contains { $0.id == s.activeScheduleID })
    }

    func testValidationRejectsAnImpossibleLocation() {
        var s = Presets.defaultSettings()
        s.location = GeoLocation(latitude: 480, longitude: 900, label: "Bad")
        s.validate()
        XCTAssertNil(s.location)
    }

    func testExportImportRoundTrip() {
        var s = Presets.defaultSettings()
        s.transitionSpeed = .brisk
        let data = try! store.exportData(s)
        let back = try! store.importData(data)
        XCTAssertEqual(back.transitionSpeed, TransitionSpeed.brisk)
        XCTAssertTrue(back.hasCompletedOnboarding, "importing a configuration skips onboarding")
    }

    func testImportRejectsNonsense() {
        XCTAssertThrowsError(try store.importData(Data("<html>nope</html>".utf8)))
    }

    func testImportedValuesAreClampedBeforeUse() {
        // Imported files are untrusted: a hand-edited profile must not be able
        // to drive a display to an unusable value.
        var s = Presets.defaultSettings()
        s.schedules[0].weekdayAnchors[0].temperature = ColourTemperature(kelvin: 100)
        s.schedules[0].weekdayAnchors[0].dimming = SoftwareDimming(factor: 0.0)
        let data = try! JSONEncoder().encode(s)
        let back = try! store.importData(data)
        let a = back.schedules[0].weekdayAnchors[0]
        XCTAssertGreaterThanOrEqual(a.temperature.kelvin, ColourTemperature.advancedRange.lowerBound)
        XCTAssertGreaterThanOrEqual(a.dimming.factor, SoftwareDimming.safeFloor)
    }

    func testExportContainsNoSecrets() {
        // There are no integration credentials yet, but the guarantee is
        // asserted now so it cannot regress quietly later.
        let data = try! store.exportData(Presets.defaultSettings())
        let text = String(data: data, encoding: .utf8)!.lowercased()
        for word in ["token", "password", "secret", "apikey", "api_key", "bearer"] {
            XCTAssertFalse(text.contains(word), "exported settings must not contain \(word)")
        }
    }

    func testPerDisplayLimitsConstrainTheTarget() {
        let d = DisplaySettings(id: "x", minimumDimming: 0.5, minimumKelvin: 3000, maximumKelvin: 5000)
        let out = d.constrain(ResolvedTarget(temperature: ColourTemperature(kelvin: 2000),
                                             dimming: SoftwareDimming(factor: 0.2)))
        XCTAssertEqual(out.temperature.kelvin, 3000, accuracy: 1)
        XCTAssertEqual(out.dimming.factor, 0.5, accuracy: 0.001)
    }

    func testPerDisplayOffsetShiftsBrightnessWithinLimits() {
        let d = DisplaySettings(id: "x", minimumDimming: 0.2, dimmingOffset: -0.2)
        let out = d.constrain(ResolvedTarget(temperature: .neutral, dimming: SoftwareDimming(factor: 0.9)))
        XCTAssertEqual(out.dimming.factor, 0.7, accuracy: 0.001)
    }

    func testUnknownDisplayGetsSafeDefaultsNotSomeoneElsesSettings() {
        // A newly connected monitor must never inherit an extreme saved value.
        let s = Presets.defaultSettings()
        let d = s.settings(forDisplay: "uuid:brand-new-display")
        XCTAssertFalse(d.isExcluded)
        XCTAssertGreaterThanOrEqual(d.minimumDimming, 0.3)
        XCTAssertEqual(d.minimumKelvin, ColourTemperature.normalRange.lowerBound, accuracy: 1)
    }
}

final class DisplayIdentityTests: DaylightTestCase {

    func testUUIDIsPreferredOverEdidNumbers() {
        let k = DisplayIdentity.makeKey(uuid: "ABC-123", vendor: 1, model: 2, serial: 3, isBuiltIn: false)
        XCTAssertEqual(k, "uuid:ABC-123")
    }

    func testFallsBackToEdidWhenNoUUID() {
        let k = DisplayIdentity.makeKey(uuid: nil, vendor: 0x610, model: 0xa04e, serial: 0, isBuiltIn: false)
        XCTAssertTrue(k.hasPrefix("edid:"))
        XCTAssertEqual(k, DisplayIdentity.makeKey(uuid: nil, vendor: 0x610, model: 0xa04e,
                                                  serial: 0, isBuiltIn: false),
                       "the key must be stable across calls")
    }

    func testEmptyUUIDDoesNotProduceAUselessKey() {
        let k = DisplayIdentity.makeKey(uuid: "", vendor: 5, model: 6, serial: 7, isBuiltIn: false)
        XCTAssertTrue(k.hasPrefix("edid:"))
    }

    func testCompletelyUnidentifiableDisplayStillGetsAKey() {
        XCTAssertEqual(DisplayIdentity.makeKey(uuid: nil, vendor: 0, model: 0, serial: 0, isBuiltIn: true),
                       "builtin")
        XCTAssertEqual(DisplayIdentity.makeKey(uuid: nil, vendor: 0, model: 0, serial: 0, isBuiltIn: false),
                       "unknown")
    }

    func testIdenticalMonitorsProduceTheSameKey() {
        // Two of the same model with no serial genuinely cannot be told apart.
        // The app must notice that rather than pretending otherwise.
        let a = DisplayIdentity.makeKey(uuid: nil, vendor: 1, model: 2, serial: 0, isBuiltIn: false)
        let b = DisplayIdentity.makeKey(uuid: nil, vendor: 1, model: 2, serial: 0, isBuiltIn: false)
        XCTAssertEqual(a, b)
    }

    func testDifferentSerialsAreDistinguished() {
        let a = DisplayIdentity.makeKey(uuid: nil, vendor: 1, model: 2, serial: 10, isBuiltIn: false)
        let b = DisplayIdentity.makeKey(uuid: nil, vendor: 1, model: 2, serial: 11, isBuiltIn: false)
        XCTAssertNotEqual(a, b)
    }
}

final class BaselineValidatorTests: DaylightTestCase {

    func ramp(_ r: Float, _ g: Float, _ b: Float, n: Int = 256) -> ([Float], [Float], [Float]) {
        let base = (0..<n).map { Float($0) / Float(n - 1) }
        return (base.map { $0 * r }, base.map { $0 * g }, base.map { $0 * b })
    }

    func testPlainRampIsAcceptedAsABaseline() {
        let (r, g, b) = ramp(1, 1, 1)
        XCTAssertTrue(BaselineValidator.isPlausibleBaseline(red: r, green: g, blue: b))
    }

    func testSlightlyCalibratedProfileIsStillAccepted() {
        let (r, g, b) = ramp(1.0, 0.98, 0.96)
        XCTAssertTrue(BaselineValidator.isPlausibleBaseline(red: r, green: g, blue: b))
    }

    func testAnotherAppsWarmTransformIsRejected() {
        // These are the values actually read back from this machine while f.lux
        // was running. Adopting them as "neutral" would bake its tint into
        // Daylight's own baseline permanently.
        let (r, g, b) = ramp(1.0, 0.3606, 0.1000)
        XCTAssertFalse(BaselineValidator.isPlausibleBaseline(red: r, green: g, blue: b),
                       "a strongly tinted table must never be adopted as a baseline")
    }

    func testHeavilyDimmedTableIsRejected() {
        let (r, g, b) = ramp(0.3, 0.3, 0.3)
        XCTAssertFalse(BaselineValidator.isPlausibleBaseline(red: r, green: g, blue: b))
    }

    func testNonMonotonicTableIsRejected() {
        var (r, g, b) = ramp(1, 1, 1)
        r[100] = 0.0
        XCTAssertFalse(BaselineValidator.isPlausibleBaseline(red: r, green: g, blue: b))
    }

    func testEmptyTableIsRejected() {
        XCTAssertFalse(BaselineValidator.isPlausibleBaseline(red: [], green: [], blue: []))
    }
}

/// Loading settings files written by *earlier builds*.
///
/// These exist because the original migration test only bumped a version
/// number on a current struct, which proved nothing. Adding one field to
/// `DaylightSettings` made every real settings file fail to decode, and the
/// app silently replaced the user's whole configuration with defaults. These
/// tests use literal older payloads so that cannot happen again unnoticed.
final class SettingsForwardCompatibilityTests: DaylightTestCase {

    var dir: URL!
    var store: SettingsStore!

    override func setUp() {
        dir = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent("daylight-compat-\(UUID().uuidString)")
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        store = SettingsStore(directory: dir)
    }
    override func tearDown() { try? FileManager.default.removeItem(at: dir) }

    /// Exactly the shape the first shipped build wrote: no workspaces, no
    /// groups' settings, no break reminders, no DDC flag.
    let originalRelease = """
    {
      "schemaVersion": 1,
      "activeScheduleID": "11111111-1111-1111-1111-111111111111",
      "automationEnabled": true,
      "hasCompletedOnboarding": true,
      "launchAtLogin": false,
      "showsMenuBarPercentage": false,
      "respectsReducedMotion": true,
      "appRulesEnabled": false,
      "warnOnExtremeSettings": true,
      "advancedWarmthRange": true,
      "transitionSpeed": "veryGentle",
      "displays": [
        {"id":"uuid:abc","customName":"Desk monitor","isExcluded":false,
         "minimumDimming":0.42,"minimumKelvin":3100,"maximumKelvin":6500,"dimmingOffset":0}
      ],
      "groups": [], "rules": [], "profiles": [],
      "schedules": [{
        "id": "11111111-1111-1111-1111-111111111111",
        "name": "My schedule",
        "usesSeparateWeekend": false,
        "weekendDays": [1,7],
        "weekendAnchors": [],
        "weekdayAnchors": [
          {"id":"22222222-2222-2222-2222-222222222222","name":"All day","isEnabled":true,
           "time":{"clock":{"secondsFromMidnight":0}},
           "temperature":{"kelvin":3000},"dimming":{"factor":0.85},"transitionMinutes":0}
        ]
      }]
    }
    """

    func testAFileFromTheFirstReleaseStillLoads() {
        try! Data(originalRelease.utf8).write(to: dir.appendingPathComponent("settings.json"))
        let outcome = store.load()
        XCTAssertFalse(outcome.recoveredFromCorruption,
                       "an older but valid settings file must not be treated as corrupt")
        XCTAssertEqual(outcome.settings.activeSchedule?.name, "My schedule")
        XCTAssertEqual(outcome.settings.schedules.count, 1)
        XCTAssertTrue(outcome.settings.hasCompletedOnboarding)
        XCTAssertTrue(outcome.settings.advancedWarmthRange)
        XCTAssertEqual(outcome.settings.transitionSpeed, TransitionSpeed.veryGentle)
    }

    func testTheUsersOwnAnchorsSurviveIntact() {
        try! Data(originalRelease.utf8).write(to: dir.appendingPathComponent("settings.json"))
        let s = store.load().settings
        guard let anchor = s.activeSchedule?.weekdayAnchors.first else {
            return XCTFail("the schedule's anchors were lost")
        }
        XCTAssertEqual(anchor.name, "All day")
        XCTAssertEqual(anchor.temperature.kelvin, 3000, accuracy: 1)
        XCTAssertEqual(anchor.dimming.factor, 0.85, accuracy: 0.001)
    }

    func testPerDisplaySettingsSurviveIntact() {
        try! Data(originalRelease.utf8).write(to: dir.appendingPathComponent("settings.json"))
        let d = store.load().settings.settings(forDisplay: "uuid:abc")
        XCTAssertEqual(d.customName, "Desk monitor")
        XCTAssertEqual(d.minimumDimming, 0.42, accuracy: 0.001)
        XCTAssertEqual(d.minimumKelvin, 3100, accuracy: 1)
    }

    func testFieldsAddedLaterTakeTheirDefaults() {
        try! Data(originalRelease.utf8).write(to: dir.appendingPathComponent("settings.json"))
        let s = store.load().settings
        XCTAssertTrue(s.workspaces.isEmpty)
        XCTAssertFalse(s.breakReminders.isEnabled)
        XCTAssertFalse(s.experimentalDDCBrightness)
        XCTAssertFalse(s.settings(forDisplay: "uuid:abc").prefersHardwareBrightness)
    }

    func testAnAlmostEmptyFileStillProducesAUsableConfiguration() {
        try! Data("{}".utf8).write(to: dir.appendingPathComponent("settings.json"))
        let outcome = store.load()
        XCTAssertFalse(outcome.settings.schedules.isEmpty)
        XCTAssertTrue(outcome.settings.schedules.contains { $0.id == outcome.settings.activeScheduleID })
    }

    func testAFileWithUnknownFutureFieldsStillLoads() {
        let future = """
        {"schemaVersion": 1, "somethingFromTheFuture": {"a": 1},
         "transitionSpeed": "brisk", "hasCompletedOnboarding": true}
        """
        try! Data(future.utf8).write(to: dir.appendingPathComponent("settings.json"))
        let s = store.load().settings
        XCTAssertEqual(s.transitionSpeed, TransitionSpeed.brisk)
        XCTAssertTrue(s.hasCompletedOnboarding)
    }

    func testASingleUnreadableFieldDoesNotDiscardEverythingElse() {
        // A hand-edited or partially corrupted value should cost that value,
        // not the whole configuration.
        let damaged = """
        {"schemaVersion": 1, "transitionSpeed": "not-a-real-speed",
         "hasCompletedOnboarding": true, "advancedWarmthRange": true}
        """
        try! Data(damaged.utf8).write(to: dir.appendingPathComponent("settings.json"))
        let s = store.load().settings
        XCTAssertTrue(s.hasCompletedOnboarding, "the readable fields must survive")
        XCTAssertTrue(s.advancedWarmthRange)
        XCTAssertEqual(s.transitionSpeed, TransitionSpeed.gentle, "the bad field falls back")
    }

    func testRoundTripThroughTheCurrentFormatIsStable() {
        try! Data(originalRelease.utf8).write(to: dir.appendingPathComponent("settings.json"))
        let first = store.load().settings
        try! store.save(first)
        let second = store.load().settings
        XCTAssertEqual(first.activeSchedule?.name, second.activeSchedule?.name)
        XCTAssertEqual(first.schedules.count, second.schedules.count)
        XCTAssertEqual(first.transitionSpeed, second.transitionSpeed)
    }
}
