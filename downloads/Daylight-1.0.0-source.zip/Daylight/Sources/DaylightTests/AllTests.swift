import Foundation

/// Every suite in the project. Adding a test class means adding it here.
enum AllTests {
    static let suites: [AnyClass] = [
        ColourScienceTests.self,
        SolarTests.self,
        CityTests.self,
        CitySearchNormalisationTests.self,
        LocationTimeZoneTests.self,
        ScheduleResolutionTests.self,
        PrecedenceTests.self,
        OverrideTests.self,
        RulesTests.self,
        TransitionTests.self,
        PersistenceTests.self,
        SettingsForwardCompatibilityTests.self,
        DisplayIdentityTests.self,
        BaselineValidatorTests.self,
        DeviceAdapterTests.self,
        CoordinatorIntegrationTests.self,
        WorkspaceTests.self,
        DisplayGroupTests.self,
        GroupEditingTests.self,
        BreakReminderTests.self,
        CommandPaletteTests.self,
        HistoryTests.self,
        ExtremeSettingsTests.self,
        OverrideScopeTests.self,
        DDCProtocolTests.self,
        SleepingDisplayTests.self,
        ExperimentalBrightnessTests.self,
        ScopedOverrideIntegrationTests.self,
    ]
}
