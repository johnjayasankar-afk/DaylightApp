import Foundation
import ObjectiveC

/// A minimal test harness.
///
/// The toolchain available here (Command Line Tools, no Xcode) ships neither
/// XCTest nor swift-testing, so this provides the small slice of the XCTest
/// surface the suite uses. Test classes are discovered through the ObjC
/// runtime exactly as XCTest does, so the test files themselves stay portable:
/// swapping `DaylightTestCase` for `XCTestCase` is the whole migration.

@objcMembers open class DaylightTestCase: NSObject {
    public required override init() { super.init() }
    open func setUp() {}
    open func tearDown() {}
}

public struct Failure {
    public var test: String
    public var message: String
    public var file: String
    public var line: Int
}

public enum TestRegistry {
    nonisolated(unsafe) public static var failures: [Failure] = []
    nonisolated(unsafe) public static var currentTest = ""
    nonisolated(unsafe) public static var assertions = 0

    static func record(_ message: String, _ file: StaticString, _ line: UInt) {
        failures.append(Failure(test: currentTest, message: message,
                                file: URL(fileURLWithPath: "\(file)").lastPathComponent,
                                line: Int(line)))
    }
}

// MARK: - Assertions (XCTest-compatible names and signatures)

public func XCTFail(_ message: String = "", file: StaticString = #filePath, line: UInt = #line) {
    TestRegistry.assertions += 1
    TestRegistry.record(message.isEmpty ? "failed" : message, file, line)
}

public func XCTAssertTrue(_ expression: @autoclosure () -> Bool, _ message: String = "",
                          file: StaticString = #filePath, line: UInt = #line) {
    TestRegistry.assertions += 1
    if !expression() { TestRegistry.record(message.isEmpty ? "expected true" : message, file, line) }
}

public func XCTAssertFalse(_ expression: @autoclosure () -> Bool, _ message: String = "",
                           file: StaticString = #filePath, line: UInt = #line) {
    TestRegistry.assertions += 1
    if expression() { TestRegistry.record(message.isEmpty ? "expected false" : message, file, line) }
}

public func XCTAssertEqual<T: Equatable>(_ a: @autoclosure () -> T, _ b: @autoclosure () -> T,
                                         _ message: String = "",
                                         file: StaticString = #filePath, line: UInt = #line) {
    TestRegistry.assertions += 1
    let (x, y) = (a(), b())
    if x != y {
        TestRegistry.record(message.isEmpty ? "\(x) != \(y)" : "\(message) — \(x) != \(y)", file, line)
    }
}

public func XCTAssertNotEqual<T: Equatable>(_ a: @autoclosure () -> T, _ b: @autoclosure () -> T,
                                            _ message: String = "",
                                            file: StaticString = #filePath, line: UInt = #line) {
    TestRegistry.assertions += 1
    if a() == b() { TestRegistry.record(message.isEmpty ? "values are equal" : message, file, line) }
}

public func XCTAssertEqual<T: FloatingPoint>(_ a: @autoclosure () -> T, _ b: @autoclosure () -> T,
                                             accuracy: T, _ message: String = "",
                                             file: StaticString = #filePath, line: UInt = #line) {
    TestRegistry.assertions += 1
    let (x, y) = (a(), b())
    if !(abs(x - y) <= accuracy) {
        TestRegistry.record(message.isEmpty ? "\(x) is not within \(accuracy) of \(y)"
                                            : "\(message) — \(x) vs \(y)", file, line)
    }
}

public func XCTAssertNil(_ expression: @autoclosure () -> Any?, _ message: String = "",
                         file: StaticString = #filePath, line: UInt = #line) {
    TestRegistry.assertions += 1
    if let v = expression() { TestRegistry.record(message.isEmpty ? "expected nil, got \(v)" : message, file, line) }
}

public func XCTAssertNotNil(_ expression: @autoclosure () -> Any?, _ message: String = "",
                            file: StaticString = #filePath, line: UInt = #line) {
    TestRegistry.assertions += 1
    if expression() == nil { TestRegistry.record(message.isEmpty ? "expected a value" : message, file, line) }
}

public func XCTAssertGreaterThan<T: Comparable>(_ a: @autoclosure () -> T, _ b: @autoclosure () -> T,
                                                _ message: String = "",
                                                file: StaticString = #filePath, line: UInt = #line) {
    TestRegistry.assertions += 1
    let (x, y) = (a(), b())
    if !(x > y) { TestRegistry.record(message.isEmpty ? "\(x) is not > \(y)" : message, file, line) }
}

public func XCTAssertGreaterThanOrEqual<T: Comparable>(_ a: @autoclosure () -> T, _ b: @autoclosure () -> T,
                                                       _ message: String = "",
                                                       file: StaticString = #filePath, line: UInt = #line) {
    TestRegistry.assertions += 1
    let (x, y) = (a(), b())
    if !(x >= y) { TestRegistry.record(message.isEmpty ? "\(x) is not >= \(y)" : message, file, line) }
}

public func XCTAssertLessThan<T: Comparable>(_ a: @autoclosure () -> T, _ b: @autoclosure () -> T,
                                             _ message: String = "",
                                             file: StaticString = #filePath, line: UInt = #line) {
    TestRegistry.assertions += 1
    let (x, y) = (a(), b())
    if !(x < y) { TestRegistry.record(message.isEmpty ? "\(x) is not < \(y)" : message, file, line) }
}

public func XCTAssertLessThanOrEqual<T: Comparable>(_ a: @autoclosure () -> T, _ b: @autoclosure () -> T,
                                                    _ message: String = "",
                                                    file: StaticString = #filePath, line: UInt = #line) {
    TestRegistry.assertions += 1
    let (x, y) = (a(), b())
    if !(x <= y) { TestRegistry.record(message.isEmpty ? "\(x) is not <= \(y)" : message, file, line) }
}

public func XCTAssertThrowsError<T>(_ expression: @autoclosure () throws -> T, _ message: String = "",
                                    file: StaticString = #filePath, line: UInt = #line,
                                    _ handler: (Error) -> Void = { _ in }) {
    TestRegistry.assertions += 1
    do { _ = try expression(); TestRegistry.record(message.isEmpty ? "expected an error" : message, file, line) }
    catch { handler(error) }
}

public func XCTAssertNoThrow<T>(_ expression: @autoclosure () throws -> T, _ message: String = "",
                                file: StaticString = #filePath, line: UInt = #line) {
    TestRegistry.assertions += 1
    do { _ = try expression() }
    catch { TestRegistry.record(message.isEmpty ? "unexpected error: \(error)" : message, file, line) }
}

// MARK: - Runner

@main
struct TestMain {
    static func main() {
        let started = Date()
        var suites: [(String, [String])] = []

        // Suites are listed explicitly rather than discovered by walking the
        // whole ObjC class list: that walk trips over runtime-internal classes
        // that do not respond to ordinary messages.
        let discovered: [AnyClass] = AllTests.suites



        var passed = 0, failedTests = 0
        for cls in discovered {
            let name = String(describing: cls)
            var methodCount: UInt32 = 0
            guard let methods = class_copyMethodList(cls, &methodCount) else { continue }
            var selectors: [Selector] = []
            for j in 0..<Int(methodCount) {
                let sel = method_getName(methods[j])
                let n = NSStringFromSelector(sel)
                if n.hasPrefix("test") && !n.contains(":") { selectors.append(sel) }
            }
            free(UnsafeMutableRawPointer(methods))
            selectors.sort { NSStringFromSelector($0) < NSStringFromSelector($1) }
            guard !selectors.isEmpty else { continue }

            var names: [String] = []
            for sel in selectors {
                let testName = "\(name).\(NSStringFromSelector(sel))"
                TestRegistry.currentTest = testName
                let before = TestRegistry.failures.count
                guard let type = cls as? DaylightTestCase.Type else { continue }
                let instance = type.init()
                instance.setUp()
                _ = instance.perform(sel)
                instance.tearDown()
                if TestRegistry.failures.count == before { passed += 1 } else { failedTests += 1 }
                names.append(testName)
            }
            suites.append((name, names))
        }

        let elapsed = Date().timeIntervalSince(started)
        print("")
        for (suite, tests) in suites {
            let suiteFailures = TestRegistry.failures.filter { $0.test.hasPrefix(suite + ".") }
            let mark = suiteFailures.isEmpty ? "ok  " : "FAIL"
            print("\(mark) \(suite)  (\(tests.count) tests)")
        }
        if !TestRegistry.failures.isEmpty {
            print("\nFailures:")
            for f in TestRegistry.failures {
                print("  ✗ \(f.test)\n      \(f.message)\n      \(f.file):\(f.line)")
            }
        }
        print("""

        \(passed + failedTests) tests, \(TestRegistry.assertions) assertions, \
        \(failedTests) failed  —  \(String(format: "%.3f", elapsed))s
        """)
        exit(TestRegistry.failures.isEmpty ? 0 : 1)
    }
}
