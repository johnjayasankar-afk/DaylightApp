import Foundation
import DaylightCore

func tz(_ id: String) -> TimeZone { TimeZone(identifier: id)! }

func date(_ y: Int, _ m: Int, _ d: Int, _ h: Int, _ min: Int, _ zone: TimeZone) -> Date {
    var cal = Calendar(identifier: .gregorian); cal.timeZone = zone
    return cal.date(from: DateComponents(year: y, month: m, day: d, hour: h, minute: min))!
}

final class ColourScienceTests: DaylightTestCase {

    func testNeutralProducesIdentityGains() {
        let g = channelGains(for: .neutral)
        XCTAssertEqual(g.red, 1.0, accuracy: 0.02)
        XCTAssertEqual(g.green, 1.0, accuracy: 0.02)
        XCTAssertEqual(g.blue, 1.0, accuracy: 0.02)
    }

    func testWarmerReducesBlueMoreThanRed() {
        let g = channelGains(for: ColourTemperature(kelvin: 3000))
        XCTAssertEqual(g.red, 1.0, accuracy: 0.001, "red should stay at full scale")
        XCTAssertLessThan(g.blue, g.green)
        XCTAssertLessThan(g.green, g.red)
    }

    func testGainsNeverExceedOne() {
        // Gains above 1 would clip against the panel's white point.
        for k in stride(from: 1900.0, through: 6500.0, by: 100) {
            let g = channelGains(for: ColourTemperature(kelvin: k))
            XCTAssertLessThanOrEqual(g.red, 1.0001)
            XCTAssertLessThanOrEqual(g.green, 1.0001)
            XCTAssertLessThanOrEqual(g.blue, 1.0001)
            XCTAssertGreaterThan(g.red, 0.0)
        }
    }

    func testGainsAreMonotonicInTemperature() {
        var lastBlue = 0.0
        for k in stride(from: 2000.0, through: 6500.0, by: 100) {
            let b = channelGains(for: ColourTemperature(kelvin: k)).blue
            XCTAssertGreaterThanOrEqual(b, lastBlue - 1e-9, "blue must rise with temperature at \(k)K")
            lastBlue = b
        }
    }

    func testMiredInterpolationIsPerceptuallyEvenNotLinearKelvin() {
        let a = ColourTemperature(kelvin: 2000), b = ColourTemperature(kelvin: 6500)
        let mid = ColourTemperature.interpolate(a, b, 0.5)
        // Linear kelvin would land at 4250 K. Mired lands considerably warmer,
        // which is the point: it matches how the change actually looks.
        XCTAssertEqual(mid.mired, (a.mired + b.mired) / 2, accuracy: 0.01)
        XCTAssertLessThan(mid.kelvin, 3200.0)
        XCTAssertGreaterThan(mid.kelvin, 3000.0)
    }

    func testInterpolationClampsOutOfRangeProgress() {
        let a = ColourTemperature(kelvin: 3000), b = ColourTemperature(kelvin: 6000)
        XCTAssertEqual(ColourTemperature.interpolate(a, b, -5).kelvin, 3000, accuracy: 0.001)
        XCTAssertEqual(ColourTemperature.interpolate(a, b, 5).kelvin, 6000, accuracy: 0.001)
    }

    func testDimmingScalesAllChannelsEqually() {
        let t = ResolvedTarget(temperature: .neutral, dimming: SoftwareDimming(factor: 0.5))
        let g = t.gains
        XCTAssertEqual(g.red, 0.5, accuracy: 0.02)
        XCTAssertEqual(g.green, 0.5, accuracy: 0.02)
        XCTAssertEqual(g.blue, 0.5, accuracy: 0.02)
    }

    func testDimmingFloorIsEnforced() {
        let d = SoftwareDimming(factor: 0.01).clamped()
        XCTAssertEqual(d.factor, SoftwareDimming.safeFloor, accuracy: 1e-9)
    }
}

final class SolarTests: DaylightTestCase {

    func testLondonMidsummerSunriseIsEarly() {
        let london = GeoLocation(latitude: 51.5074, longitude: -0.1278, label: "London")
        let z = tz("Europe/London")
        let r = SolarCalculator.event(.sunrise, date: date(2026, 6, 21, 12, 0, z),
                                      location: london, timeZone: z)
        guard let s = r.seconds else { return XCTFail("expected a sunrise") }
        XCTAssertEqual(s / 3600, 4.72, accuracy: 0.25)   // about 04:43 BST
    }

    func testLondonMidwinterSunsetIsEarly() {
        let london = GeoLocation(latitude: 51.5074, longitude: -0.1278, label: "London")
        let z = tz("Europe/London")
        let r = SolarCalculator.event(.sunset, date: date(2026, 12, 21, 12, 0, z),
                                      location: london, timeZone: z)
        guard let s = r.seconds else { return XCTFail("expected a sunset") }
        XCTAssertEqual(s / 3600, 15.87, accuracy: 0.3)   // about 15:52 GMT
    }

    func testSydneySouthernHemisphere() {
        let sydney = GeoLocation(latitude: -33.8688, longitude: 151.2093, label: "Sydney")
        let z = tz("Australia/Sydney")
        let r = SolarCalculator.event(.sunrise, date: date(2026, 12, 21, 12, 0, z),
                                      location: sydney, timeZone: z)
        guard let s = r.seconds else { return XCTFail("expected a sunrise") }
        XCTAssertEqual(s / 3600, 5.7, accuracy: 0.4)
    }

    func testPolarNightIsReportedNotFaked() {
        let tromso = GeoLocation(latitude: 69.6496, longitude: 18.9560, label: "Tromso")
        let z = tz("Europe/Oslo")
        let r = SolarCalculator.event(.sunrise, date: date(2026, 12, 21, 12, 0, z),
                                      location: tromso, timeZone: z)
        XCTAssertEqual(r, .polarNight)
        XCTAssertNil(r.seconds)
    }

    func testPolarDayIsReportedNotFaked() {
        let tromso = GeoLocation(latitude: 69.6496, longitude: 18.9560, label: "Tromso")
        let z = tz("Europe/Oslo")
        let r = SolarCalculator.event(.sunset, date: date(2026, 6, 21, 12, 0, z),
                                      location: tromso, timeZone: z)
        XCTAssertEqual(r, .polarDay)
    }

    func testLeapDayResolves() {
        let paris = GeoLocation(latitude: 48.8566, longitude: 2.3522, label: "Paris")
        let z = tz("Europe/Paris")
        let r = SolarCalculator.event(.sunrise, date: date(2028, 2, 29, 12, 0, z),
                                      location: paris, timeZone: z)
        XCTAssertNotNil(r.seconds)
    }

    func testInvalidLocationDoesNotCrash() {
        let bad = GeoLocation(latitude: 999, longitude: 999, label: "Nowhere")
        let r = SolarCalculator.event(.sunrise, date: Date(), location: bad, timeZone: .current)
        XCTAssertNil(r.seconds)
    }

    func testSunriseIsBeforeSunsetEverywhereReasonable() {
        let z = tz("UTC")
        for lat in stride(from: -60.0, through: 60.0, by: 15) {
            let loc = GeoLocation(latitude: lat, longitude: 0, label: "test")
            let rise = SolarCalculator.event(.sunrise, date: date(2026, 4, 15, 12, 0, z),
                                             location: loc, timeZone: z)
            let set = SolarCalculator.event(.sunset, date: date(2026, 4, 15, 12, 0, z),
                                            location: loc, timeZone: z)
            if let a = rise.seconds, let b = set.seconds {
                XCTAssertLessThan(a, b, "sunrise should precede sunset at latitude \(lat)")
            }
        }
    }
}

final class ScheduleResolutionTests: DaylightTestCase {

    func simpleSchedule() -> Schedule {
        Schedule(name: "Test", weekdayAnchors: [
            Presets.anchor("Morning", 7, 0, 6500, 1.0, transition: 30),
            Presets.anchor("Evening", 19, 0, 4000, 0.9, transition: 60),
            Presets.anchor("Night", 23, 0, 2700, 0.7, transition: 60),
        ])
    }

    func testHoldsAnchorValueBetweenTransitions() {
        let z = tz("Europe/London")
        let tl = ScheduleResolver.timeline(for: simpleSchedule(), on: date(2026, 4, 15, 12, 0, z),
                                           timeZone: z, location: nil)
        let ev = tl.evaluate(at: date(2026, 4, 15, 12, 0, z))
        XCTAssertEqual(ev.target.temperature.kelvin, 6500, accuracy: 1)
        XCTAssertEqual(ev.currentAnchorName, "Morning")
        if case .holding = ev.phase {} else { XCTFail("expected a hold at midday") }
    }

    func testReachesAnchorValueExactlyAtAnchorTime() {
        let z = tz("Europe/London")
        let tl = ScheduleResolver.timeline(for: simpleSchedule(), on: date(2026, 4, 15, 12, 0, z),
                                           timeZone: z, location: nil)
        let ev = tl.evaluate(at: date(2026, 4, 15, 19, 0, z))
        XCTAssertEqual(ev.target.temperature.kelvin, 4000, accuracy: 5)
    }

    func testTransitionIsHalfwayAtMidRamp() {
        let z = tz("Europe/London")
        let tl = ScheduleResolver.timeline(for: simpleSchedule(), on: date(2026, 4, 15, 12, 0, z),
                                           timeZone: z, location: nil)
        let ev = tl.evaluate(at: date(2026, 4, 15, 18, 30, z))   // ramp runs 18:00 -> 19:00
        guard case .transitioning(_, let to, let p) = ev.phase else {
            return XCTFail("expected a transition")
        }
        XCTAssertEqual(to, "Evening")
        XCTAssertEqual(p, 0.5, accuracy: 0.01)
        let expected = ColourTemperature.interpolate(ColourTemperature(kelvin: 6500),
                                                     ColourTemperature(kelvin: 4000), 0.5)
        XCTAssertEqual(ev.target.temperature.kelvin, expected.kelvin, accuracy: 5)
    }

    func testAfterMidnightUsesPreviousDayAnchor() {
        let z = tz("Europe/London")
        let tl = ScheduleResolver.timeline(for: simpleSchedule(), on: date(2026, 4, 15, 2, 0, z),
                                           timeZone: z, location: nil)
        let ev = tl.evaluate(at: date(2026, 4, 15, 2, 0, z))
        XCTAssertEqual(ev.target.temperature.kelvin, 2700, accuracy: 1)
        XCTAssertEqual(ev.currentAnchorName, "Night")
    }

    func testNightShiftScheduleThatWakesInTheEvening() {
        // Someone who wakes at 20:00 and sleeps at 11:00. Nothing in the engine
        // assumes "night" means "asleep".
        let s = Schedule(name: "Night shift", weekdayAnchors: [
            Presets.anchor("Wake", 20, 0, 6500, 1.0, transition: 30),
            Presets.anchor("Shift", 22, 0, 6000, 1.0, transition: 30),
            Presets.anchor("Wind down", 9, 0, 3000, 0.8, transition: 60),
            Presets.anchor("Sleep", 11, 0, 2700, 0.6, transition: 30),
        ])
        let z = tz("Europe/London")
        let tl = ScheduleResolver.timeline(for: s, on: date(2026, 4, 15, 3, 0, z),
                                           timeZone: z, location: nil)
        let ev = tl.evaluate(at: date(2026, 4, 15, 3, 0, z))
        XCTAssertEqual(ev.target.temperature.kelvin, 6000, accuracy: 1)
        XCTAssertEqual(ev.currentAnchorName, "Shift")
        let ev2 = tl.evaluate(at: date(2026, 4, 15, 12, 0, z))
        XCTAssertEqual(ev2.target.temperature.kelvin, 2700, accuracy: 1)
    }

    func testWeekendScheduleUsedOnSaturday() {
        var s = simpleSchedule()
        s.usesSeparateWeekend = true
        s.weekendAnchors = [Presets.anchor("Lazy morning", 10, 0, 6500, 1.0, transition: 30)]
        let z = tz("Europe/London")
        let tl = ScheduleResolver.timeline(for: s, on: date(2026, 4, 18, 12, 0, z),
                                           timeZone: z, location: nil)   // a Saturday
        XCTAssertEqual(tl.evaluate(at: date(2026, 4, 18, 12, 0, z)).currentAnchorName, "Lazy morning")
    }

    func testCustomWeekendDaysForNonWesternWeek() {
        var s = simpleSchedule()
        s.usesSeparateWeekend = true
        s.weekendDays = [6, 7]        // Friday and Saturday
        s.weekendAnchors = [Presets.anchor("Rest", 11, 0, 5000, 1.0, transition: 30)]
        let z = tz("Asia/Dubai")
        let tl = ScheduleResolver.timeline(for: s, on: date(2026, 4, 17, 14, 0, z),
                                           timeZone: z, location: nil)   // a Friday
        XCTAssertEqual(tl.evaluate(at: date(2026, 4, 17, 14, 0, z)).currentAnchorName, "Rest")
    }

    func testWeekendBoundaryUsesTheRightDaysAnchorsAcrossMidnight() {
        var s = Schedule(name: "Boundary", weekdayAnchors: [
            Presets.anchor("Weekday night", 23, 0, 2700, 0.7, transition: 30)
        ])
        s.usesSeparateWeekend = true
        s.weekendAnchors = [Presets.anchor("Weekend night", 23, 0, 3500, 0.9, transition: 30)]
        let z = tz("Europe/London")
        // Early Saturday: the value in force came from Friday's schedule.
        let tl = ScheduleResolver.timeline(for: s, on: date(2026, 4, 18, 2, 0, z),
                                           timeZone: z, location: nil)
        let ev = tl.evaluate(at: date(2026, 4, 18, 2, 0, z))
        XCTAssertEqual(ev.currentAnchorName, "Weekday night")
        XCTAssertEqual(ev.target.temperature.kelvin, 2700, accuracy: 1)
    }

    func testSpringForwardKeepsWallClockAnchors() {
        // 2026-03-08, America/New_York: 02:00 -> 03:00.
        let z = tz("America/New_York")
        let tl = ScheduleResolver.timeline(for: simpleSchedule(), on: date(2026, 3, 8, 12, 0, z),
                                           timeZone: z, location: nil)
        let ev = tl.evaluate(at: date(2026, 3, 8, 19, 0, z))
        XCTAssertEqual(ev.target.temperature.kelvin, 4000, accuracy: 5)
    }

    func testSpringForwardShortDayKeepsTimelineContinuous() {
        let z = tz("America/New_York")
        let tl = ScheduleResolver.timeline(for: simpleSchedule(), on: date(2026, 3, 8, 12, 0, z),
                                           timeZone: z, location: nil)
        let ev = tl.evaluate(at: date(2026, 3, 8, 1, 0, z))
        XCTAssertEqual(ev.currentAnchorName, "Night")
        XCTAssertEqual(ev.target.temperature.kelvin, 2700, accuracy: 1)
    }

    func testFallBackAmbiguousHourResolvesDeterministically() {
        // 2026-11-01, America/New_York: 01:00-02:00 happens twice.
        let z = tz("America/New_York")
        let tl = ScheduleResolver.timeline(for: simpleSchedule(), on: date(2026, 11, 1, 12, 0, z),
                                           timeZone: z, location: nil)
        let first = tl.evaluate(at: date(2026, 11, 1, 1, 30, z))
        XCTAssertEqual(first.currentAnchorName, "Night")
        let second = tl.evaluate(at: date(2026, 11, 1, 1, 30, z).addingTimeInterval(3600))
        XCTAssertEqual(second.currentAnchorName, "Night")
    }

    func testSpringForwardGapAnchorIsPassedWhenTheClockJumps() {
        // An anchor at 02:30 on a spring-forward day: 02:30 never occurs, so
        // the clock goes 01:59:59 -> 03:00:00 and the anchor must count as
        // passed immediately rather than being skipped for the whole day.
        let s = Schedule(name: "Gap", weekdayAnchors: [
            Presets.anchor("Late night", 2, 30, 2700, 0.7, transition: 0),
            Presets.anchor("Morning", 8, 0, 6500, 1.0, transition: 0),
        ])
        let z = tz("America/New_York")
        let tl = ScheduleResolver.timeline(for: s, on: date(2026, 3, 8, 12, 0, z),
                                           timeZone: z, location: nil)
        let before = tl.evaluateAtWallClock(seconds: 1 * 3600 + 59 * 60)
        let after = tl.evaluateAtWallClock(seconds: 3 * 3600)
        XCTAssertEqual(before.currentAnchorName, "Morning", "still on yesterday's last anchor")
        XCTAssertEqual(after.currentAnchorName, "Late night", "the 02:30 anchor counts as passed")
    }

    func testFallBackRepeatedHourEvaluatesTheSameBothTimes() {
        // 01:30 happens twice on 2026-11-01. Wall-clock evaluation gives the
        // same answer for both, which is the predictable behaviour.
        let z = tz("America/New_York")
        let tl = ScheduleResolver.timeline(for: simpleSchedule(), on: date(2026, 11, 1, 12, 0, z),
                                           timeZone: z, location: nil)
        let a = tl.evaluate(at: date(2026, 11, 1, 1, 30, z))
        let b = tl.evaluate(at: date(2026, 11, 1, 1, 30, z).addingTimeInterval(3600))
        XCTAssertEqual(a.target, b.target)
        XCTAssertEqual(a.currentAnchorName, "Night")
    }

    func testTimeZoneChangeRebuildsToLocalWallClock() {
        let london = tz("Europe/London"), tokyo = tz("Asia/Tokyo")
        let s = simpleSchedule()
        let inLondon = ScheduleResolver.timeline(for: s, on: date(2026, 4, 15, 12, 0, london),
                                                  timeZone: london, location: nil)
        let inTokyo = ScheduleResolver.timeline(for: s, on: date(2026, 4, 15, 12, 0, tokyo),
                                                 timeZone: tokyo, location: nil)
        XCTAssertEqual(inLondon.evaluate(at: date(2026, 4, 15, 12, 0, london)).currentAnchorName, "Morning")
        XCTAssertEqual(inTokyo.evaluate(at: date(2026, 4, 15, 12, 0, tokyo)).currentAnchorName, "Morning")
    }

    func testSolarAnchorWithoutLocationFallsBackAndExplains() {
        let s = Schedule(name: "Solar", weekdayAnchors: [
            ScheduleAnchor(name: "Sundown",
                           time: .solar(event: .sunset, offsetMinutes: 0, earliest: nil, latest: nil),
                           temperature: ColourTemperature(kelvin: 3500), transitionMinutes: 30)
        ])
        let z = tz("Europe/London")
        let tl = ScheduleResolver.timeline(for: s, on: date(2026, 4, 15, 12, 0, z),
                                           timeZone: z, location: nil)
        XCTAssertFalse(tl.diagnostics.isEmpty)
        XCTAssertTrue(tl.diagnostics.contains { $0.message.contains("No location is set") })
        XCTAssertEqual(tl.todayAnchors.first?.seconds ?? -1, 19 * 3600, accuracy: 1)
    }

    func testPolarNightFallsBackAndExplainsInPlainLanguage() {
        let s = Presets.solar()
        let tromso = GeoLocation(latitude: 69.6496, longitude: 18.9560, label: "Tromso")
        let z = tz("Europe/Oslo")
        let tl = ScheduleResolver.timeline(for: s, on: date(2026, 12, 21, 12, 0, z),
                                           timeZone: z, location: tromso)
        XCTAssertTrue(tl.diagnostics.contains { $0.message.contains("does not rise") },
                      "expected a plain-language polar-night explanation")
        let ev = tl.evaluate(at: date(2026, 12, 21, 20, 0, z))
        XCTAssertGreaterThan(ev.target.temperature.kelvin, 1000.0)
    }

    func testSolarClampKeepsWinterSunsetSensible() {
        let s = Presets.solar()
        let london = GeoLocation(latitude: 51.5074, longitude: -0.1278, label: "London")
        let z = tz("Europe/London")
        let tl = ScheduleResolver.timeline(for: s, on: date(2026, 12, 21, 12, 0, z),
                                           timeZone: z, location: london)
        guard let sunsetAnchor = tl.todayAnchors.first(where: { $0.anchor.name == "Sunset" }) else {
            return XCTFail("expected a sunset anchor")
        }
        // Real sunset-30min is about 15:22; the clamp holds it at 17:00.
        XCTAssertEqual(sunsetAnchor.seconds, 17 * 3600, accuracy: 1)
        if case .solarClamped(_, let side) = sunsetAnchor.origin {
            XCTAssertEqual(side, .earliest)
        } else {
            XCTFail("expected the anchor to report that it was clamped")
        }
    }

    func testConflictingAnchorsResolveDeterministicallyAndExplain() {
        // Place the clock anchor five minutes after the real sunset, so the two
        // genuinely collide regardless of the date this runs on.
        let loc = GeoLocation(latitude: 51.5074, longitude: -0.1278, label: "London")
        let z = tz("Europe/London")
        guard let sunset = SolarCalculator.event(.sunset, date: date(2026, 4, 15, 12, 0, z),
                                                 location: loc, timeZone: z).seconds else {
            return XCTFail("expected a sunset")
        }
        let clockSeconds = Int(sunset) + 5 * 60
        let s = Schedule(name: "Conflict", weekdayAnchors: [
            ScheduleAnchor(name: "Solar dusk",
                           time: .solar(event: .sunset, offsetMinutes: 0, earliest: nil, latest: nil),
                           temperature: ColourTemperature(kelvin: 4000), transitionMinutes: 30),
            ScheduleAnchor(name: "My evening",
                           time: .clock(secondsFromMidnight: clockSeconds),
                           temperature: ColourTemperature(kelvin: 3000),
                           dimming: SoftwareDimming(factor: 0.8), transitionMinutes: 30),
        ])
        let tl = ScheduleResolver.timeline(for: s, on: date(2026, 4, 15, 12, 0, z),
                                           timeZone: z, location: loc)
        let names = tl.todayAnchors.map(\.anchor.name)
        XCTAssertEqual(names.filter { $0 == "My evening" || $0 == "Solar dusk" }.count, 1,
                       "only one of two colliding anchors should survive")
        XCTAssertTrue(names.contains("My evening"), "an explicit clock anchor outranks a solar one")
        XCTAssertTrue(tl.diagnostics.contains { $0.message.contains("within 15 minutes") })
    }

    func testEmptyScheduleIsNeutralAndSaysSo() {
        let s = Schedule(name: "Empty", weekdayAnchors: [])
        let z = tz("Europe/London")
        let tl = ScheduleResolver.timeline(for: s, on: date(2026, 4, 15, 12, 0, z),
                                           timeZone: z, location: nil)
        XCTAssertEqual(tl.evaluate(at: date(2026, 4, 15, 12, 0, z)).target, ResolvedTarget.neutral)
        XCTAssertTrue(tl.diagnostics.contains { $0.message.contains("no enabled anchors") })
    }

    func testDisabledAnchorsAreIgnored() {
        var s = simpleSchedule()
        s.weekdayAnchors[1].isEnabled = false
        let z = tz("Europe/London")
        let tl = ScheduleResolver.timeline(for: s, on: date(2026, 4, 15, 12, 0, z),
                                           timeZone: z, location: nil)
        XCTAssertFalse(tl.todayAnchors.contains { $0.anchor.name == "Evening" })
    }

    func testWakingAfterSleepRecomputesRatherThanReplaying() {
        // The engine is a pure function of the clock, so a machine that slept
        // through three anchors lands on the right value in one evaluation.
        let z = tz("Europe/London")
        let tl = ScheduleResolver.timeline(for: simpleSchedule(), on: date(2026, 4, 15, 23, 30, z),
                                           timeZone: z, location: nil)
        let ev = tl.evaluate(at: date(2026, 4, 15, 23, 30, z))
        XCTAssertEqual(ev.target.temperature.kelvin, 2700, accuracy: 1)
        XCTAssertEqual(ev.currentAnchorName, "Night")
    }

    func testNextChangeIsInTheFuture() {
        let z = tz("Europe/London")
        let now = date(2026, 4, 15, 12, 0, z)
        let tl = ScheduleResolver.timeline(for: simpleSchedule(), on: now, timeZone: z, location: nil)
        let ev = tl.evaluate(at: now)
        XCTAssertNotNil(ev.nextChangeAt)
        if let n = ev.nextChangeAt { XCTAssertGreaterThan(n, now) }
    }

    func testZeroLengthTransitionSnapsWithoutDividingByZero() {
        let s = Schedule(name: "Snap", weekdayAnchors: [
            Presets.anchor("A", 8, 0, 6500, 1.0, transition: 0),
            Presets.anchor("B", 20, 0, 3000, 0.8, transition: 0),
        ])
        let z = tz("Europe/London")
        let tl = ScheduleResolver.timeline(for: s, on: date(2026, 4, 15, 12, 0, z),
                                           timeZone: z, location: nil)
        XCTAssertEqual(tl.evaluate(at: date(2026, 4, 15, 19, 59, z)).target.temperature.kelvin, 6500, accuracy: 1)
        XCTAssertEqual(tl.evaluate(at: date(2026, 4, 15, 20, 1, z)).target.temperature.kelvin, 3000, accuracy: 1)
    }

    func testSamplingCoversTheWholeDay() {
        let z = tz("Europe/London")
        let tl = ScheduleResolver.timeline(for: simpleSchedule(), on: date(2026, 4, 15, 12, 0, z),
                                           timeZone: z, location: nil)
        let samples = tl.sample(stepSeconds: 900)
        XCTAssertEqual(samples.count, 97)
        XCTAssertTrue(samples.allSatisfy { $0.target.temperature.kelvin > 1000 })
    }

    func testCurveIsContinuousWithNoSuddenJumps() {
        // Sampled every 10 seconds, the steepest ramp in this schedule moves
        // about 1.2 mired per step. A genuine discontinuity — the anchor or
        // ramp maths being wrong at a boundary — would move hundreds.
        let z = tz("Europe/London")
        let tl = ScheduleResolver.timeline(for: simpleSchedule(), on: date(2026, 4, 15, 12, 0, z),
                                           timeZone: z, location: nil)
        let samples = tl.sample(stepSeconds: 10)
        for i in 1..<samples.count {
            let jump = abs(samples[i].target.temperature.mired - samples[i-1].target.temperature.mired)
            XCTAssertLessThan(jump, 5.0, "discontinuity at \(clockString(samples[i].seconds))")
        }
    }
}

final class CityTests: DaylightTestCase {

    func testEveryBundledCityHasPlausibleCoordinates() {
        for city in Cities.all {
            XCTAssertTrue(city.location.isValid, "\(city.label) has impossible coordinates")
            XCTAssertNotEqual(city.latitude, 0.0, "\(city.label) looks like a placeholder")
            XCTAssertFalse(city.name.isEmpty)
            XCTAssertFalse(city.region.isEmpty)
        }
    }

    func testEveryCityNamesARealTimeZone() {
        for city in Cities.all {
            XCTAssertNotNil(TimeZone(identifier: city.timeZoneIdentifier),
                            "\(city.label) names an unknown time zone: \(city.timeZoneIdentifier)")
        }
    }

    func testCoordinatesAgreeWithTheirTimeZoneRoughly() {
        // Longitude and UTC offset should be in the same part of the world.
        // Catches a transposed or mistyped coordinate, which is the realistic
        // failure for a hand-entered table.
        for city in Cities.all {
            guard let zone = TimeZone(identifier: city.timeZoneIdentifier) else { continue }
            let offsetHours = Double(zone.secondsFromGMT(for: Date(timeIntervalSince1970: 0))) / 3600
            let expected = city.longitude / 15
            XCTAssertLessThan(abs(offsetHours - expected), 4.0,
                              "\(city.label): longitude \(city.longitude) does not match a \(offsetHours)h zone")
        }
    }

    func testNamesAreUnique() {
        let ids = Cities.all.map(\.id)
        XCTAssertEqual(Set(ids).count, ids.count, "duplicate city entries")
    }

    func testSearchFindsByPrefix() {
        XCTAssertEqual(Cities.search("lond").first?.name, "London")
        XCTAssertEqual(Cities.search("tok").first?.name, "Tokyo")
    }

    func testSearchIgnoresCaseAndAccents() {
        XCTAssertEqual(Cities.search("SAO PAULO").first?.name, "São Paulo")
        XCTAssertEqual(Cities.search("zurich").first?.name, "Zurich")
        XCTAssertEqual(Cities.search("tromso").first?.name, "Tromsø")
    }

    func testSearchMatchesRegion() {
        XCTAssertTrue(Cities.search("japan").contains { $0.name == "Tokyo" })
    }

    func testPrefixMatchesOutrankSubstringMatches() {
        // "san" should surface San Francisco before Santiago's region match.
        XCTAssertTrue(Cities.search("san").first?.name.hasPrefix("San") ?? false)
    }

    func testEmptySearchReturnsSomethingRatherThanNothing() {
        XCTAssertFalse(Cities.search("").isEmpty)
    }

    func testNonsenseSearchReturnsNothing() {
        XCTAssertTrue(Cities.search("qqzzxx").isEmpty)
    }

    func testTimeZoneSuggestionIsExactWhereItCanBe() {
        XCTAssertEqual(Cities.suggestion(forTimeZone: "Europe/London")?.name, "London")
        XCTAssertEqual(Cities.suggestion(forTimeZone: "Asia/Tokyo")?.name, "Tokyo")
        XCTAssertEqual(Cities.suggestion(forTimeZone: "America/New_York")?.name, "New York")
    }

    func testTimeZoneSuggestionFallsBackToTheRegion() {
        // Not in the list, but at least on the right continent.
        let s = Cities.suggestion(forTimeZone: "Europe/Ljubljana")
        XCTAssertNotNil(s)
        XCTAssertTrue(s!.timeZoneIdentifier.hasPrefix("Europe/"))
    }

    func testAnUnknownZoneSuggestsNothingRatherThanGuessingWildly() {
        XCTAssertNil(Cities.suggestion(forTimeZone: "Mars/Olympus_Mons"))
    }

    func testASuggestionIsUsableAsALocation() {
        guard let city = Cities.suggestion(forTimeZone: "Europe/Paris") else {
            return XCTFail("expected a suggestion")
        }
        let z = TimeZone(identifier: city.timeZoneIdentifier)!
        let sunset = SolarCalculator.event(.sunset, date: date(2026, 6, 21, 12, 0, z),
                                           location: city.location, timeZone: z)
        XCTAssertNotNil(sunset.seconds, "a suggested city must produce real solar events")
    }

    func testSunsetTimesAreSaneForEveryBundledCity() {
        // A transposed sign or a decimal slip shows up here as a solar event at
        // an absurd hour, or none at all outside the polar circles.
        let z = TimeZone(identifier: "UTC")!
        for city in Cities.all where abs(city.latitude) < 60 {
            let result = SolarCalculator.event(.sunset, date: date(2026, 3, 20, 12, 0, z),
                                               location: city.location,
                                               timeZone: TimeZone(identifier: city.timeZoneIdentifier)!)
            guard let seconds = result.seconds else {
                XCTFail("\(city.label): no sunset at an equinox below 60° latitude")
                continue
            }
            let hour = seconds / 3600
            // At an equinox, local sunset is near 18:00 everywhere; time-zone
            // width and longitude push it around by a couple of hours.
            XCTAssertGreaterThan(hour, 15.0, "\(city.label) sets at \(clockString(seconds))")
            XCTAssertLessThan(hour, 21.0, "\(city.label) sets at \(clockString(seconds))")
        }
    }
}

final class CitySearchNormalisationTests: DaylightTestCase {

    /// Letters that survive Unicode diacritic folding because they are distinct
    /// letters rather than a base plus a mark. Someone typing the plain-ASCII
    /// spelling still expects to find them.
    func testNonDecomposableLettersAreSearchable() {
        let cases = [("tromso", "Tromsø"), ("reykjavik", "Reykjavík"),
                     ("sao paulo", "São Paulo"), ("montreal", "Montréal"),
                     ("bogota", "Bogotá")]
        for (typed, expected) in cases {
            XCTAssertEqual(Cities.search(typed).first?.name, expected,
                           "typing “\(typed)” should find \(expected)")
        }
    }

    func testNormalisationIsIdempotent() {
        for city in Cities.all {
            let once = Cities.normalise(city.name)
            XCTAssertEqual(Cities.normalise(once), once)
        }
    }

    func testNormalisationLeavesPlainAsciiAlone() {
        XCTAssertEqual(Cities.normalise("London"), "london")
    }
}

final class LocationTimeZoneTests: DaylightTestCase {

    func testACityCarriesItsTimeZone() {
        let london = Cities.all.first { $0.name == "London" }!
        XCTAssertEqual(london.location.timeZoneIdentifier, "Europe/London")
    }

    func testAMismatchWithTheSystemClockIsDetected() {
        // Picking London while the Mac is set to New York makes sunrise appear
        // at an hour that looks wrong but is not. The app has to notice.
        let london = Cities.all.first { $0.name == "London" }!.location
        XCTAssertTrue(london.disagreesWithSystemClock(tz("America/New_York")))
        XCTAssertFalse(london.disagreesWithSystemClock(tz("Europe/London")))
    }

    func testZonesThatShareAnOffsetAreNotFlagged() {
        // Paris and Berlin keep the same clock; flagging that would be noise.
        let paris = Cities.all.first { $0.name == "Paris" }!.location
        XCTAssertFalse(paris.disagreesWithSystemClock(tz("Europe/Berlin")))
    }

    func testCoordinatesTypedByHandAreNeverFlagged() {
        // No zone was claimed, so there is nothing to disagree with.
        let manual = GeoLocation(latitude: 51.5, longitude: -0.12, label: "Home")
        XCTAssertFalse(manual.disagreesWithSystemClock(tz("Asia/Tokyo")))
    }

    func testALocationFromAnOlderSettingsFileStillDecodes() {
        // Written before `timeZoneIdentifier` existed. Losing the location here
        // would silently break every solar schedule on upgrade.
        let json = """
        {"latitude": 51.5074, "longitude": -0.1278, "label": "London"}
        """
        let decoded = try? JSONDecoder().decode(GeoLocation.self, from: Data(json.utf8))
        XCTAssertNotNil(decoded)
        XCTAssertEqual(decoded?.label, "London")
        XCTAssertNil(decoded?.timeZoneIdentifier)
        XCTAssertTrue(decoded?.isValid ?? false)
    }

    func testALocationWithoutALabelStillDecodes() {
        let json = "{\"latitude\": 10.0, \"longitude\": 20.0}"
        let decoded = try? JSONDecoder().decode(GeoLocation.self, from: Data(json.utf8))
        XCTAssertEqual(decoded?.label, "My location")
    }

    func testRoundTripPreservesTheZone() {
        let city = Cities.all.first { $0.name == "Tokyo" }!.location
        let data = try! JSONEncoder().encode(city)
        let back = try! JSONDecoder().decode(GeoLocation.self, from: data)
        XCTAssertEqual(back.timeZoneIdentifier, "Asia/Tokyo")
        XCTAssertEqual(back.label, city.label)
    }
}
