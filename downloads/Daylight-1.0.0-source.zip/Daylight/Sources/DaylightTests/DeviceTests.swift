import Foundation
import DaylightCore

final class DeviceAdapterTests: DaylightTestCase {

    let warm = ResolvedTarget(temperature: ColourTemperature(kelvin: 3000),
                              dimming: SoftwareDimming(factor: 0.8))

    func testHappyPathIsConfirmedByReadback() {
        let d = SimulatedDisplayDevice()
        try! d.prepare()
        let r = try! d.apply(warm)
        XCTAssertEqual(r.confidence, ApplicationConfidence.readbackConfirmed)
        XCTAssertFalse(r.foreignChangeDetected)
        XCTAssertEqual(d.writeCount, 1)
    }

    func testDisconnectedDeviceThrowsRatherThanPretending() {
        let d = SimulatedDisplayDevice()
        d.faults.disconnected = true
        XCTAssertThrowsError(try d.prepare()) { XCTAssertEqual($0 as? DeviceError, .notConnected) }
        XCTAssertThrowsError(try d.apply(warm))
        XCTAssertEqual(d.connectionState, ConnectionState.disconnected)
    }

    func testDisconnectMidSessionIsReportedOnTheNextWrite() {
        let d = SimulatedDisplayDevice()
        try! d.prepare()
        _ = try! d.apply(warm)
        d.faults.disconnected = true
        XCTAssertThrowsError(try d.apply(warm)) { XCTAssertEqual($0 as? DeviceError, .notConnected) }
    }

    func testTimeoutIsSurfaced() {
        let d = SimulatedDisplayDevice()
        try! d.prepare()
        d.faults.timeOut = true
        XCTAssertThrowsError(try d.apply(warm)) { XCTAssertEqual($0 as? DeviceError, .timedOut) }
    }

    func testWriteFailureIsSurfaced() {
        let d = SimulatedDisplayDevice()
        try! d.prepare()
        d.faults.failWrites = true
        XCTAssertThrowsError(try d.apply(warm)) {
            XCTAssertEqual($0 as? DeviceError, .writeFailed(code: -1))
        }
    }

    func testAcceptedButUnverifiableIsNotReportedAsConfirmed() {
        // The important distinction: the call succeeded, but we have no
        // evidence the output changed. That must not be dressed up.
        let d = SimulatedDisplayDevice()
        try! d.prepare()
        d.faults.readbackUnavailable = true
        let r = try! d.apply(warm)
        XCTAssertEqual(r.confidence, ApplicationConfidence.acceptedBySystem)
        XCTAssertNil(r.readback)
        XCTAssertLessThan(r.confidence, ApplicationConfidence.readbackConfirmed)
    }

    func testReadbackDisagreementDowngradesConfidence() {
        let d = SimulatedDisplayDevice()
        try! d.prepare()
        d.faults.readbackDisagrees = true
        let r = try! d.apply(warm)
        XCTAssertEqual(r.confidence, ApplicationConfidence.acceptedBySystem)
        XCTAssertTrue(r.foreignChangeDetected)
        XCTAssertNotNil(r.deviation)
    }

    func testForeignOverwriteIsDetected() {
        let d = SimulatedDisplayDevice()
        try! d.prepare()
        d.faults.foreignOverwrite = ChannelGains(red: 1, green: 0.36, blue: 0.10)
        let r = try! d.apply(warm)
        XCTAssertTrue(r.foreignChangeDetected, "another app's transform must be noticed")
    }

    func testRateLimitedDeviceRejectsFloodingButRecovers() {
        let d = SimulatedDisplayDevice()
        try! d.prepare()
        d.faults.minimumWriteInterval = 3600
        _ = try! d.apply(warm)
        XCTAssertThrowsError(try d.apply(warm))
        d.faults.minimumWriteInterval = 0
        XCTAssertNoThrow(try d.apply(warm))
    }

    func testUnsupportedControlIsDeclaredNotFaked() {
        let d = SimulatedDisplayDevice(capabilities: DisplayCapabilities(
            supportsColourTransform: false, transferTableCapacity: 0,
            supportsSoftwareDimming: false, supportsHardwareBrightness: false))
        XCTAssertFalse(d.capabilities.supportsColourTransform)
        XCTAssertFalse(d.capabilities.supportsHardwareBrightness)
    }

    func testRestoreClearsAppliedState() {
        let d = SimulatedDisplayDevice()
        try! d.prepare()
        _ = try! d.apply(warm)
        XCTAssertNotNil(d.appliedGains)
        try! d.restore()
        XCTAssertNil(d.appliedGains)
        XCTAssertEqual(d.restoreCount, 1)
    }

    func testRestoreOnADisconnectedDeviceFailsLoudly() {
        let d = SimulatedDisplayDevice()
        try! d.prepare()
        d.faults.disconnected = true
        XCTAssertThrowsError(try d.restore())
    }

    func testPartialFailureAcrossDevicesLeavesOthersWorking() {
        // One broken monitor must not take the others down with it.
        let good = SimulatedDisplayDevice(key: "sim:good")
        let bad = SimulatedDisplayDevice(key: "sim:bad")
        bad.faults.failWrites = true
        try! good.prepare(); try! bad.prepare()

        var succeeded = 0, failed = 0
        for d in [good, bad] as [SimulatedDisplayDevice] {
            do { _ = try d.apply(warm); succeeded += 1 } catch { failed += 1 }
        }
        XCTAssertEqual(succeeded, 1)
        XCTAssertEqual(failed, 1)
        XCTAssertNotNil(good.appliedGains)
    }

    func testAppliedGainsMatchTheRequestedTarget() {
        let d = SimulatedDisplayDevice()
        try! d.prepare()
        _ = try! d.apply(warm)
        XCTAssertEqual(d.appliedGains?.red ?? 0, warm.gains.red, accuracy: 1e-9)
        XCTAssertEqual(d.appliedGains?.blue ?? 0, warm.gains.blue, accuracy: 1e-9)
    }

    func testNeutralTargetProducesUnityGains() {
        let d = SimulatedDisplayDevice()
        try! d.prepare()
        _ = try! d.apply(.neutral)
        XCTAssertEqual(d.appliedGains?.red ?? 0, 1.0, accuracy: 0.02)
        XCTAssertEqual(d.appliedGains?.green ?? 0, 1.0, accuracy: 0.02)
        XCTAssertEqual(d.appliedGains?.blue ?? 0, 1.0, accuracy: 0.02)
    }

    func testRepeatedApplicationDoesNotAccumulate() {
        // Gains are always computed from the target, never from the current
        // state, so applying the same value ten times is idempotent.
        let d = SimulatedDisplayDevice()
        try! d.prepare()
        for _ in 0..<10 { _ = try! d.apply(warm) }
        XCTAssertEqual(d.appliedGains?.blue ?? 0, warm.gains.blue, accuracy: 1e-9)
    }

    func testConfidenceOrderingIsMeaningful() {
        XCTAssertLessThan(ApplicationConfidence.requested, ApplicationConfidence.acceptedBySystem)
        XCTAssertLessThan(ApplicationConfidence.acceptedBySystem, ApplicationConfidence.readbackConfirmed)
    }
}

final class DDCProtocolTests: DaylightTestCase {

    func testSetBrightnessPacketMatchesTheSpec() {
        // Set luminance (0x10) to 50 on a 0-100 display.
        let p = DDCPacket.setVCP(DDCPacket.VCP.luminance.rawValue, value: 50)
        XCTAssertEqual(Array(p.prefix(6)), [0x51, 0x84, 0x03, 0x10, 0x00, 0x32])
        XCTAssertEqual(p.count, 7)
        // Checksum is an XOR over the destination address and every byte sent.
        let expected = ([0x6E] + Array(p.prefix(6))).reduce(0 as UInt8) { $0 ^ $1 }
        XCTAssertEqual(p[6], expected)
    }

    func testSetPacketCarriesSixteenBitValues() {
        let p = DDCPacket.setVCP(0x10, value: 0x1234)
        XCTAssertEqual(p[4], 0x12)
        XCTAssertEqual(p[5], 0x34)
    }

    func testGetPacketMatchesTheSpec() {
        let p = DDCPacket.getVCP(0x10)
        XCTAssertEqual(Array(p.prefix(4)), [0x51, 0x82, 0x01, 0x10])
        XCTAssertEqual(p.count, 5)
        let expected = ([0x6E] + Array(p.prefix(4))).reduce(0 as UInt8) { $0 ^ $1 }
        XCTAssertEqual(p[4], expected)
    }

    /// Builds a well-formed reply the way a display would.
    func reply(vcp: UInt8, current: UInt16, maximum: UInt16,
               result: UInt8 = 0x00, corruptChecksum: Bool = false) -> [UInt8] {
        var body: [UInt8] = [
            0x88, 0x02, result, vcp, 0x00,
            UInt8(maximum >> 8), UInt8(truncatingIfNeeded: maximum),
            UInt8(current >> 8), UInt8(truncatingIfNeeded: current),
        ]
        let sum = ([0x6E] + body).reduce(0x50 as UInt8) { $0 ^ $1 }
        body.append(corruptChecksum ? sum ^ 0xFF : sum)
        return [0x6E] + body
    }

    func testParsesAWellFormedReply() {
        let r = DDCPacket.parseReply(reply(vcp: 0x10, current: 40, maximum: 100), expecting: 0x10)
        XCTAssertEqual(r?.current, 40)
        XCTAssertEqual(r?.maximum, 100)
    }

    func testParsesAReplyWithoutTheLeadingAddressByte() {
        var bytes = reply(vcp: 0x10, current: 40, maximum: 100)
        bytes.removeFirst()
        XCTAssertNotNil(DDCPacket.parseReply(bytes, expecting: 0x10))
    }

    func testRejectsABadChecksum() {
        // Rejecting these is what makes a successful parse real evidence of
        // DDC support rather than noise on the wire.
        XCTAssertNil(DDCPacket.parseReply(
            reply(vcp: 0x10, current: 40, maximum: 100, corruptChecksum: true), expecting: 0x10))
    }

    func testRejectsAnErrorResult() {
        XCTAssertNil(DDCPacket.parseReply(
            reply(vcp: 0x10, current: 40, maximum: 100, result: 0x01), expecting: 0x10))
    }

    func testRejectsAReplyAboutADifferentFeature() {
        XCTAssertNil(DDCPacket.parseReply(
            reply(vcp: 0x12, current: 40, maximum: 100), expecting: 0x10))
    }

    func testRejectsTruncatedAndEmptyReplies() {
        XCTAssertNil(DDCPacket.parseReply([], expecting: 0x10))
        XCTAssertNil(DDCPacket.parseReply([0x6E, 0x88, 0x02], expecting: 0x10))
        XCTAssertNil(DDCPacket.parseReply(Array(repeating: 0, count: 11), expecting: 0x10))
    }

    func testRejectsAZeroMaximum() {
        // A maximum of zero would make every level division meaningless.
        XCTAssertNil(DDCPacket.parseReply(
            reply(vcp: 0x10, current: 0, maximum: 0), expecting: 0x10))
    }

    func testLevelConversionRoundTrips() {
        for maximum: UInt16 in [100, 255, 1000] {
            for level in [0.0, 0.25, 0.5, 0.75, 1.0] {
                let raw = DDCPacket.rawValue(forLevel: level, maximum: maximum)
                XCTAssertLessThanOrEqual(raw, maximum)
                XCTAssertEqual(DDCPacket.level(forRaw: raw, maximum: maximum), level,
                               accuracy: 1.0 / Double(maximum))
            }
        }
    }

    func testLevelIsClampedRatherThanOverflowing() {
        XCTAssertEqual(DDCPacket.rawValue(forLevel: 5.0, maximum: 100), 100)
        XCTAssertEqual(DDCPacket.rawValue(forLevel: -2.0, maximum: 100), 0)
        XCTAssertEqual(DDCPacket.level(forRaw: 50, maximum: 0), 0.0, accuracy: 1e-9)
    }
}

final class SleepingDisplayTests: DaylightTestCase {

    let warm = ResolvedTarget(temperature: ColourTemperature(kelvin: 3000),
                              dimming: SoftwareDimming(factor: 0.8))

    func testAsleepIsDistinctFromDisconnected() {
        let d = SimulatedDisplayDevice()
        d.faults.asleep = true
        XCTAssertEqual(d.connectionState, ConnectionState.asleep)
        d.faults.disconnected = true
        XCTAssertEqual(d.connectionState, ConnectionState.disconnected,
                       "disconnected outranks asleep")
    }

    func testASleepingDisplayStillAcceptsWrites() {
        // The value should be in place before the screen comes back, rather
        // than the screen briefly showing the previous setting.
        let d = SimulatedDisplayDevice()
        try! d.prepare()
        d.faults.asleep = true
        XCTAssertNoThrow(try d.apply(warm))
        XCTAssertNotNil(d.appliedGains)
    }

    func testADisconnectedDisplayStillRefusesWrites() {
        let d = SimulatedDisplayDevice()
        try! d.prepare()
        d.faults.disconnected = true
        XCTAssertThrowsError(try d.apply(warm))
    }
}
