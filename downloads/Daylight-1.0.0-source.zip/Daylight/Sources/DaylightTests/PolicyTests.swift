import Foundation
import DaylightCore

final class PrecedenceTests: DaylightTestCase {

    func testHigherLayerWins() {
        let o = PrecedenceResolver.resolve([
            LayerProposal(layer: .baseSchedule, label: "Schedule",
                          target: LightingTarget(temperature: ColourTemperature(kelvin: 3000))),
            LayerProposal(layer: .manualOverride, label: "Reading",
                          target: LightingTarget(temperature: ColourTemperature(kelvin: 4500))),
        ])
        XCTAssertEqual(o.target.temperature.kelvin, 4500, accuracy: 1)
        XCTAssertEqual(o.temperatureFrom.layer, ControlLayer.manualOverride)
    }

    func testPerControlResolutionKeepsBothContributions() {
        // A rule that only speaks about brightness must not silently discard
        // the schedule's warmth decision.
        let o = PrecedenceResolver.resolve([
            LayerProposal(layer: .baseSchedule, label: "Evening schedule",
                          target: LightingTarget(temperature: ColourTemperature(kelvin: 3000),
                                                 dimming: SoftwareDimming(factor: 0.9))),
            LayerProposal(layer: .activityRule, label: "On battery",
                          target: LightingTarget(dimming: SoftwareDimming(factor: 0.6))),
        ])
        XCTAssertEqual(o.target.temperature.kelvin, 3000, accuracy: 1, "warmth survives")
        XCTAssertEqual(o.target.dimming.factor, 0.6, accuracy: 0.001, "brightness comes from the rule")
        XCTAssertEqual(o.temperatureFrom.layer, ControlLayer.baseSchedule)
        XCTAssertEqual(o.dimmingFrom.layer, ControlLayer.activityRule)
    }

    func testPauseBeatsEverythingBelowIt() {
        let o = PrecedenceResolver.resolve([
            LayerProposal(layer: .baseSchedule, label: "Schedule",
                          target: LightingTarget(temperature: ColourTemperature(kelvin: 2700))),
            LayerProposal(layer: .activityRule, label: "Photos",
                          target: LightingTarget(temperature: ColourTemperature(kelvin: 5000))),
            LayerProposal(layer: .userPause, label: "Paused", target: .neutral),
        ])
        XCTAssertEqual(o.target.temperature.kelvin, ColourTemperature.neutral.kelvin, accuracy: 1)
        XCTAssertTrue(o.explanation.contains("paused"))
    }

    func testEmergencyRestoreOutranksPause() {
        let o = PrecedenceResolver.resolve([
            LayerProposal(layer: .userPause, label: "Paused",
                          target: LightingTarget(temperature: ColourTemperature(kelvin: 3000))),
            LayerProposal(layer: .emergencyRestore, label: "Restored", target: .neutral),
        ])
        XCTAssertEqual(o.dominant.layer, ControlLayer.emergencyRestore)
        XCTAssertTrue(o.explanation.contains("Restore"))
    }

    func testExplanationNamesTheResponsibleRule() {
        let o = PrecedenceResolver.resolve([
            LayerProposal(layer: .baseSchedule, label: "Weekday schedule",
                          target: LightingTarget(temperature: ColourTemperature(kelvin: 2900))),
            LayerProposal(layer: .activityRule, label: "Colour Work",
                          target: LightingTarget(temperature: .neutral)),
        ])
        XCTAssertTrue(o.explanation.contains("Colour Work"), o.explanation)
        XCTAssertTrue(o.explanation.contains("this app"), o.explanation)
    }

    func testEmptyProposalsAreNeutralNotCrash() {
        let o = PrecedenceResolver.resolve([])
        XCTAssertEqual(o.target, ResolvedTarget.neutral)
    }

    func testLayerOrderingIsTotalAndStable() {
        let all = ControlLayer.allCases.shuffled()
        let sorted = all.sorted { $0 > $1 }
        XCTAssertEqual(sorted.first, ControlLayer.emergencyRestore)
        XCTAssertEqual(sorted.last, ControlLayer.baseSchedule)
    }
}

final class OverrideTests: DaylightTestCase {

    func testDurationOverrideExpires() {
        let start = Date()
        let o = TemporaryOverride(label: "Reading",
                                  target: LightingTarget(temperature: ColourTemperature(kelvin: 3400)),
                                  expiry: .duration(3600), startedAt: start)
        XCTAssertFalse(o.isExpired(at: start.addingTimeInterval(3599), nextScheduleChange: nil))
        XCTAssertTrue(o.isExpired(at: start.addingTimeInterval(3601), nextScheduleChange: nil))
    }

    func testUntilNextScheduleChangeUsesTheSchedule() {
        let start = Date()
        let next = start.addingTimeInterval(1800)
        let o = TemporaryOverride(label: "Manual", target: LightingTarget(),
                                  expiry: .untilNextScheduleChange, startedAt: start)
        XCTAssertEqual(o.expiryDate(nextScheduleChange: next), next)
        XCTAssertTrue(o.isExpired(at: next.addingTimeInterval(1), nextScheduleChange: next))
    }

    func testUntilNextScheduleChangeWithNoScheduleNeverExpiresSilently() {
        let o = TemporaryOverride(label: "Manual", target: LightingTarget(),
                                  expiry: .untilNextScheduleChange, startedAt: Date())
        XCTAssertNil(o.expiryDate(nextScheduleChange: nil))
        XCTAssertFalse(o.isExpired(at: Date().addingTimeInterval(99999), nextScheduleChange: nil))
    }

    func testUntilResumedHasNoExpiry() {
        let o = TemporaryOverride(label: "Focus", target: LightingTarget(),
                                  expiry: .untilResumed, startedAt: Date())
        XCTAssertNil(o.expiryDate(nextScheduleChange: Date()))
        XCTAssertFalse(o.isExpired(at: Date().addingTimeInterval(86_400), nextScheduleChange: Date()))
    }

    func testStatusSentenceIsPlainLanguage() {
        let f = DateFormatter(); f.dateFormat = "HH:mm"; f.timeZone = tz("UTC")
        let start = Date(timeIntervalSince1970: 0)
        let o = TemporaryOverride(label: "Reading mode",
                                  target: LightingTarget(), expiry: .duration(3600), startedAt: start)
        let s = o.statusSentence(now: start, nextScheduleChange: nil, formatter: f)
        XCTAssertTrue(s.contains("Reading mode until 01:00"), s)
        XCTAssertTrue(s.contains("schedule resumes"), s)
    }

    func testUntilResumedSentenceSaysSo() {
        let f = DateFormatter(); f.dateFormat = "HH:mm"
        let o = TemporaryOverride(label: "Focus", target: LightingTarget(),
                                  expiry: .untilResumed, startedAt: Date())
        XCTAssertTrue(o.statusSentence(now: Date(), nextScheduleChange: nil, formatter: f)
                        .contains("until you resume"))
    }
}

final class RulesTests: DaylightTestCase {

    func ctx(app: String? = nil, seconds: Int = 12 * 3600, weekday: Int = 2,
             battery: Bool = false, displays: Set<String> = []) -> RuleContext {
        RuleContext(frontmostBundleID: app, secondsFromMidnight: seconds, weekday: weekday,
                    onBattery: battery, connectedDisplayKeys: displays)
    }

    func testFrontmostAppTriggerMatches() {
        let r = Rule(name: "Photos neutral",
                     triggers: [.frontmostApp(bundleIdentifier: "com.apple.Photos", displayName: "Photos")],
                     actions: [.pauseWarmth])
        let e = RulesEngine.evaluate(rules: [r], context: ctx(app: "com.apple.Photos"), profiles: [])
        XCTAssertEqual(e.matchedRules.count, 1)
        XCTAssertEqual(e.proposal?.target.temperature?.kelvin ?? 0,
                       ColourTemperature.neutral.kelvin, accuracy: 1)
    }

    func testNonMatchingAppProducesNoProposal() {
        let r = Rule(name: "Photos neutral",
                     triggers: [.frontmostApp(bundleIdentifier: "com.apple.Photos", displayName: "Photos")],
                     actions: [.pauseWarmth])
        XCTAssertNil(RulesEngine.evaluate(rules: [r], context: ctx(app: "com.apple.Safari"),
                                          profiles: []).proposal)
    }

    func testAllTriggersMustMatch() {
        let r = Rule(name: "Evening battery",
                     triggers: [.onBatteryPower, .timeRange(startSeconds: 20 * 3600, endSeconds: 23 * 3600)],
                     actions: [.setDimming(SoftwareDimming(factor: 0.6))])
        XCTAssertNil(RulesEngine.evaluate(rules: [r],
                                          context: ctx(seconds: 21 * 3600, battery: false),
                                          profiles: []).proposal)
        XCTAssertNotNil(RulesEngine.evaluate(rules: [r],
                                             context: ctx(seconds: 21 * 3600, battery: true),
                                             profiles: []).proposal)
    }

    func testTimeRangeWrappingMidnight() {
        let r = Rule(name: "Overnight", triggers: [.timeRange(startSeconds: 22 * 3600, endSeconds: 6 * 3600)],
                     actions: [.setDimming(SoftwareDimming(factor: 0.5))])
        XCTAssertNotNil(RulesEngine.evaluate(rules: [r], context: ctx(seconds: 23 * 3600), profiles: []).proposal)
        XCTAssertNotNil(RulesEngine.evaluate(rules: [r], context: ctx(seconds: 2 * 3600), profiles: []).proposal)
        XCTAssertNil(RulesEngine.evaluate(rules: [r], context: ctx(seconds: 12 * 3600), profiles: []).proposal)
    }

    func testDisabledRulesAreSkipped() {
        var r = Rule(name: "Off", triggers: [.onBatteryPower], actions: [.pauseWarmth])
        r.isEnabled = false
        XCTAssertNil(RulesEngine.evaluate(rules: [r], context: ctx(battery: true), profiles: []).proposal)
    }

    func testRuleWithNoTriggersNeverMatches() {
        // Otherwise an empty rule would silently apply to everything.
        let r = Rule(name: "Empty", triggers: [], actions: [.pauseWarmth])
        XCTAssertNil(RulesEngine.evaluate(rules: [r], context: ctx(), profiles: []).proposal)
    }

    func testOverlappingRulesResolveByVisibleOrder() {
        let a = Rule(name: "First", triggers: [.onBatteryPower],
                     actions: [.setTemperature(ColourTemperature(kelvin: 4000))], order: 0)
        let b = Rule(name: "Second", triggers: [.onBatteryPower],
                     actions: [.setTemperature(ColourTemperature(kelvin: 3000))], order: 1)
        let e = RulesEngine.evaluate(rules: [a, b], context: ctx(battery: true), profiles: [])
        XCTAssertEqual(e.proposal?.target.temperature?.kelvin ?? 0, 3000, accuracy: 1,
                       "the later rule wins, matching the order shown in the interface")
        XCTAssertEqual(e.matchedRules.count, 2)
    }

    func testOverlappingRulesTouchingDifferentControlsBothApply() {
        let a = Rule(name: "Warmth", triggers: [.onBatteryPower],
                     actions: [.setTemperature(ColourTemperature(kelvin: 3500))], order: 0)
        let b = Rule(name: "Dim", triggers: [.onBatteryPower],
                     actions: [.setDimming(SoftwareDimming(factor: 0.5))], order: 1)
        let e = RulesEngine.evaluate(rules: [a, b], context: ctx(battery: true), profiles: [])
        XCTAssertEqual(e.proposal?.target.temperature?.kelvin ?? 0, 3500, accuracy: 1)
        XCTAssertEqual(e.proposal?.target.dimming?.factor ?? 0, 0.5, accuracy: 0.001)
    }

    func testProfileActionAppliesProfileValues()  {
        let p = Profile(name: "Reading", symbolName: "book",
                        target: LightingTarget(temperature: ColourTemperature(kelvin: 3400),
                                               dimming: SoftwareDimming(factor: 0.8)),
                        silencesReminders: true, summary: "")
        let r = Rule(name: "Books", triggers: [.onBatteryPower],
                     actions: [.applyProfile(profileID: p.id, profileName: p.name)])
        let e = RulesEngine.evaluate(rules: [r], context: ctx(battery: true), profiles: [p])
        XCTAssertEqual(e.proposal?.target.temperature?.kelvin ?? 0, 3400, accuracy: 1)
        XCTAssertTrue(e.silencesReminders)
    }

    func testMissingProfileIsIgnoredRatherThanCrashing() {
        let r = Rule(name: "Ghost", triggers: [.onBatteryPower],
                     actions: [.applyProfile(profileID: UUID(), profileName: "Deleted")])
        let e = RulesEngine.evaluate(rules: [r], context: ctx(battery: true), profiles: [])
        XCTAssertNil(e.proposal?.target.temperature)
    }

    func testExcludeDisplayActionIsCollected() {
        let r = Rule(name: "Leave the TV alone", triggers: [.displayConnected(identityKey: "k", displayName: "TV")],
                     actions: [.excludeDisplay(identityKey: "k")])
        let e = RulesEngine.evaluate(rules: [r], context: ctx(displays: ["k"]), profiles: [])
        XCTAssertTrue(e.excludedDisplayKeys.contains("k"))
    }

    func testRuleSummaryReadsAsASentence() {
        let r = Rule(name: "Photos",
                     triggers: [.frontmostApp(bundleIdentifier: "com.apple.Photos", displayName: "Photos")],
                     actions: [.pauseWarmth])
        XCTAssertEqual(r.summary, "When Photos is in front, pause warmth.")
    }
}

final class TransitionTests: DaylightTestCase {

    func testFadeReachesTargetExactly() {
        var e = TransitionEngine(initial: .neutral, now: 0)
        let goal = ResolvedTarget(temperature: ColourTemperature(kelvin: 3000),
                                  dimming: SoftwareDimming(factor: 0.7))
        e.retarget(goal, duration: 10, now: 0)
        XCTAssertEqual(e.advance(to: 10).temperature.kelvin, 3000, accuracy: 0.5)
        XCTAssertEqual(e.advance(to: 20).dimming.factor, 0.7, accuracy: 0.001)
    }

    func testRetargetMidFadeDoesNotJump() {
        // The whole point: a rule firing halfway through a fade must continue
        // from where the output actually is, not snap back to the start.
        var e = TransitionEngine(initial: .neutral, now: 0)
        e.retarget(ResolvedTarget(temperature: ColourTemperature(kelvin: 2700), dimming: .none),
                   duration: 10, now: 0)
        let midway = e.advance(to: 5)
        e.retarget(ResolvedTarget(temperature: ColourTemperature(kelvin: 5000), dimming: .none),
                   duration: 10, now: 5)
        let justAfter = e.advance(to: 5.001)
        XCTAssertEqual(justAfter.temperature.mired, midway.temperature.mired, accuracy: 1.0,
                       "output must be continuous across a retarget")
    }

    func testZeroDurationSnaps() {
        var e = TransitionEngine(initial: .neutral, now: 0)
        let goal = ResolvedTarget(temperature: ColourTemperature(kelvin: 2000), dimming: .none)
        e.retarget(goal, duration: 0, now: 0)
        XCTAssertEqual(e.advance(to: 0).temperature.kelvin, 2000, accuracy: 0.5)
        XCTAssertTrue(e.isSettled)
    }

    func testFadeIsMonotonicAndBounded() {
        var e = TransitionEngine(initial: ResolvedTarget(temperature: ColourTemperature(kelvin: 6500), dimming: .none), now: 0)
        e.retarget(ResolvedTarget(temperature: ColourTemperature(kelvin: 2700), dimming: .none),
                   duration: 10, now: 0)
        var last = 0.0
        for t in stride(from: 0.0, through: 10.0, by: 0.1) {
            let m = e.advance(to: t).temperature.mired
            XCTAssertGreaterThanOrEqual(m, last - 1e-6)
            XCTAssertLessThanOrEqual(m, ColourTemperature(kelvin: 2700).mired + 1e-6)
            last = m
        }
    }

    func testSnapIgnoresAnyInFlightFade() {
        var e = TransitionEngine(initial: .neutral, now: 0)
        e.retarget(ResolvedTarget(temperature: ColourTemperature(kelvin: 2000), dimming: .none),
                   duration: 100, now: 0)
        _ = e.advance(to: 10)
        e.snap(to: .neutral, now: 10)
        XCTAssertEqual(e.advance(to: 11).temperature.kelvin, ColourTemperature.neutral.kelvin, accuracy: 0.5)
        XCTAssertTrue(e.isSettled)
    }

    func testTickIntervalScalesWithHowMuchActuallyChanges() {
        let cool = ResolvedTarget(temperature: ColourTemperature(kelvin: 6500), dimming: .none)
        let warm = ResolvedTarget(temperature: ColourTemperature(kelvin: 4200), dimming: .none)
        // A 90-minute schedule ramp needs a write roughly once a minute, not
        // once a frame.
        let slow = TickPlanner.interval(from: cool, to: warm, duration: 5400)
        XCTAssertGreaterThan(slow, 30.0)
        XCTAssertLessThanOrEqual(slow, TickPlanner.maximumInterval)
        // The same change over six seconds needs to be much smoother.
        let fast = TickPlanner.interval(from: cool, to: warm, duration: 6)
        XCTAssertLessThan(fast, 0.2)
        XCTAssertGreaterThanOrEqual(fast, TickPlanner.minimumInterval)
    }

    func testNoChangeMeansNoBusyLoop() {
        let t = ResolvedTarget(temperature: ColourTemperature(kelvin: 5000), dimming: .none)
        XCTAssertEqual(TickPlanner.interval(from: t, to: t, duration: 600),
                       TickPlanner.maximumInterval, accuracy: 0.001)
    }

    func testIdleSleepIsCappedByTheHeartbeat() {
        let now = Date()
        XCTAssertEqual(TickPlanner.idleInterval(nextChangeAt: nil, now: now),
                       TickPlanner.idleHeartbeat, accuracy: 0.001)
        XCTAssertEqual(TickPlanner.idleInterval(nextChangeAt: now.addingTimeInterval(99_999), now: now),
                       TickPlanner.idleHeartbeat, accuracy: 0.001)
        XCTAssertEqual(TickPlanner.idleInterval(nextChangeAt: now.addingTimeInterval(30), now: now),
                       30, accuracy: 0.5)
    }

    func testWritePolicySuppressesInvisibleChanges() {
        let p = WritePolicy.gamma
        let a = ChannelGains(red: 1, green: 0.8, blue: 0.6)
        let b = ChannelGains(red: 1, green: 0.8001, blue: 0.6)
        XCTAssertFalse(p.shouldWrite(new: b, last: a, lastWriteAt: 0, now: 100))
        let c = ChannelGains(red: 1, green: 0.75, blue: 0.6)
        XCTAssertTrue(p.shouldWrite(new: c, last: a, lastWriteAt: 0, now: 100))
    }

    func testWritePolicyAlwaysWritesWhenForced() {
        let p = WritePolicy.gamma
        let a = ChannelGains(red: 1, green: 0.8, blue: 0.6)
        XCTAssertTrue(p.shouldWrite(new: a, last: a, lastWriteAt: 0, now: 0, force: true))
    }

    func testSlowDeviceRateLimitIsRespected() {
        let p = WritePolicy.slowExternalDevice
        let a = ChannelGains(red: 1, green: 1, blue: 1)
        let b = ChannelGains(red: 0.5, green: 0.5, blue: 0.5)
        XCTAssertFalse(p.shouldWrite(new: b, last: a, lastWriteAt: 100, now: 100.5),
                       "a slow device must not be flooded")
        XCTAssertTrue(p.shouldWrite(new: b, last: a, lastWriteAt: 100, now: 101.5))
    }
}

final class WorkspaceTests: DaylightTestCase {

    let laptop = "uuid:laptop"
    let deskMonitor = "uuid:desk"
    let officeMonitor = "uuid:office"

    func workspaces() -> [Workspace] {
        [
            Workspace(name: "Travelling", requiredDisplayKeys: []),
            Workspace(name: "Home desk", requiredDisplayKeys: ["uuid:desk"]),
            Workspace(name: "Office", requiredDisplayKeys: ["uuid:office"]),
            Workspace(name: "Home, two screens", requiredDisplayKeys: ["uuid:desk", "uuid:laptop"]),
        ]
    }

    func testMostSpecificWorkspaceWins() {
        // Both "Home desk" and "Home, two screens" match; the more specific one
        // should be chosen, otherwise adding a second monitor would silently
        // do nothing.
        let m = WorkspaceMatcher.match(workspaces(), connected: [laptop, deskMonitor])
        XCTAssertEqual(m?.name, "Home, two screens")
    }

    func testSingleMonitorPicksTheSingleMonitorWorkspace() {
        XCTAssertEqual(WorkspaceMatcher.match(workspaces(), connected: [deskMonitor])?.name,
                       "Home desk")
    }

    func testCatchAllMatchesWhenNothingElseDoes() {
        XCTAssertEqual(WorkspaceMatcher.match(workspaces(), connected: [laptop])?.name,
                       "Travelling")
    }

    func testNoMatchWhenThereIsNoCatchAll() {
        let specific = workspaces().filter { !$0.requiredDisplayKeys.isEmpty }
        XCTAssertNil(WorkspaceMatcher.match(specific, connected: [laptop]))
    }

    func testDisabledWorkspacesAreSkipped() {
        var list = workspaces()
        list[3].isEnabled = false
        XCTAssertEqual(WorkspaceMatcher.match(list, connected: [laptop, deskMonitor])?.name,
                       "Home desk")
    }

    func testExtraDisplaysDoNotPreventAMatch() {
        // Requirements are a subset test, not an exact match: plugging in a
        // projector should not drop you out of your office workspace.
        XCTAssertEqual(
            WorkspaceMatcher.match(workspaces(), connected: [officeMonitor, "uuid:projector"])?.name,
            "Office")
    }

    func testEmptyListMatchesNothing() {
        XCTAssertNil(WorkspaceMatcher.match([], connected: [laptop]))
    }

    func testWorkspaceSitsBelowAppRulesAndAboveTheSchedule() {
        let o = PrecedenceResolver.resolve([
            LayerProposal(layer: .baseSchedule, label: "Schedule",
                          target: LightingTarget(temperature: ColourTemperature(kelvin: 3000))),
            LayerProposal(layer: .workspaceProfile, label: "Office",
                          target: LightingTarget(temperature: ColourTemperature(kelvin: 5000))),
        ])
        XCTAssertEqual(o.target.temperature.kelvin, 5000, accuracy: 1)
        XCTAssertTrue(o.explanation.contains("Office"), o.explanation)

        let withRule = PrecedenceResolver.resolve([
            LayerProposal(layer: .workspaceProfile, label: "Office",
                          target: LightingTarget(temperature: ColourTemperature(kelvin: 5000))),
            LayerProposal(layer: .activityRule, label: "Colour Work",
                          target: LightingTarget(temperature: .neutral)),
        ])
        XCTAssertEqual(withRule.target.temperature.kelvin,
                       ColourTemperature.neutral.kelvin, accuracy: 1)
    }

    func testWorkspaceTriggerMatchesByName() {
        let r = Rule(name: "Office dimming", triggers: [.workspace(name: "Office")],
                     actions: [.setDimming(SoftwareDimming(factor: 0.6))])
        var ctx = RuleContext()
        ctx.workspaceName = "Office"
        XCTAssertNotNil(RulesEngine.evaluate(rules: [r], context: ctx, profiles: []).proposal)
        ctx.workspaceName = "Home"
        XCTAssertNil(RulesEngine.evaluate(rules: [r], context: ctx, profiles: []).proposal)
    }
}

final class DisplayGroupTests: DaylightTestCase {

    func settingsWithGroup() -> DaylightSettings {
        var s = Presets.defaultSettings()
        var group = DisplayGroup(name: "Desk pair", memberKeys: ["a", "b"])
        group.settings.minimumKelvin = 3500
        group.settings.minimumDimming = 0.6
        s.groups = [group]
        s.displays = [
            DisplaySettings(id: "a", customName: "Left", minimumDimming: 0.2, minimumKelvin: 2700),
            DisplaySettings(id: "b", customName: "Right", minimumDimming: 0.2, minimumKelvin: 2700),
            DisplaySettings(id: "c", customName: "Alone", minimumDimming: 0.2, minimumKelvin: 2700),
        ]
        return s
    }

    func testGroupedDisplaysShareTheGroupsLimits() {
        let s = settingsWithGroup()
        XCTAssertEqual(s.settings(forDisplay: "a").minimumKelvin, 3500, accuracy: 1)
        XCTAssertEqual(s.settings(forDisplay: "b").minimumDimming, 0.6, accuracy: 0.001)
    }

    func testUngroupedDisplayKeepsItsOwnLimits() {
        XCTAssertEqual(settingsWithGroup().settings(forDisplay: "c").minimumKelvin, 2700, accuracy: 1)
    }

    func testNameAndExclusionStayPerDisplayEvenInAGroup() {
        // Linking two monitors should not stop you naming them separately or
        // leaving one of them alone.
        var s = settingsWithGroup()
        s.displays[0].isExcluded = true
        XCTAssertEqual(s.settings(forDisplay: "a").customName, "Left")
        XCTAssertEqual(s.settings(forDisplay: "b").customName, "Right")
        XCTAssertTrue(s.settings(forDisplay: "a").isExcluded)
        XCTAssertFalse(s.settings(forDisplay: "b").isExcluded)
    }

    func testGroupedSettingsReportTheirGroup() {
        XCTAssertNotNil(settingsWithGroup().settings(forDisplay: "a").groupID)
        XCTAssertNil(settingsWithGroup().settings(forDisplay: "c").groupID)
    }

    func testADisplayCanOnlyBelongToOneGroup() {
        var s = settingsWithGroup()
        s.groups.append(DisplayGroup(name: "Other", memberKeys: ["a", "d"]))
        s.validate()
        let owners = s.groups.filter { $0.memberKeys.contains("a") }
        XCTAssertEqual(owners.count, 1, "a display must not be claimed by two groups")
    }

    func testGroupsThatLoseTheirMembersAreDropped() {
        var s = Presets.defaultSettings()
        s.groups = [DisplayGroup(name: "Lonely", memberKeys: ["only-one"])]
        s.validate()
        XCTAssertTrue(s.groups.isEmpty, "a group of one is not a group")
    }

    func testWorkspaceReferencingADeletedScheduleIsRepaired() {
        var s = Presets.defaultSettings()
        s.workspaces = [Workspace(name: "Ghost", scheduleID: UUID())]
        s.validate()
        XCTAssertNil(s.workspaces[0].scheduleID)
    }
}

final class GroupEditingTests: DaylightTestCase {

    /// Mirrors what the Displays panel does when a limit slider moves, so the
    /// "edit silently does nothing" bug cannot come back.
    func applyEdit(_ settings: inout DaylightSettings, displayKey: String,
                   _ change: (inout DisplaySettings) -> Void) {
        if let group = settings.group(containing: displayKey),
           let gi = settings.groups.firstIndex(where: { $0.id == group.id }) {
            var probe = group.settings
            let before = (probe.customName, probe.isExcluded)
            change(&probe)
            if (probe.customName, probe.isExcluded) == before {
                settings.groups[gi].settings = probe
                return
            }
        }
        if let i = settings.displays.firstIndex(where: { $0.id == displayKey }) {
            change(&settings.displays[i])
        } else {
            var fresh = DisplaySettings(id: displayKey)
            change(&fresh)
            settings.displays.append(fresh)
        }
    }

    func grouped() -> DaylightSettings {
        var s = Presets.defaultSettings()
        s.groups = [DisplayGroup(name: "Pair", memberKeys: ["a", "b"])]
        s.displays = [DisplaySettings(id: "a"), DisplaySettings(id: "b")]
        return s
    }

    func testEditingALimitOnAGroupedDisplayActuallyTakesEffect() {
        var s = grouped()
        applyEdit(&s, displayKey: "a") { $0.minimumKelvin = 3800 }
        XCTAssertEqual(s.settings(forDisplay: "a").minimumKelvin, 3800, accuracy: 1,
                       "the edit must survive the group's own limits")
        XCTAssertEqual(s.settings(forDisplay: "b").minimumKelvin, 3800, accuracy: 1,
                       "and reach the other member")
    }

    func testEditingTheNameOfAGroupedDisplayStaysPerDisplay() {
        var s = grouped()
        applyEdit(&s, displayKey: "a") { $0.customName = "Left" }
        XCTAssertEqual(s.settings(forDisplay: "a").customName, "Left")
        XCTAssertNil(s.settings(forDisplay: "b").customName)
    }

    func testExcludingOneGroupedDisplayDoesNotExcludeTheOther() {
        var s = grouped()
        applyEdit(&s, displayKey: "a") { $0.isExcluded = true }
        XCTAssertTrue(s.settings(forDisplay: "a").isExcluded)
        XCTAssertFalse(s.settings(forDisplay: "b").isExcluded)
    }

    func testEditingAnUngroupedDisplayIsUnaffected() {
        var s = Presets.defaultSettings()
        applyEdit(&s, displayKey: "solo") { $0.minimumKelvin = 3100 }
        XCTAssertEqual(s.settings(forDisplay: "solo").minimumKelvin, 3100, accuracy: 1)
    }
}

final class BreakReminderTests: DaylightTestCase {

    func enabled(interval: Double = 30) -> BreakReminderSettings {
        BreakReminderSettings(isEnabled: true, intervalMinutes: interval, snoozeMinutes: 10,
                              quietStartSeconds: 22 * 3600, quietEndSeconds: 8 * 3600)
    }

    func testDisabledNeverShows() {
        var s = enabled(); s.isEnabled = false
        let state = BreakReminderState(startedAt: Date().addingTimeInterval(-10_000))
        XCTAssertFalse(BreakReminderScheduler.shouldShow(
            state: state, settings: s, now: Date(),
            secondsFromMidnight: 12 * 3600, isSilencedByMode: false))
        XCTAssertNil(BreakReminderScheduler.nextDue(state: state, settings: s))
    }

    func testShowsOnceTheIntervalHasPassed() {
        let start = Date()
        let state = BreakReminderState(startedAt: start)
        let s = enabled(interval: 30)
        XCTAssertFalse(BreakReminderScheduler.shouldShow(
            state: state, settings: s, now: start.addingTimeInterval(29 * 60),
            secondsFromMidnight: 12 * 3600, isSilencedByMode: false))
        XCTAssertTrue(BreakReminderScheduler.shouldShow(
            state: state, settings: s, now: start.addingTimeInterval(31 * 60),
            secondsFromMidnight: 12 * 3600, isSilencedByMode: false))
    }

    func testQuietHoursSuppressWithoutSkippingTheReminder() {
        // At 23:00 it is suppressed; the same state at 09:00 still fires, so a
        // whole evening's worth is deferred rather than silently dropped.
        let start = Date()
        let state = BreakReminderState(startedAt: start)
        let s = enabled()
        let later = start.addingTimeInterval(60 * 60)
        XCTAssertFalse(BreakReminderScheduler.shouldShow(
            state: state, settings: s, now: later,
            secondsFromMidnight: 23 * 3600, isSilencedByMode: false))
        XCTAssertTrue(BreakReminderScheduler.shouldShow(
            state: state, settings: s, now: later,
            secondsFromMidnight: 9 * 3600, isSilencedByMode: false))
    }

    func testQuietHoursWrapMidnight() {
        let s = enabled()
        XCTAssertTrue(BreakReminderScheduler.isInQuietHours(secondsFromMidnight: 23 * 3600, settings: s))
        XCTAssertTrue(BreakReminderScheduler.isInQuietHours(secondsFromMidnight: 2 * 3600, settings: s))
        XCTAssertFalse(BreakReminderScheduler.isInQuietHours(secondsFromMidnight: 12 * 3600, settings: s))
    }

    func testQuietHoursCanBeTurnedOff() {
        var s = enabled(); s.quietStartSeconds = nil; s.quietEndSeconds = nil
        XCTAssertFalse(BreakReminderScheduler.isInQuietHours(secondsFromMidnight: 3 * 3600, settings: s))
    }

    func testIdenticalQuietBoundsMeanNoQuietPeriod() {
        var s = enabled(); s.quietStartSeconds = 3600; s.quietEndSeconds = 3600
        XCTAssertFalse(BreakReminderScheduler.isInQuietHours(secondsFromMidnight: 3600, settings: s))
    }

    func testSilencingModeSuppresses() {
        let start = Date()
        let state = BreakReminderState(startedAt: start)
        XCTAssertFalse(BreakReminderScheduler.shouldShow(
            state: state, settings: enabled(), now: start.addingTimeInterval(3600),
            secondsFromMidnight: 12 * 3600, isSilencedByMode: true))
    }

    func testSilencingCanBeIgnoredIfTheUserPrefers() {
        var s = enabled(); s.respectsSilencingModes = false
        let start = Date()
        XCTAssertTrue(BreakReminderScheduler.shouldShow(
            state: BreakReminderState(startedAt: start), settings: s,
            now: start.addingTimeInterval(3600),
            secondsFromMidnight: 12 * 3600, isSilencedByMode: true))
    }

    func testSnoozePushesTheNextOneOut() {
        let start = Date()
        var state = BreakReminderState(startedAt: start)
        state.snoozedUntil = start.addingTimeInterval(90 * 60)
        let due = BreakReminderScheduler.nextDue(state: state, settings: enabled(interval: 30))
        XCTAssertEqual(due?.timeIntervalSince(start) ?? 0, 90 * 60, accuracy: 1)
    }

    func testSnoozeInThePastDoesNotDelayAnything() {
        let start = Date()
        var state = BreakReminderState(startedAt: start)
        state.snoozedUntil = start.addingTimeInterval(-600)
        let due = BreakReminderScheduler.nextDue(state: state, settings: enabled(interval: 30))
        XCTAssertEqual(due?.timeIntervalSince(start) ?? 0, 30 * 60, accuracy: 1)
    }

    func testIntervalIsMeasuredFromTheLastReminderNotFromLaunch() {
        let start = Date()
        var state = BreakReminderState(startedAt: start)
        state.lastShownAt = start.addingTimeInterval(3600)
        let due = BreakReminderScheduler.nextDue(state: state, settings: enabled(interval: 30))
        XCTAssertEqual(due?.timeIntervalSince(start) ?? 0, 3600 + 30 * 60, accuracy: 1)
    }

    func testSettingsAreClampedToSaneValues() {
        var s = BreakReminderSettings(isEnabled: true, intervalMinutes: 0, snoozeMinutes: 9999)
        s.validate()
        XCTAssertGreaterThanOrEqual(s.intervalMinutes, 5.0)
        XCTAssertLessThanOrEqual(s.snoozeMinutes, 120.0)
    }

    func testMessagesSuggestRatherThanInstructAndClaimNoBenefit() {
        // Guards the product language rules: no medical claims, no guilt.
        let banned = ["must", "should", "eye strain", "damage", "health", "sleep better",
                      "streak", "failed", "melatonin", "circadian"]
        for minute in 0..<8 {
            let m = BreakReminderScheduler.message(for: Date(timeIntervalSince1970: Double(minute) * 60))
                .lowercased()
            for word in banned {
                XCTAssertFalse(m.contains(word), "reminder text must not contain “\(word)”: \(m)")
            }
        }
    }
}

final class CommandPaletteTests: DaylightTestCase {

    func commands() -> [Command] {
        [
            Command(id: "pause", title: "Pause for one hour", keywords: ["stop", "off"]),
            Command(id: "resume", title: "Resume automatic mode", keywords: ["continue"]),
            Command(id: "colour", title: "Colour Work", keywords: ["neutral", "accurate", "design"]),
            Command(id: "warmer", title: "Warm the current display slightly", keywords: ["warmth"]),
            Command(id: "restore", title: "Restore normal output", keywords: ["reset", "undo"]),
        ]
    }

    func testEmptyQueryReturnsEverythingInOrder() {
        let r = CommandMatcher.rank(commands(), query: "")
        XCTAssertEqual(r.count, 5)
        XCTAssertEqual(r.first?.id, "pause")
    }

    func testExactPrefixRanksFirst() {
        XCTAssertEqual(CommandMatcher.rank(commands(), query: "resume").first?.id, "resume")
    }

    func testInitialsMatch() {
        XCTAssertEqual(CommandMatcher.rank(commands(), query: "cw").first?.id, "colour")
    }

    func testKeywordMatch() {
        XCTAssertEqual(CommandMatcher.rank(commands(), query: "undo").first?.id, "restore")
    }

    func testSubsequenceMatch() {
        // "rstr" is scattered through "Restore normal output".
        XCTAssertTrue(CommandMatcher.rank(commands(), query: "rstr").contains { $0.id == "restore" })
    }

    func testNoMatchReturnsEmptyRatherThanEverything() {
        XCTAssertTrue(CommandMatcher.rank(commands(), query: "zzzzqqq").isEmpty)
    }

    func testMatchingIsCaseInsensitiveAndTrimsSpace() {
        XCTAssertEqual(CommandMatcher.rank(commands(), query: "  COLOUR  ").first?.id, "colour")
    }

    func testPrefixBeatsMerelyContaining() {
        let list = [
            Command(id: "a", title: "Restore normal output"),
            Command(id: "b", title: "Undo and restore"),
        ]
        XCTAssertEqual(CommandMatcher.rank(list, query: "restore").first?.id, "a")
    }

    func testRankingIsStableForEqualScores() {
        let list = [Command(id: "b", title: "Bravo test"), Command(id: "a", title: "Alpha test")]
        XCTAssertEqual(CommandMatcher.rank(list, query: "test").map(\.id), ["a", "b"],
                       "ties break alphabetically so the order does not jitter")
    }
}

final class HistoryTests: DaylightTestCase {

    var dir: URL!
    var log: HistoryLog!
    let on = HistorySettings(isEnabled: true, retentionDays: 7)

    override func setUp() {
        dir = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent("daylight-history-\(UUID().uuidString)")
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        log = HistoryLog(directory: dir)
    }
    override func tearDown() { try? FileManager.default.removeItem(at: dir) }

    func testNothingIsRecordedWhileHistoryIsOff() {
        log.record(HistoryEntry(kind: .paused, summary: "Paused."),
                   settings: HistorySettings(isEnabled: false))
        XCTAssertEqual(log.count, 0)
        log.flush()
        XCTAssertFalse(FileManager.default.fileExists(atPath: dir.appendingPathComponent("history.json").path),
                       "history must not touch disk while it is switched off")
    }

    func testRecordsAndReadsBack() {
        log.record(HistoryEntry(kind: .resumed, summary: "Automation resumed."), settings: on)
        XCTAssertEqual(log.all().count, 1)
        XCTAssertEqual(log.all().first?.summary, "Automation resumed.")
    }

    func testRepeatedIdenticalEntriesAreCollapsed() {
        // A schedule ramp produces a value every minute; a log that repeats
        // itself is a log nobody reads.
        for _ in 0..<10 {
            log.record(HistoryEntry(kind: .scheduleChange, summary: "Schedule moved to Evening."),
                       settings: on)
        }
        XCTAssertEqual(log.count, 1)
    }

    func testTheSameSummaryIsRecordedAgainAfterAWhile() {
        log.record(HistoryEntry(at: Date().addingTimeInterval(-3600), kind: .paused,
                                summary: "Paused."), settings: on)
        log.record(HistoryEntry(kind: .paused, summary: "Paused."), settings: on)
        XCTAssertEqual(log.count, 2)
    }

    func testDifferentSummariesAreBothKept() {
        log.record(HistoryEntry(kind: .scheduleChange, summary: "Moved to Evening."), settings: on)
        log.record(HistoryEntry(kind: .scheduleChange, summary: "Moved to Night."), settings: on)
        XCTAssertEqual(log.count, 2)
    }

    func testNewestFirst() {
        log.record(HistoryEntry(at: Date().addingTimeInterval(-7200), kind: .paused,
                                summary: "Older."), settings: on)
        log.record(HistoryEntry(kind: .resumed, summary: "Newer."), settings: on)
        XCTAssertEqual(log.all().first?.summary, "Newer.")
    }

    func testPruningDropsEntriesPastRetention() {
        log.record(HistoryEntry(at: Date().addingTimeInterval(-10 * 86_400), kind: .paused,
                                summary: "Ancient."), settings: on)
        log.record(HistoryEntry(kind: .resumed, summary: "Recent."), settings: on)
        log.prune(settings: on)
        XCTAssertEqual(log.count, 1)
        XCTAssertEqual(log.all().first?.summary, "Recent.")
    }

    func testTheEntryCountIsCappedRegardlessOfRetention() {
        let generous = HistorySettings(isEnabled: true, retentionDays: 90)
        for i in 0..<(HistoryLog.maximumEntries + 50) {
            log.record(HistoryEntry(at: Date().addingTimeInterval(Double(i) * 120),
                                    kind: .scheduleChange, summary: "Entry \(i)"),
                       settings: generous)
        }
        XCTAssertLessThanOrEqual(log.count, HistoryLog.maximumEntries)
    }

    func testClearingRemovesEverythingAndTheFile() {
        log.record(HistoryEntry(kind: .paused, summary: "Paused."), settings: on)
        log.flush()
        XCTAssertTrue(FileManager.default.fileExists(atPath: dir.appendingPathComponent("history.json").path))
        log.clear()
        XCTAssertEqual(log.count, 0)
        XCTAssertFalse(FileManager.default.fileExists(atPath: dir.appendingPathComponent("history.json").path))
    }

    func testItSurvivesARestart() {
        log.record(HistoryEntry(kind: .modeApplied, summary: "Reading applied."), settings: on)
        log.flush()
        let reopened = HistoryLog(directory: dir)
        XCTAssertEqual(reopened.all().first?.summary, "Reading applied.")
    }

    func testFlushDoesNoWorkWhenNothingChanged() {
        log.flush()
        XCTAssertFalse(FileManager.default.fileExists(atPath: dir.appendingPathComponent("history.json").path),
                       "an idle app should not write an empty history file")
    }

    func testRetentionIsClamped() {
        var s = HistorySettings(isEnabled: true, retentionDays: 9999)
        s.validate()
        XCTAssertLessThanOrEqual(s.retentionDays, 90)
        var t = HistorySettings(isEnabled: true, retentionDays: -5)
        t.validate()
        XCTAssertGreaterThanOrEqual(t.retentionDays, 1)
    }

    func testEverySummaryStyleAvoidsHealthClaims() {
        // The log describes software activity. Guarded so a future entry
        // cannot quietly start implying an outcome.
        let banned = ["melatonin", "circadian", "eye strain", "sleep quality",
                      "healthier", "protected", "damage"]
        let samples = [
            "Schedule moved to “Evening” — about 4200 K.",
            "Reading applied.", "Paused for 60 minutes.", "Automation resumed.",
            "Normal output restored on every display.",
            "Another display utility is competing for Studio Display.",
        ]
        for sample in samples {
            for word in banned {
                XCTAssertFalse(sample.lowercased().contains(word),
                               "history text must not contain “\(word)”")
            }
        }
    }
}

final class ExtremeSettingsTests: DaylightTestCase {

    func testNormalValuesRaiseNoConcern() {
        XCTAssertNil(ExtremeSettings.concern(
            temperature: ColourTemperature(kelvin: 3200),
            dimming: SoftwareDimming(factor: 0.8)))
    }

    func testVeryWarmIsFlagged() {
        let c = ExtremeSettings.concern(temperature: ColourTemperature(kelvin: 2100),
                                        dimming: SoftwareDimming(factor: 0.9))
        XCTAssertNotNil(c)
        XCTAssertTrue(c?.title.contains("very warm") ?? false)
    }

    func testVeryDimIsFlagged() {
        let c = ExtremeSettings.concern(temperature: ColourTemperature(kelvin: 5000),
                                        dimming: SoftwareDimming(factor: 0.25))
        XCTAssertNotNil(c)
        XCTAssertTrue(c?.title.contains("very dim") ?? false)
    }

    func testBothTogetherGetTheirOwnMessage() {
        let c = ExtremeSettings.concern(temperature: ColourTemperature(kelvin: 2000),
                                        dimming: SoftwareDimming(factor: 0.25))
        XCTAssertTrue(c?.title.contains("very warm and very dim") ?? false)
        XCTAssertTrue(c?.detail.contains("Restore") ?? false || c?.detail.contains("normal output") ?? false,
                      "the way out should be part of the message")
    }

    func testTheBoundaryItselfIsNotFlagged() {
        XCTAssertNil(ExtremeSettings.concern(
            temperature: ColourTemperature(kelvin: ColourTemperature.legibilityWarningBelow),
            dimming: SoftwareDimming(factor: 0.35)))
    }

    func testMissingValuesAreTreatedAsUnchanged() {
        XCTAssertNil(ExtremeSettings.concern(temperature: nil, dimming: nil))
    }
}

final class OverrideScopeTests: DaylightTestCase {

    func testAllDisplaysIncludesEverything() {
        XCTAssertTrue(OverrideScope.allDisplays.includes(displayKey: "a", groupID: nil))
        XCTAssertTrue(OverrideScope.allDisplays.includes(displayKey: "b", groupID: UUID()))
    }

    func testASingleDisplayScopeExcludesTheOthers() {
        let scope = OverrideScope.display(key: "a")
        XCTAssertTrue(scope.includes(displayKey: "a", groupID: nil))
        XCTAssertFalse(scope.includes(displayKey: "b", groupID: nil),
                       "a change aimed at one screen must not move another")
    }

    func testAGroupScopeCoversItsMembersOnly() {
        let id = UUID()
        let scope = OverrideScope.group(id: id)
        XCTAssertTrue(scope.includes(displayKey: "a", groupID: id))
        XCTAssertFalse(scope.includes(displayKey: "b", groupID: UUID()))
        XCTAssertFalse(scope.includes(displayKey: "c", groupID: nil))
    }

    func testScopeSurvivesEncoding() {
        for scope in [OverrideScope.allDisplays, .display(key: "uuid:x"), .group(id: UUID())] {
            let o = TemporaryOverride(label: "Manual", target: LightingTarget(),
                                      expiry: .untilResumed, startedAt: Date(), scope: scope)
            let data = try! JSONEncoder().encode(o)
            let back = try! JSONDecoder().decode(TemporaryOverride.self, from: data)
            XCTAssertEqual(back.scope, scope)
        }
    }

    func testAnOverrideFromBeforeScopesExistedDefaultsToAllDisplays() {
        let legacy = """
        {"id":"11111111-1111-1111-1111-111111111111","label":"Manual",
         "target":{},"expiry":{"untilResumed":{}},
         "startedAt":"2026-01-01T00:00:00Z"}
        """
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let back = try? decoder.decode(TemporaryOverride.self, from: Data(legacy.utf8))
        XCTAssertEqual(back?.scope, OverrideScope.allDisplays)
    }
}
