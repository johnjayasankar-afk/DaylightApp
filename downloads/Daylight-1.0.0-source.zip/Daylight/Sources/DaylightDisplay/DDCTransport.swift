import Foundation
import IOKit
import CoreGraphics
import DaylightCore

/// Experimental DDC/CI brightness control for external displays.
///
/// **This is the one part of Daylight that uses private system API.** It is
/// off by default, it is never a dependency of anything else, and every path
/// through it fails closed: if the symbols are missing, if no display can be
/// matched unambiguously, or if the display does not answer a capability
/// query, the feature simply reports itself unsupported and Daylight carries
/// on with software dimming.
///
/// The symbols live in IOKit but are not in its public headers, so they are
/// resolved at runtime rather than linked. A future macOS release may remove
/// them; that would disable this module and nothing else.
enum IOAVSymbols {
    typealias CreateWithService = @convention(c) (CFAllocator?, io_service_t) -> Unmanaged<CFTypeRef>?
    typealias ReadI2C = @convention(c) (CFTypeRef, UInt32, UInt32, UnsafeMutableRawPointer, UInt32) -> IOReturn
    typealias WriteI2C = @convention(c) (CFTypeRef, UInt32, UInt32, UnsafeMutableRawPointer, UInt32) -> IOReturn
    typealias CopyEDID = @convention(c) (CFTypeRef, UnsafeMutablePointer<Unmanaged<CFData>?>) -> IOReturn

    nonisolated(unsafe) static let handle: UnsafeMutableRawPointer? =
        dlopen("/System/Library/Frameworks/IOKit.framework/IOKit", RTLD_LAZY)

    nonisolated(unsafe) static let createWithService: CreateWithService? = load("IOAVServiceCreateWithService")
    nonisolated(unsafe) static let readI2C: ReadI2C? = load("IOAVServiceReadI2C")
    nonisolated(unsafe) static let writeI2C: WriteI2C? = load("IOAVServiceWriteI2C")
    nonisolated(unsafe) static let copyEDID: CopyEDID? = load("IOAVServiceCopyEDID")

    private static func load<T>(_ name: String) -> T? {
        guard let handle, let sym = dlsym(handle, name) else { return nil }
        return unsafeBitCast(sym, to: T.self)
    }

    /// True when everything this module needs exists on this system.
    static var areAvailable: Bool {
        createWithService != nil && readI2C != nil && writeI2C != nil
    }
}

/// Puts DDC/CI messages on the wire for one external display.
final class DDCTransport {
    private let service: CFTypeRef
    /// DDC is slow and easily confused by overlapping conversations, so every
    /// exchange for a display is serialised and paced.
    private let queue: DispatchQueue
    private var lastExchange: Double = -.infinity
    private let minimumGap: Double = 0.04

    init?(displayID: CGDirectDisplayID) {
        guard IOAVSymbols.areAvailable,
              let service = DDCTransport.avService(for: displayID) else { return nil }
        self.service = service
        self.queue = DispatchQueue(label: "app.daylight.ddc.\(displayID)")
    }

    // MARK: Matching a display to its AV service

    /// Finds the AV service belonging to a display.
    ///
    /// Matched by EDID where possible. Where that is not available, the match
    /// is only accepted when there is exactly one external display and exactly
    /// one external AV service — pairing by index across several monitors would
    /// be a guess, and a wrong guess here sends brightness commands to the
    /// wrong screen.
    static func avService(for displayID: CGDirectDisplayID) -> CFTypeRef? {
        guard CGDisplayIsBuiltin(displayID) == 0 else { return nil }
        let services = externalAVServices()
        guard !services.isEmpty else { return nil }

        let wantedVendor = CGDisplayVendorNumber(displayID)
        let wantedModel = CGDisplayModelNumber(displayID)
        let wantedSerial = CGDisplaySerialNumber(displayID)

        if let copyEDID = IOAVSymbols.copyEDID {
            for candidate in services {
                var data: Unmanaged<CFData>?
                guard copyEDID(candidate, &data) == KERN_SUCCESS,
                      let edid = data?.takeRetainedValue() as Data?,
                      let ident = EDID.identity(from: edid) else { continue }
                if ident.vendor == wantedVendor && ident.model == wantedModel
                    && (wantedSerial == 0 || ident.serial == wantedSerial) {
                    return candidate
                }
            }
        }

        // Unambiguous fallback only.
        let externalDisplays = onlineDisplays().filter { CGDisplayIsBuiltin($0) == 0 }
        if externalDisplays.count == 1 && services.count == 1 { return services[0] }
        return nil
    }

    private static func onlineDisplays() -> [CGDirectDisplayID] {
        var count: UInt32 = 0
        guard CGGetOnlineDisplayList(0, nil, &count) == .success, count > 0 else { return [] }
        var ids = [CGDirectDisplayID](repeating: 0, count: Int(count))
        guard CGGetOnlineDisplayList(count, &ids, &count) == .success else { return [] }
        return Array(ids.prefix(Int(count)))
    }

    private static func externalAVServices() -> [CFTypeRef] {
        guard let create = IOAVSymbols.createWithService else { return [] }
        var out: [CFTypeRef] = []
        var iterator: io_iterator_t = 0
        guard IOServiceGetMatchingServices(kIOMainPortDefault,
                                           IOServiceMatching("DCPAVServiceProxy"),
                                           &iterator) == KERN_SUCCESS else { return [] }
        defer { IOObjectRelease(iterator) }

        var node = IOIteratorNext(iterator)
        while node != 0 {
            defer { IOObjectRelease(node); node = IOIteratorNext(iterator) }
            // The built-in panel appears here too and must be skipped: it does
            // not speak DDC, and probing it would be pointless traffic.
            let location = IORegistryEntryCreateCFProperty(
                node, "Location" as CFString, kCFAllocatorDefault, 0)?
                .takeRetainedValue() as? String
            if location == "Embedded" { continue }
            if let ref = create(kCFAllocatorDefault, node)?.takeRetainedValue() {
                out.append(ref)
            }
        }
        return out
    }

    // MARK: Exchanges

    @discardableResult
    func write(_ bytes: [UInt8]) -> Bool {
        guard let writeI2C = IOAVSymbols.writeI2C else { return false }
        return queue.sync {
            pace()
            var buffer = bytes
            let result = buffer.withUnsafeMutableBytes { raw -> IOReturn in
                guard let base = raw.baseAddress else { return KERN_FAILURE }
                return writeI2C(service, UInt32(DDCPacket.displayChipAddress),
                                UInt32(DDCPacket.hostAddress), base, UInt32(bytes.count))
            }
            lastExchange = monotonicNow()
            return result == KERN_SUCCESS
        }
    }

    func read(byteCount: Int) -> [UInt8]? {
        guard let readI2C = IOAVSymbols.readI2C else { return nil }
        return queue.sync {
            pace()
            var buffer = [UInt8](repeating: 0, count: byteCount)
            let result = buffer.withUnsafeMutableBytes { raw -> IOReturn in
                guard let base = raw.baseAddress else { return KERN_FAILURE }
                return readI2C(service, UInt32(DDCPacket.displayChipAddress), 0,
                               base, UInt32(byteCount))
            }
            lastExchange = monotonicNow()
            return result == KERN_SUCCESS ? buffer : nil
        }
    }

    /// DDC displays need a gap between messages or they start dropping them.
    private func pace() {
        let elapsed = monotonicNow() - lastExchange
        if elapsed < minimumGap { usleep(useconds_t((minimumGap - elapsed) * 1_000_000)) }
    }
}

/// EDID fields Daylight needs, and nothing else.
enum EDID {
    struct Identity { var vendor: UInt32; var model: UInt32; var serial: UInt32 }

    static func identity(from data: Data) -> Identity? {
        guard data.count >= 16 else { return nil }
        let b = [UInt8](data)
        // Bytes 8-9 hold the manufacturer id, 10-11 the product code,
        // 12-15 the serial, little-endian.
        let vendor = UInt32(b[8]) << 8 | UInt32(b[9])
        let model = UInt32(b[11]) << 8 | UInt32(b[10])
        let serial = UInt32(b[15]) << 24 | UInt32(b[14]) << 16
                   | UInt32(b[13]) << 8 | UInt32(b[12])
        return Identity(vendor: vendor, model: model, serial: serial)
    }
}

/// Hardware brightness for one external display, if it turns out to support it.
public final class DDCBrightnessChannel {
    private let transport: DDCTransport
    public private(set) var maximum: UInt16 = 0
    public private(set) var isProven = false

    public init?(displayID: CGDirectDisplayID) {
        guard let transport = DDCTransport(displayID: displayID) else { return nil }
        self.transport = transport
    }

    public static var isPossibleOnThisSystem: Bool { IOAVSymbols.areAvailable }

    /// Asks the display what its brightness range is.
    ///
    /// Support is only claimed if the display sends back a well-formed reply
    /// for the feature we asked about. A write that appears to succeed proves
    /// nothing — plenty of displays accept I²C traffic and ignore it.
    @discardableResult
    public func probe() -> Double? {
        let vcp = DDCPacket.VCP.luminance.rawValue
        for _ in 0..<3 {
            guard transport.write(DDCPacket.getVCP(vcp)) else { continue }
            usleep(50_000)
            guard let bytes = transport.read(byteCount: 12),
                  let reply = DDCPacket.parseReply(bytes, expecting: vcp) else { continue }
            maximum = reply.maximum
            isProven = true
            return DDCPacket.level(forRaw: reply.current, maximum: reply.maximum)
        }
        isProven = false
        return nil
    }

    /// Sets brightness. Refuses unless the display has already answered a
    /// capability query, so Daylight never writes blind.
    @discardableResult
    public func setBrightness(_ level: Double) -> Bool {
        guard isProven, maximum > 0 else { return false }
        let raw = DDCPacket.rawValue(forLevel: level, maximum: maximum)
        return transport.write(DDCPacket.setVCP(DDCPacket.VCP.luminance.rawValue, value: raw))
    }
}
