import Foundation
import CoreGraphics
import AppKit
import DaylightCore

/// Drives a real macOS display through its transfer (gamma) table.
///
/// Uses only public CoreGraphics API. Two properties of that API shape the
/// whole design:
///
/// 1. The table set by a process is owned by that process, and macOS restores
///    the previous state when the process exits — verified here including
///    under SIGKILL. Crash cleanup is therefore the system's job, not ours,
///    and we do not install a watchdog to duplicate it.
/// 2. Any process can overwrite any other's table at any time. So we read back
///    after writing, and treat a mismatch as evidence that something else is
///    driving the display rather than as our own failure.
public final class CoreGraphicsDisplayDevice: LightingDevice, @unchecked Sendable {

    public private(set) var displayID: CGDirectDisplayID
    public let identity: DisplayIdentity
    public var displayName: String
    public private(set) var capabilities: DisplayCapabilities

    /// The neutral table this display should return to. Captured once, from
    /// the colour profile — never from whatever happened to be on screen.
    private var baseline: (r: [Float], g: [Float], b: [Float])?
    public private(set) var baselineSource: BaselineSource?
    /// True when another process was already transforming this display when we
    /// first looked at it.
    public private(set) var foreignTransformAtCapture = false

    private var lastWrittenGains: ChannelGains?
    private var lastHardwareLevel: Double?
    private let lock = NSLock()

    /// Present only when the experiment is enabled *and* this display has
    /// answered a DDC capability query. Nothing else in the app depends on it.
    public private(set) var ddc: DDCBrightnessChannel?

    public var connectionState: ConnectionState {
        if CGDisplayIsOnline(displayID) == 0 { return .disconnected }
        if CGDisplayIsAsleep(displayID) != 0 { return .asleep }
        return .connected
    }

    public init(displayID: CGDirectDisplayID, identity: DisplayIdentity, displayName: String) {
        self.displayID = displayID
        self.identity = identity
        self.displayName = displayName
        self.capabilities = Self.probeCapabilities(displayID)
    }

    /// The display ID is transient. When a monitor reconnects, the manager
    /// matches it by durable identity and rebinds the ID here.
    public func rebind(displayID: CGDirectDisplayID) {
        lock.lock(); defer { lock.unlock() }
        self.displayID = displayID
        self.capabilities = Self.probeCapabilities(displayID)
        self.baseline = nil
        self.baselineSource = nil
        self.lastWrittenGains = nil
        self.lastHardwareLevel = nil
        // A reconnected display has to prove DDC support again; it may not even
        // be the same monitor.
        self.ddc = nil
        self.capabilities.supportsHardwareBrightness = false
    }

    /// Try DDC on this display. Called only when the person has switched the
    /// experiment on, and safe to call repeatedly.
    ///
    /// Capability is claimed only after the display answers — an accepted write
    /// proves nothing, since plenty of displays absorb I²C traffic and ignore it.
    public func enableExperimentalHardwareBrightness() {
        lock.lock(); defer { lock.unlock() }
        guard ddc == nil, !identity.isBuiltIn else { return }
        guard let channel = DDCBrightnessChannel(displayID: displayID) else { return }
        if channel.probe() != nil {
            ddc = channel
            capabilities.supportsHardwareBrightness = true
            capabilities.notes.removeAll { $0.hasPrefix("Brightness here is software dimming") }
            capabilities.notes.append("This display answered a DDC brightness query, so Daylight can drive its backlight. This path is experimental and uses private system API.")
        }
    }

    public func disableExperimentalHardwareBrightness() {
        lock.lock(); defer { lock.unlock() }
        ddc = nil
        lastHardwareLevel = nil
        capabilities = Self.probeCapabilities(displayID)
    }

    static func probeCapabilities(_ id: CGDirectDisplayID) -> DisplayCapabilities {
        let capacity = Int(CGDisplayGammaTableCapacity(id))
        var notes: [String] = []
        var hdr = false

        if let screen = NSScreen.screens.first(where: {
            ($0.deviceDescription[NSDeviceDescriptionKey("NSScreenNumber")] as? UInt32) == id
        }) {
            hdr = screen.maximumPotentialExtendedDynamicRangeColorComponentValue > 1.0
        }
        if hdr {
            notes.append("This display supports HDR. Daylight has not been able to verify how its adjustment behaves while HDR content is on screen.")
        }
        if CGDisplayIsInMirrorSet(id) != 0 {
            notes.append("This display is mirrored, so it shares its settings with the display it mirrors.")
        }
        notes.append("Brightness here is software dimming: it changes the values sent to the panel, not the backlight.")

        return DisplayCapabilities(
            supportsColourTransform: capacity > 0,
            transferTableCapacity: capacity,
            supportsSoftwareDimming: capacity > 0,
            // No public API gives real backlight control, so Daylight does not
            // claim it. See Docs/compatibility.md.
            supportsHardwareBrightness: false,
            isHDRCapable: hdr,
            notes: notes)
    }

    // MARK: Baseline

    private func readTable() -> (r: [Float], g: [Float], b: [Float])? {
        let cap = Int(CGDisplayGammaTableCapacity(displayID))
        guard cap > 0 else { return nil }
        var r = [Float](repeating: 0, count: cap), g = r, b = r
        var n: UInt32 = 0
        guard CGGetDisplayTransferByTable(displayID, UInt32(cap), &r, &g, &b, &n) == .success,
              n > 0 else { return nil }
        let k = Int(n)
        return (Array(r[0..<k]), Array(g[0..<k]), Array(b[0..<k]))
    }

    private static func identityTable(_ count: Int) -> (r: [Float], g: [Float], b: [Float]) {
        let v = (0..<count).map { Float($0) / Float(max(count - 1, 1)) }
        return (v, v, v)
    }

    public func prepare() throws {
        lock.lock(); defer { lock.unlock() }
        guard CGDisplayIsOnline(displayID) != 0 else { throw DeviceError.notConnected }
        guard capabilities.supportsColourTransform else {
            throw DeviceError.unsupportedControl("colour adjustment")
        }
        try captureBaselineLocked()
    }

    private func captureBaselineLocked() throws {
        let capacity = Int(CGDisplayGammaTableCapacity(displayID))
        guard capacity > 0 else { throw DeviceError.unsupportedControl("colour adjustment") }

        let before = readTable()

        // Ask the system to put the display back to its colour profile, then
        // read *that*. Reading the table as-found would capture whatever other
        // software had already applied — the mistake that makes an app slowly
        // bake someone else's tint into its own idea of neutral.
        CGDisplayRestoreColorSyncSettings()
        usleep(120_000)
        let candidate = readTable()

        if let before, let candidate {
            let spread = max(abs(before.r.last! - candidate.r.last!),
                             max(abs(before.g.last! - candidate.g.last!),
                                 abs(before.b.last! - candidate.b.last!)))
            foreignTransformAtCapture = spread > 0.02
        }

        if let c = candidate,
           BaselineValidator.isPlausibleBaseline(red: c.r, green: c.g, blue: c.b) {
            baseline = c
            baselineSource = .colourProfile
        } else if let c = candidate {
            // The profile did not look neutral. Rather than adopt a suspicious
            // table, fall back to a plain ramp and say so.
            baseline = Self.identityTable(c.r.count)
            baselineSource = .rejectedForeignTransform
            foreignTransformAtCapture = true
        } else {
            baseline = Self.identityTable(capacity)
            baselineSource = .identityFallback
        }
        lastWrittenGains = nil
    }

    // MARK: Apply

    public func apply(_ target: ResolvedTarget) throws -> AppliedResult {
        lock.lock(); defer { lock.unlock() }
        guard CGDisplayIsOnline(displayID) != 0 else { throw DeviceError.notConnected }
        if baseline == nil { try captureBaselineLocked() }
        guard let base = baseline else { throw DeviceError.unsupportedControl("colour adjustment") }

        let gains = target.gains
        // Always computed from the stored baseline, never from the current
        // table, so repeated applications cannot accumulate tint or dimming.
        var r = base.r.map { $0 * Float(gains.red) }
        var g = base.g.map { $0 * Float(gains.green) }
        var b = base.b.map { $0 * Float(gains.blue) }

        let err = CGSetDisplayTransferByTable(displayID, UInt32(r.count), &r, &g, &b)
        guard err == .success else {
            throw DeviceError.writeFailed(code: Int32(err.rawValue))
        }
        lastWrittenGains = gains

        // Backlight, when this display has proven it supports it. Failures here
        // never fail the colour change: dimming in software still happened.
        if let ddc, let level = target.hardwareBrightness?.level {
            if lastHardwareLevel == nil || abs((lastHardwareLevel ?? 0) - level) > 0.01 {
                if ddc.setBrightness(level) { lastHardwareLevel = level }
            }
        }

        guard let observed = readbackLocked() else {
            return AppliedResult(confidence: .acceptedBySystem, requested: gains)
        }
        let deviation = observed.maxDifference(from: gains)
        return AppliedResult(
            confidence: deviation < 0.004 ? .readbackConfirmed : .acceptedBySystem,
            requested: gains,
            readback: observed,
            deviation: deviation,
            foreignChangeDetected: deviation >= 0.02)
    }

    // MARK: Restore

    /// Puts *this* display back to its baseline, without touching any other
    /// display. A global reset would be wrong when only one device is at fault.
    public func restore() throws {
        lock.lock(); defer { lock.unlock() }
        guard CGDisplayIsOnline(displayID) != 0 else { throw DeviceError.notConnected }
        guard var base = baseline else {
            CGDisplayRestoreColorSyncSettings()
            lastWrittenGains = nil
            return
        }
        let err = CGSetDisplayTransferByTable(displayID, UInt32(base.r.count),
                                              &base.r, &base.g, &base.b)
        if err != .success { throw DeviceError.writeFailed(code: Int32(err.rawValue)) }
        lastWrittenGains = nil
    }

    // MARK: Readback

    public func readback() -> ChannelGains? {
        lock.lock(); defer { lock.unlock() }
        return readbackLocked()
    }

    private func readbackLocked() -> ChannelGains? {
        guard let base = baseline, let now = readTable() else { return nil }
        guard let br = base.r.last, let bg = base.g.last, let bb = base.b.last,
              let nr = now.r.last, let ng = now.g.last, let nb = now.b.last,
              br > 0.01, bg > 0.01, bb > 0.01 else { return nil }
        return ChannelGains(red: Double(nr / br), green: Double(ng / bg), blue: Double(nb / bb))
    }

    /// True when the display no longer shows what we last wrote, which means
    /// another application has taken over.
    public func detectForeignChange(tolerance: Double = 0.02) -> Bool {
        guard let last = lastWrittenGains, let now = readback() else { return false }
        return now.maxDifference(from: last) > tolerance
    }
}
