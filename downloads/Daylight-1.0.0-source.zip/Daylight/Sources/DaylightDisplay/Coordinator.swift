import Foundation
import Combine
import AppKit
import IOKit.ps
import DaylightCore

// MARK: - Published state

public struct DisplayStatus: Identifiable, Equatable {
    public var id: String
    public var name: String
    public var isBuiltIn: Bool
    public var isAmbiguous: Bool
    public var isMirrored: Bool
    public var connection: ConnectionState
    public var capabilities: DisplayCapabilities
    public var appliedTarget: ResolvedTarget
    public var confidence: ApplicationConfidence
    public var lastErrorMessage: String?
    public var isExcluded: Bool
    public var baselineSource: BaselineSource?
    public var foreignChangeDetected: Bool
    public var consecutiveFailures: Int
}

public struct PauseState: Equatable {
    public var startedAt: Date
    public var until: Date?
}

public struct PreviewState: Equatable {
    public var label: String
    public var target: ResolvedTarget
    public var endsAt: Date
    public var appliesToHardware: Bool
}

public struct ConflictReport: Identifiable, Equatable {
    public var id: String { displayKey }
    public var displayKey: String
    public var displayName: String
    public var message: String
}

// MARK: - Coordinator

/// The one authority that decides what every display should look like and is
/// the only thing allowed to write to one.
///
/// The interface talks to this in intents ("pause for an hour"), never in
/// hardware terms. That boundary is what keeps a slow or missing device from
/// being able to wedge the UI.
public final class LightingCoordinator: ObservableObject, DisplayManagerDelegate {

    // Published, read-only from the interface's point of view.
    @Published public private(set) var outcome: ResolutionOutcome
    @Published public private(set) var evaluation: ScheduleEvaluation
    @Published public private(set) var timeline: Timeline
    @Published public private(set) var displayStatuses: [DisplayStatus] = []
    @Published public private(set) var conflicts: [ConflictReport] = []
    @Published public private(set) var pause: PauseState?
    @Published public private(set) var activeOverride: TemporaryOverride?
    @Published public private(set) var preview: PreviewState?
    @Published public private(set) var lastAppliedAt: Date?
    /// The workspace currently recognised from the attached displays, if any.
    @Published public private(set) var activeWorkspace: Workspace?
    /// Set when a break reminder is due. The shell shows it and then calls
    /// `acknowledgeBreakReminder` or `snoozeBreakReminder`.
    @Published public private(set) var breakReminderIsDue = false
    @Published public private(set) var isSimulated: Bool
    @Published public var settings: DaylightSettings {
        didSet { settingsChanged(from: oldValue) }
    }

    private let manager: DisplayManager
    private let store: SettingsStore
    public let history: HistoryLog
    private var engines: [String: TransitionEngine] = [:]
    private var lastWrittenGains: [String: ChannelGains] = [:]
    private var lastWriteAt: [String: Double] = [:]
    private var failures: [String: Int] = [:]
    private var lastResults: [String: AppliedResult] = [:]
    private var lastErrors: [String: String] = [:]

    private var timer: DispatchSourceTimer?
    private let queue = DispatchQueue(label: "app.daylight.coordinator")
    private var previewTimer: DispatchWorkItem?
    private var savedBeforePreview: ResolvedTarget?
    private var emergencyRestoreActive = false
    private var lastConflictScan: Date = .distantPast
    private var lastLoggedAnchor: String?
    private var lastLoggedProblem: [String: String] = [:]
    private var historyFlushTimer: Timer?
    private var frontmostBundleID: String?
    private var reminderState = BreakReminderState(startedAt: Date())
    private var remindersSilencedByMode = false

    public var timeZone: TimeZone = .current
    public var onSettingsSaveError: ((String) -> Void)?

    public init(store: SettingsStore, useSimulation: Bool = false) {
        self.store = store
        self.isSimulated = useSimulation
        let loaded = store.load()
        self.settings = loaded.settings
        self.manager = DisplayManager(useSimulation: useSimulation)
        self.history = HistoryLog(directory: store.directory)

        let schedule = loaded.settings.activeSchedule ?? Presets.balanced()
        let tl = ScheduleResolver.timeline(for: schedule, on: Date(),
                                           timeZone: .current, location: loaded.settings.location)
        self.timeline = tl
        let ev = tl.evaluate(at: Date())
        self.evaluation = ev
        self.outcome = PrecedenceResolver.resolve(
            [LayerProposal(layer: .baseSchedule, label: schedule.name, target:
                LightingTarget(temperature: ev.target.temperature, dimming: ev.target.dimming))])
    }

    // MARK: Lifecycle

    public func start() {
        manager.delegate = self
        manager.start()
        NSWorkspace.shared.notificationCenter.addObserver(
            self, selector: #selector(frontmostAppChanged),
            name: NSWorkspace.didActivateApplicationNotification, object: nil)
        NotificationCenter.default.addObserver(
            self, selector: #selector(clockChanged),
            name: .NSSystemClockDidChange, object: nil)
        NotificationCenter.default.addObserver(
            self, selector: #selector(clockChanged),
            name: .NSSystemTimeZoneDidChange, object: nil)
        prepareDevices()
        rebuildTimeline()
        tick(force: true)

        history.prune(settings: settings.history)
        // Batched rather than written on every event: an idle app should do no
        // disk work, and a log is not worth an fsync per line.
        historyFlushTimer = Timer.scheduledTimer(withTimeInterval: 60, repeats: true) { [weak self] _ in
            self?.history.flush()
        }
        historyFlushTimer?.tolerance = 20
        log(.settingsChange, "Daylight started.")
    }

    /// Ordered shutdown: stop deciding, then hand every display back.
    public func shutdown(restore: Bool = true) {
        log(.settingsChange, restore ? "Daylight quit and restored your displays." : "Daylight quit.")
        history.flush()
        historyFlushTimer?.invalidate(); historyFlushTimer = nil
        timer?.cancel(); timer = nil
        previewTimer?.cancel(); previewTimer = nil
        if restore { manager.restoreAll() }
        manager.stop()
        NSWorkspace.shared.notificationCenter.removeObserver(self)
        NotificationCenter.default.removeObserver(self)
    }

    private func prepareDevices() {
        for device in manager.allDevices {
            do { try device.prepare() }
            catch { lastErrors[device.identity.key] = friendly(error) }
            if let cg = device as? CoreGraphicsDisplayDevice {
                if settings.experimentalDDCBrightness {
                    cg.enableExperimentalHardwareBrightness()
                } else {
                    cg.disableExperimentalHardwareBrightness()
                }
            }
        }
    }

    /// Re-probe after the experiment is switched on or off.
    public func refreshHardwareBrightnessSupport() {
        prepareDevices()
        refreshStatuses()
        tick(force: true)
    }

    // MARK: Notifications

    @objc private func frontmostAppChanged() {
        guard settings.appRulesEnabled else { return }
        // Only the bundle identifier is read, and it is never written to disk.
        let new = NSWorkspace.shared.frontmostApplication?.bundleIdentifier
        guard new != frontmostBundleID else { return }
        frontmostBundleID = new
        tick()
    }

    /// A clock or time-zone change invalidates every resolved time, so the
    /// timeline is rebuilt from scratch rather than adjusted.
    @objc private func clockChanged() {
        timeZone = .current
        rebuildTimeline()
        tick(force: true)
    }

    public func displayManagerDidChangeConfiguration(_ manager: DisplayManager) {
        let names = manager.allDevices.map(\.displayName).sorted()
        log(.displayChange, names.isEmpty
            ? "Displays changed — none detected."
            : "Displays changed — now \(names.joined(separator: ", ")).")
        prepareDevices()
        let before = activeWorkspace?.id
        tick(force: true)
        // Plugging in a monitor can change which workspace applies, which can
        // change the schedule, so the timeline has to be rebuilt after the
        // match is re-evaluated rather than before.
        if activeWorkspace?.id != before {
            rebuildTimeline()
            tick(force: true)
        }
    }

    public func displayManagerWillSleep(_ manager: DisplayManager) {
        timer?.cancel(); timer = nil
    }

    /// On wake, recompute where the schedule *is now* rather than replaying
    /// every transition that elapsed while the machine was asleep.
    public func displayManagerDidWake(_ manager: DisplayManager) {
        rebuildTimeline()
        for key in engines.keys { engines[key] = nil }
        engines.removeAll()
        lastWrittenGains.removeAll()
        prepareDevices()
        tick(force: true)
    }

    // MARK: Settings

    private func settingsChanged(from old: DaylightSettings) {
        if old.activeScheduleID != settings.activeScheduleID
            || old.schedules != settings.schedules
            || old.location != settings.location {
            rebuildTimeline()
        }
        persist()
        tick(force: true)
    }

    public func persist() {
        do { try store.save(settings) }
        catch { onSettingsSaveError?(friendly(error)) }
    }

    public func rebuildTimeline() {
        // A workspace can point at a different schedule entirely; falling back
        // to the active one if it has since been deleted.
        let workspaceSchedule = activeWorkspace?.scheduleID
            .flatMap { id in settings.schedules.first { $0.id == id } }
        let schedule = workspaceSchedule ?? settings.activeSchedule ?? Presets.balanced()
        timeline = ScheduleResolver.timeline(for: schedule, on: Date(),
                                             timeZone: timeZone, location: settings.location)
    }

    // MARK: History

    /// One place that decides what is worth remembering.
    func log(_ kind: HistoryEntry.Kind, _ summary: String, detail: String? = nil) {
        history.record(HistoryEntry(kind: kind, summary: summary, detail: detail),
                       settings: settings.history)
    }

    /// Turning history off erases what was kept, rather than hiding it.
    public func setHistoryEnabled(_ enabled: Bool) {
        settings.history.isEnabled = enabled
        if !enabled { history.disableAndErase() }
        else { log(.settingsChange, "History turned on.") }
    }

    public func clearHistory() {
        history.clear()
    }

    // MARK: Intents

    public func setAutomation(enabled: Bool) {
        settings.automationEnabled = enabled
        if enabled { pause = nil; emergencyRestoreActive = false }
        tick(force: true)
    }

    public func pauseAutomation(for duration: TimeInterval?) {
        pause = PauseState(startedAt: Date(),
                           until: duration.map { Date().addingTimeInterval($0) })
        activeOverride = nil
        log(.paused, duration.map {
            "Paused for \(Int($0 / 60)) minutes."
        } ?? "Paused until resumed.")
        tick(force: true)
    }

    public func resumeAutomation() {
        pause = nil
        activeOverride = nil
        emergencyRestoreActive = false
        log(.resumed, "Automation resumed.")
        tick(force: true)
    }

    /// Restore normal output immediately. Deliberately the bluntest instrument
    /// in the app: no fade, no negotiation, reachable from the keyboard.
    public func emergencyRestore() {
        emergencyRestoreActive = true
        cancelPreview()
        for device in manager.allDevices {
            do { try device.restore(); lastErrors[device.identity.key] = nil }
            catch { lastErrors[device.identity.key] = friendly(error) }
        }
        for key in engines.keys { engines[key]?.snap(to: .neutral) }
        lastWrittenGains.removeAll()
        log(.restored, "Normal output restored on every display.")
        // Recompute rather than only restoring the hardware: otherwise the
        // published state would keep describing the override that is no longer
        // in force, and the interface would confidently explain something that
        // is not on screen.
        performTick(force: true)
        objectWillChange.send()
    }

    public func applyProfile(_ profile: Profile, expiry: OverrideExpiry,
                             scope: OverrideScope = .allDisplays) {
        emergencyRestoreActive = false
        pause = nil
        activeOverride = TemporaryOverride(label: profile.name, target: profile.target,
                                           expiry: expiry, startedAt: Date(), scope: scope)
        log(.modeApplied, "\(profile.name) applied.", detail: profile.summary)
        tick(force: true)
    }

    public func setManualTarget(temperature: ColourTemperature? = nil,
                                dimming: SoftwareDimming? = nil,
                                expiry: OverrideExpiry,
                                scope: OverrideScope = .allDisplays) {
        emergencyRestoreActive = false
        pause = nil
        // Changing which displays a manual change applies to starts a fresh
        // override rather than retargeting the old one, so values never carry
        // across from a screen you were not adjusting.
        var target = activeOverride?.scope == scope
            ? (activeOverride?.target ?? LightingTarget())
            : LightingTarget()
        if let temperature { target.temperature = temperature }
        if let dimming { target.dimming = dimming }
        activeOverride = TemporaryOverride(label: scopeLabel(scope), target: target,
                                           expiry: expiry, startedAt: Date(), scope: scope)
        if let t = target.temperature {
            log(.manualChange, "Set manually to about \(Int((t.kelvin / 50).rounded() * 50)) K.")
        } else if let d = target.dimming {
            log(.manualChange, "Brightness set manually to \(Int((d.factor * 100).rounded()))%.")
        }
        tick(force: true)
    }

    private func scopeLabel(_ scope: OverrideScope) -> String {
        switch scope {
        case .allDisplays: return "Manual"
        case .display(let key):
            let name = displayStatuses.first { $0.id == key }?.name
            return name.map { "Manual on \($0)" } ?? "Manual"
        case .group(let id):
            let name = settings.groups.first { $0.id == id }?.name
            return name.map { "Manual on \($0)" } ?? "Manual"
        }
    }

    public func clearOverride() {
        activeOverride = nil
        tick(force: true)
    }

    // MARK: Preview

    /// Applies a value to real displays for a bounded time, then always puts
    /// things back — including if the app is quit or the display vanishes.
    public func startPreview(label: String, target: ResolvedTarget, seconds: TimeInterval) {
        previewTimer?.cancel()
        preview = PreviewState(label: label, target: target,
                               endsAt: Date().addingTimeInterval(seconds),
                               appliesToHardware: true)
        tick(force: true)
        let work = DispatchWorkItem { [weak self] in self?.cancelPreview() }
        previewTimer = work
        DispatchQueue.main.asyncAfter(deadline: .now() + seconds, execute: work)
    }

    public func cancelPreview() {
        previewTimer?.cancel(); previewTimer = nil
        guard preview != nil else { return }
        preview = nil
        tick(force: true)
    }

    // MARK: The loop

    private func currentContext() -> RuleContext {
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = timeZone
        let now = Date()
        let secs = Int(now.timeIntervalSince(cal.startOfDay(for: now)))
        return RuleContext(
            frontmostBundleID: settings.appRulesEnabled ? frontmostBundleID : nil,
            secondsFromMidnight: secs,
            weekday: cal.component(.weekday, from: now),
            onBattery: Self.isOnBattery(),
            connectedDisplayKeys: manager.connectedKeys,
            workspaceName: activeWorkspace?.name)
    }

    static func isOnBattery() -> Bool {
        guard let blob = IOPSCopyPowerSourcesInfo()?.takeRetainedValue(),
              let list = IOPSCopyPowerSourcesList(blob)?.takeRetainedValue() as? [CFTypeRef]
        else { return false }
        for ps in list {
            guard let d = IOPSGetPowerSourceDescription(blob, ps)?.takeUnretainedValue()
                    as? [String: Any] else { continue }
            if let state = d[kIOPSPowerSourceStateKey] as? String {
                return state == kIOPSBatteryPowerValue
            }
        }
        return false
    }

    /// Everything a single tick needs, worked out once.
    ///
    /// Split from proposal building because that used to do both: it mutated
    /// published state *and* was called once per display, which meant an IOKit
    /// power-source query and a full rules evaluation per screen per tick, and
    /// `evaluation` being republished several times a tick.
    private struct TickPlan {
        /// A pause or a restore short-circuits everything below it.
        var overriding: [LayerProposal]?
        /// Layers that apply to every display.
        var shared: [LayerProposal] = []
        /// The manual override, which may apply to only some displays.
        var scoped: (proposal: LayerProposal, scope: OverrideScope)?
    }

    /// The only place that mutates state during a tick. Runs once.
    private func prepareTick(now: Date) -> TickPlan {
        var plan = TickPlan()

        if emergencyRestoreActive || !settings.automationEnabled {
            plan.overriding = [LayerProposal(
                layer: .emergencyRestore,
                label: settings.automationEnabled ? "Restored" : "Automation off",
                target: .neutral)]
            remindersSilencedByMode = false
            return plan
        }

        if let p = pause {
            if let until = p.until, now >= until {
                pause = nil
                log(.resumed, "Pause ended; following the schedule again.")
            } else {
                plan.overriding = [LayerProposal(layer: .userPause, label: "Paused", target: .neutral)]
                remindersSilencedByMode = false
                return plan
            }
        }

        var silenced = false

        if let preview {
            plan.shared.append(LayerProposal(
                layer: .manualOverride, label: "Preview: \(preview.label)",
                target: LightingTarget(temperature: preview.target.temperature,
                                       dimming: preview.target.dimming)))
        }

        if let ov = activeOverride {
            if ov.isExpired(at: now, nextScheduleChange: evaluation.nextChangeAt) {
                activeOverride = nil
                log(.resumed, "“\(ov.label)” ended; following the schedule again.")
            } else {
                plan.scoped = (LayerProposal(layer: ov.layer, label: ov.label, target: ov.target),
                               ov.scope)
                // A mode chosen for presenting or gaming silences reminders for
                // as long as it is active.
                if settings.profiles.first(where: { $0.name == ov.label })?.silencesReminders == true {
                    silenced = true
                }
            }
        }

        // Workspace sits below app rules and above the schedule: where you are
        // shapes the day, but what you are doing right now outranks it.
        let workspace = WorkspaceMatcher.match(settings.workspaces,
                                               connected: manager.connectedKeys)
        if activeWorkspace?.id != workspace?.id { activeWorkspace = workspace }
        if let workspace, workspace.target != LightingTarget() {
            plan.shared.append(LayerProposal(layer: .workspaceProfile,
                                             label: workspace.name,
                                             target: workspace.target))
        }

        if !settings.rules.isEmpty {
            let result = RulesEngine.evaluate(rules: settings.rules,
                                              context: currentContext(),
                                              profiles: settings.profiles)
            if let p = result.proposal { plan.shared.append(p) }
            if result.silencesReminders { silenced = true }
        }
        remindersSilencedByMode = silenced

        let ev = timeline.evaluate(at: now)
        if ev != evaluation { evaluation = ev }
        plan.shared.append(LayerProposal(
            layer: .baseSchedule,
            label: settings.activeSchedule?.name ?? "Schedule",
            target: LightingTarget(temperature: ev.target.temperature, dimming: ev.target.dimming)))

        return plan
    }

    /// Pure: turns the plan into the layers that apply to one display, or to
    /// the app as a whole when `displayKey` is nil.
    private func proposals(_ plan: TickPlan, displayKey: String?) -> [LayerProposal] {
        if let overriding = plan.overriding { return overriding }
        var out = plan.shared
        if let (proposal, scope) = plan.scoped {
            let applies = displayKey.map {
                scope.includes(displayKey: $0, groupID: settings.group(containing: $0)?.id)
            } ?? true
            if applies { out.append(proposal) }
        }
        return out
    }

    public func tick(force: Bool = false) {
        if Thread.isMainThread { performTick(force: force) }
        else { DispatchQueue.main.async { self.performTick(force: force) } }
    }

    private func performTick(force: Bool) {
        let now = Date()

        // A new civil day means the resolved anchors are stale.
        var cal = Calendar(identifier: .gregorian); cal.timeZone = timeZone
        if !cal.isDate(timeline.referenceMidnight, inSameDayAs: now)
            || timeline.timeZone != timeZone {
            rebuildTimeline()
        }

        let plan = prepareTick(now: now)
        let resolved = PrecedenceResolver.resolve(proposals(plan, displayKey: nil))
        if resolved != outcome { outcome = resolved }

        guard !manager.isSystemAsleep else { scheduleNextTick(now: now); return }

        let mono = monotonicNow()
        var anyTransitioning = false

        for device in manager.allDevices {
            let key = device.identity.key
            let perDisplay = settings.settings(forDisplay: key)
            if perDisplay.isExcluded {
                continue
            }
            // A sleeping display still has a transfer table, and it is still
            // online. Writing to it now means the right value is already in
            // place when the screen comes back, rather than the screen briefly
            // showing whatever was there before. Only a genuinely disconnected
            // display is skipped.
            guard device.connectionState != .disconnected else { continue }

            // A manual change scoped to one screen must not move the others.
            // Re-resolved only when a scope is actually in play.
            let isScoped = plan.scoped.map { $0.scope != .allDisplays } ?? false
            let forThisDisplay = isScoped
                ? PrecedenceResolver.resolve(proposals(plan, displayKey: key))
                : resolved
            var wanted = perDisplay.constrain(forThisDisplay.target)

            // Where a display drives its own backlight, brightness goes there
            // and software dimming is left alone — dimming twice would be
            // darker than either setting asks for.
            let cg = device as? CoreGraphicsDisplayDevice
            if settings.experimentalDDCBrightness, perDisplay.prefersHardwareBrightness,
               device.capabilities.supportsHardwareBrightness {
                wanted = ResolvedTarget(temperature: wanted.temperature,
                                        dimming: .none,
                                        hardwareBrightness: HardwareBrightness(level: wanted.dimming.factor))
            }
            _ = cg
            var engine = engines[key] ?? TransitionEngine(initial: wanted, now: mono)

            if engine.target != wanted {
                let duration = force && emergencyRestoreActive
                    ? 0
                    : rampDuration(to: wanted, from: engine.current, now: now)
                engine.retarget(wanted, duration: duration, now: mono)
            }
            let value = engine.advance(to: mono)
            engines[key] = engine
            if !engine.isSettled { anyTransitioning = true }

            let gains = value.gains
            let policy = WritePolicy.gamma
            guard policy.shouldWrite(new: gains, last: lastWrittenGains[key],
                                     lastWriteAt: lastWriteAt[key], now: mono, force: force)
            else { continue }

            do {
                let result = try device.apply(value)
                lastWrittenGains[key] = gains
                lastWriteAt[key] = mono
                lastResults[key] = result
                lastErrors[key] = nil
                lastLoggedProblem[key] = nil
                failures[key] = 0
                lastAppliedAt = now
            } catch {
                failures[key, default: 0] += 1
                let message = friendly(error)
                lastErrors[key] = message
                if lastLoggedProblem[key] != message {
                    lastLoggedProblem[key] = message
                    log(.deviceProblem, "\(device.displayName): \(message)")
                }
                // Stop hammering a device that keeps refusing. It is retried
                // on the next configuration change, wake, or manual action.
                if failures[key, default: 0] >= 5 { lastWrittenGains[key] = gains }
            }
        }

        if evaluation.currentAnchorName != lastLoggedAnchor {
            lastLoggedAnchor = evaluation.currentAnchorName
            if settings.automationEnabled && pause == nil {
                log(.scheduleChange,
                    "Schedule moved to “\(evaluation.currentAnchorName)” — about \(Int((resolved.target.temperature.kelvin / 50).rounded() * 50)) K.")
            }
        }

        evaluateBreakReminder(now: now)

        if now.timeIntervalSince(lastConflictScan) > 30 {
            lastConflictScan = now
            scanForConflicts()
        }
        refreshStatuses()
        scheduleNextTick(now: now, transitioning: anyTransitioning)
    }

    // MARK: Break reminders

    private func evaluateBreakReminder(now: Date) {
        guard settings.breakReminders.isEnabled else {
            if breakReminderIsDue { breakReminderIsDue = false }
            return
        }
        guard !breakReminderIsDue else { return }
        let seconds = Int(Timeline.wallClockSeconds(of: now, in: timeZone))
        if BreakReminderScheduler.shouldShow(state: reminderState,
                                             settings: settings.breakReminders,
                                             now: now,
                                             secondsFromMidnight: seconds,
                                             isSilencedByMode: remindersSilencedByMode) {
            breakReminderIsDue = true
        }
    }

    /// The reminder was seen. The next one is timed from now.
    public func acknowledgeBreakReminder() {
        reminderState.lastShownAt = Date()
        reminderState.snoozedUntil = nil
        breakReminderIsDue = false
        tick()
    }

    public func snoozeBreakReminder() {
        let now = Date()
        reminderState.lastShownAt = now
        reminderState.snoozedUntil = now.addingTimeInterval(settings.breakReminders.snoozeMinutes * 60)
        breakReminderIsDue = false
        tick()
    }

    public var nextBreakReminderAt: Date? {
        BreakReminderScheduler.nextDue(state: reminderState, settings: settings.breakReminders)
    }

    public func breakReminderMessage() -> String {
        BreakReminderScheduler.message(for: Date())
    }

    private func rampDuration(to wanted: ResolvedTarget, from current: ResolvedTarget, now: Date) -> Double {
        // A schedule transition should take as long as the schedule says; a
        // manual change should feel like a direct response.
        if activeOverride != nil || preview != nil || pause != nil {
            return settings.transitionSpeed.manualRampSeconds
        }
        if case .transitioning = evaluation.phase {
            // Follow the schedule's own curve: the engine is re-targeted each
            // tick, so the ramp is short and continuous rather than restarted.
            return max(TickPlanner.minimumInterval,
                       TickPlanner.interval(from: current, to: wanted, duration: 1))
        }
        return settings.transitionSpeed.manualRampSeconds
    }

    private func scheduleNextTick(now: Date, transitioning: Bool = false) {
        timer?.cancel()

        var interval: Double
        if transitioning {
            let a = engines.values.first?.current ?? .neutral
            let b = engines.values.first?.target ?? .neutral
            interval = TickPlanner.interval(from: a, to: b,
                                            duration: settings.transitionSpeed.manualRampSeconds)
        } else if evaluation.isInTransition {
            // Long schedule ramps only need a write when the value moves by a
            // perceptible step, which for a 90-minute fade is roughly once a
            // minute rather than once a frame.
            let next = evaluation.nextChangeAt ?? now.addingTimeInterval(60)
            let remaining = max(1, next.timeIntervalSince(now))
            interval = TickPlanner.interval(from: outcome.target,
                                            to: evaluation.nextAnchor?.target ?? outcome.target,
                                            duration: remaining)
        } else {
            var candidates: [Date] = []
            if let n = evaluation.nextChangeAt { candidates.append(n) }
            if let p = preview?.endsAt { candidates.append(p) }
            if let u = pause?.until { candidates.append(u) }
            if let e = activeOverride?.expiryDate(nextScheduleChange: evaluation.nextChangeAt) {
                candidates.append(e)
            }
            interval = TickPlanner.idleInterval(nextChangeAt: candidates.min(), now: now)
        }
        interval = min(max(interval, TickPlanner.minimumInterval), TickPlanner.idleHeartbeat)

        let t = DispatchSource.makeTimerSource(queue: queue)
        t.schedule(deadline: .now() + interval, leeway: .milliseconds(transitioning ? 5 : 250))
        t.setEventHandler { [weak self] in self?.tick() }
        t.resume()
        timer = t
    }

    // MARK: Status and conflicts

    private func scanForConflicts() {
        var found: [ConflictReport] = []
        for device in manager.allDevices {
            guard let cg = device as? CoreGraphicsDisplayDevice else { continue }
            if cg.detectForeignChange() || cg.foreignTransformAtCapture {
                found.append(ConflictReport(
                    displayKey: cg.identity.key,
                    displayName: cg.displayName,
                    message: "Another display utility appears to be changing this display too. Daylight and that app will keep overwriting each other until one of them is turned off."))
            }
        }
        if found.map(\.displayKey) != conflicts.map(\.displayKey) {
            for report in found where !conflicts.contains(where: { $0.displayKey == report.displayKey }) {
                log(.conflict, "Another display utility is competing for \(report.displayName).")
            }
            conflicts = found
        }
    }

    private func refreshStatuses() {
        displayStatuses = manager.allDevices.map { device in
            let key = device.identity.key
            let per = settings.settings(forDisplay: key)
            let cg = device as? CoreGraphicsDisplayDevice
            let discovered = manager.discovered.first { $0.identity.key == key }
            return DisplayStatus(
                id: key,
                name: per.customName ?? device.displayName,
                isBuiltIn: device.identity.isBuiltIn,
                isAmbiguous: device.identity.isAmbiguous,
                isMirrored: discovered?.isMirrored ?? false,
                connection: device.connectionState,
                capabilities: device.capabilities,
                appliedTarget: engines[key]?.current ?? .neutral,
                confidence: lastResults[key]?.confidence ?? .requested,
                lastErrorMessage: lastErrors[key],
                isExcluded: per.isExcluded,
                baselineSource: cg?.baselineSource,
                foreignChangeDetected: lastResults[key]?.foreignChangeDetected ?? false,
                consecutiveFailures: failures[key] ?? 0)
        }
        .sorted { a, b in
            if a.isBuiltIn != b.isBuiltIn { return a.isBuiltIn }
            return a.name < b.name
        }
    }

    private func friendly(_ error: Error) -> String {
        (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
    }
}
