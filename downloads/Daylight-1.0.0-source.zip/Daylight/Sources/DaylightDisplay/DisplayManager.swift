import Foundation
import CoreGraphics
import AppKit
import DaylightCore

public struct DiscoveredDisplay: Identifiable, Sendable {
    public var id: String { identity.key }
    public var displayID: CGDirectDisplayID
    public var identity: DisplayIdentity
    public var name: String
    public var isMain: Bool
    public var isMirrored: Bool
    public var mirrorSourceID: CGDirectDisplayID?
    public var pixelSize: CGSize
}

/// Finds displays and gives each a durable identity.
public enum DisplayEnumerator {

    public static func discover() -> [DiscoveredDisplay] {
        var count: UInt32 = 0
        guard CGGetOnlineDisplayList(0, nil, &count) == .success, count > 0 else { return [] }
        var ids = [CGDirectDisplayID](repeating: 0, count: Int(count))
        guard CGGetOnlineDisplayList(count, &ids, &count) == .success else { return [] }

        let names = screenNames()
        var raw: [DiscoveredDisplay] = ids.prefix(Int(count)).map { id in
            var uuid: String? = nil
            if let cf = CGDisplayCreateUUIDFromDisplayID(id)?.takeRetainedValue() {
                uuid = CFUUIDCreateString(nil, cf) as String?
            }
            let vendor = CGDisplayVendorNumber(id)
            let model = CGDisplayModelNumber(id)
            let serial = CGDisplaySerialNumber(id)
            let builtIn = CGDisplayIsBuiltin(id) != 0
            let key = DisplayIdentity.makeKey(uuid: uuid, vendor: vendor, model: model,
                                              serial: serial, isBuiltIn: builtIn)
            let mirrorSource = CGDisplayMirrorsDisplay(id)
            let bounds = CGDisplayBounds(id)
            return DiscoveredDisplay(
                displayID: id,
                identity: DisplayIdentity(key: key, uuid: uuid, vendor: vendor, model: model,
                                          serial: serial, isBuiltIn: builtIn),
                name: names[id] ?? (builtIn ? "Built-in Display" : "External Display"),
                isMain: CGDisplayIsMain(id) != 0,
                isMirrored: CGDisplayIsInMirrorSet(id) != 0,
                mirrorSourceID: mirrorSource == kCGNullDirectDisplay ? nil : mirrorSource,
                pixelSize: CGSize(width: bounds.width, height: bounds.height))
        }

        // Two identical monitors with no usable serial produce the same key.
        // Rather than inventing an unstable index, Daylight keeps the shared
        // key (so settings stay predictable) and marks it, so the interface can
        // say plainly that the two displays share their settings.
        let counts = Dictionary(grouping: raw, by: \.identity.key).mapValues(\.count)
        for i in raw.indices where (counts[raw[i].identity.key] ?? 0) > 1 {
            raw[i].identity.isAmbiguous = true
        }
        return raw
    }

    static func screenNames() -> [CGDirectDisplayID: String] {
        var out: [CGDirectDisplayID: String] = [:]
        for s in NSScreen.screens {
            if let n = s.deviceDescription[NSDeviceDescriptionKey("NSScreenNumber")] as? UInt32 {
                out[n] = s.localizedName
            }
        }
        return out
    }
}

// MARK: - Manager

public protocol DisplayManagerDelegate: AnyObject {
    func displayManagerDidChangeConfiguration(_ manager: DisplayManager)
    func displayManagerDidWake(_ manager: DisplayManager)
    func displayManagerWillSleep(_ manager: DisplayManager)
}

/// Owns exactly one controller per physical display and keeps that set in step
/// with the hardware.
public final class DisplayManager {

    public private(set) var devices: [String: CoreGraphicsDisplayDevice] = [:]
    public private(set) var discovered: [DiscoveredDisplay] = []
    public weak var delegate: DisplayManagerDelegate?
    /// True between "will sleep" and "did wake": writes are pointless and can
    /// fail noisily while the display pipeline is torn down.
    public private(set) var isSystemAsleep = false

    private var reconfigureDebounce: DispatchWorkItem?
    private let useSimulation: Bool
    private var simulated: [String: SimulatedDisplayDevice] = [:]

    public init(useSimulation: Bool = false) {
        self.useSimulation = useSimulation
    }

    public func start() {
        refresh()
        CGDisplayRegisterReconfigurationCallback(displayReconfigurationCallback,
                                                 Unmanaged.passUnretained(self).toOpaque())
        let nc = NSWorkspace.shared.notificationCenter
        nc.addObserver(self, selector: #selector(willSleep),
                       name: NSWorkspace.willSleepNotification, object: nil)
        nc.addObserver(self, selector: #selector(didWake),
                       name: NSWorkspace.didWakeNotification, object: nil)
        nc.addObserver(self, selector: #selector(screensDidSleep),
                       name: NSWorkspace.screensDidSleepNotification, object: nil)
        nc.addObserver(self, selector: #selector(screensDidWake),
                       name: NSWorkspace.screensDidWakeNotification, object: nil)
    }

    public func stop() {
        CGDisplayRemoveReconfigurationCallback(displayReconfigurationCallback,
                                               Unmanaged.passUnretained(self).toOpaque())
        NSWorkspace.shared.notificationCenter.removeObserver(self)
    }

    @objc private func willSleep() {
        isSystemAsleep = true
        delegate?.displayManagerWillSleep(self)
    }
    @objc private func screensDidSleep() { isSystemAsleep = true }

    @objc private func didWake() {
        isSystemAsleep = false
        // After sleep the display pipeline may not be ready for a moment, and
        // gamma set before sleep is often gone. Re-establish rather than
        // assume, and recompute the current desired state rather than
        // replaying every transition that was missed while asleep.
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [weak self] in
            guard let self else { return }
            self.refresh(forceRebaseline: true)
            self.delegate?.displayManagerDidWake(self)
        }
    }
    @objc private func screensDidWake() { didWake() }

    /// Coalesces the burst of callbacks macOS emits during a single dock,
    /// undock or resolution change.
    fileprivate func scheduleRefresh() {
        reconfigureDebounce?.cancel()
        let work = DispatchWorkItem { [weak self] in
            guard let self else { return }
            self.refresh()
            self.delegate?.displayManagerDidChangeConfiguration(self)
        }
        reconfigureDebounce = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.7, execute: work)
    }

    public func refresh(forceRebaseline: Bool = false) {
        if useSimulation {
            if simulated.isEmpty {
                let a = SimulatedDisplayDevice(key: "sim:builtin", displayName: "Simulated Built-in", isBuiltIn: true)
                let b = SimulatedDisplayDevice(key: "sim:external", displayName: "Simulated External")
                simulated = [a.identity.key: a, b.identity.key: b]
                try? a.prepare(); try? b.prepare()
            }
            return
        }

        let found = DisplayEnumerator.discover()
        discovered = found
        var next: [String: CoreGraphicsDisplayDevice] = [:]

        for d in found {
            if let existing = devices[d.identity.key] {
                if existing.displayID != d.displayID || forceRebaseline {
                    // Same physical display, new transient ID (reconnect, dock,
                    // wake). Rebind and recapture rather than writing to a
                    // stale ID.
                    existing.rebind(displayID: d.displayID)
                }
                existing.displayName = d.name
                next[d.identity.key] = existing
            } else {
                next[d.identity.key] = CoreGraphicsDisplayDevice(
                    displayID: d.displayID, identity: d.identity, displayName: d.name)
            }
        }
        devices = next
    }

    public var allDevices: [LightingDevice] {
        useSimulation ? Array(simulated.values) : Array(devices.values)
    }

    public func device(forKey key: String) -> LightingDevice? {
        useSimulation ? simulated[key] : devices[key]
    }

    public var connectedKeys: Set<String> { Set(allDevices.map(\.identity.key)) }

    /// Best-effort restoration of every display Daylight touched.
    public func restoreAll() {
        for d in allDevices { try? d.restore() }
    }
}

private func displayReconfigurationCallback(display: CGDirectDisplayID,
                                            flags: CGDisplayChangeSummaryFlags,
                                            userInfo: UnsafeMutableRawPointer?) {
    guard let userInfo else { return }
    let manager = Unmanaged<DisplayManager>.fromOpaque(userInfo).takeUnretainedValue()
    // Only react once the change has actually happened.
    guard !flags.contains(.beginConfigurationFlag) else { return }
    DispatchQueue.main.async { manager.scheduleRefresh() }
}
