import Foundation
import DaylightCore

/// `Daylight --export-site-data` — emits the presets and city list as JSON.
///
/// The landing page runs its own copy of the schedule maths so the curve on it
/// is the real thing rather than an illustration. Hand-transcribing the presets
/// into JavaScript would guarantee the two drift apart the first time a preset
/// changed, so the page's data is generated from these same values instead.
enum SiteData {

    static func run() {
        var out: [String: Any] = [:]

        out["presets"] = [Presets.balanced(), Presets.subtle(),
                          Presets.extraWarm(), Presets.solar()].map(encode)

        out["cities"] = Cities.all.map { city in
            [
                "name": city.name,
                "region": city.region,
                "lat": round(city.latitude * 10_000) / 10_000,
                "lon": round(city.longitude * 10_000) / 10_000,
                "tz": city.timeZoneIdentifier,
            ] as [String: Any]
        }

        out["constants"] = [
            "neutralKelvin": ColourTemperature.neutral.kelvin,
            "warmestKelvin": ColourTemperature.advancedRange.lowerBound,
            "normalRange": [ColourTemperature.normalRange.lowerBound,
                            ColourTemperature.normalRange.upperBound],
            "dimmingFloor": SoftwareDimming.safeFloor,
        ]

        guard let data = try? JSONSerialization.data(
            withJSONObject: out, options: [.prettyPrinted, .sortedKeys]),
              let text = String(data: data, encoding: .utf8) else {
            FileHandle.standardError.write(Data("could not encode\n".utf8))
            exit(1)
        }
        print(text)
    }

    private static func encode(_ schedule: Schedule) -> [String: Any] {
        [
            "name": schedule.name,
            "anchors": schedule.weekdayAnchors.map { anchor -> [String: Any] in
                var out: [String: Any] = [
                    "name": anchor.name,
                    "kelvin": anchor.temperature.kelvin,
                    "brightness": anchor.dimming.factor,
                    "fade": anchor.transitionMinutes,
                ]
                switch anchor.time {
                case .clock(let seconds):
                    out["kind"] = "clock"
                    out["minute"] = seconds / 60
                case .solar(let event, let offset, let earliest, let latest):
                    out["kind"] = "solar"
                    out["event"] = event.rawValue
                    out["offset"] = offset
                    if let earliest { out["earliest"] = earliest / 60 }
                    if let latest { out["latest"] = latest / 60 }
                }
                return out
            },
        ]
    }
}
