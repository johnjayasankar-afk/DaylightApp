import Foundation
import AppKit
import CoreGraphics
import DaylightCore
import DaylightDisplay

/// `Daylight --diagnose` — a report on what this Mac's displays actually
/// support, written to stdout and changing nothing.
///
/// This exists because the multi-display paths cannot be verified on a machine
/// with one display. Run it with monitors attached, dock and undock, and the
/// output says plainly which behaviours were observed rather than assumed.
enum Diagnostics {

    /// Runs the real engine against the real displays for a few seconds and
    /// reports what actually reached the hardware, then puts everything back.
    ///
    /// This is the end-to-end check: settings in, gamma table out. It exists
    /// because "the schedule is right and the display layer is right" does not
    /// prove the two are connected.
    static func selfTest() {
        print("\(Branding.productName) \(Branding.version) — end-to-end self-test")
        print(String(repeating: "=", count: 64))

        let store = SettingsStore(directory: SettingsStore.defaultDirectory())
        let coordinator = LightingCoordinator(store: store, useSimulation: false)
        coordinator.start()
        RunLoop.current.run(until: Date().addingTimeInterval(2.0))

        let target = coordinator.outcome.target
        print("")
        print("Engine says")
        print(String(format: "  %.0f K at %.0f%%  ->  R %.4f  G %.4f  B %.4f",
                     target.temperature.kelvin, target.dimming.factor * 100,
                     target.gains.red, target.gains.green, target.gains.blue))
        print("  \(coordinator.outcome.explanation)")

        print("")
        print("Displays the coordinator is driving: \(coordinator.displayStatuses.count)")
        for status in coordinator.displayStatuses {
            print("  \(status.name)")
            print("    connection    \(status.connection.displayName)")
            print("    excluded      \(status.isExcluded)")
            print("    confidence    \(status.confidence.shortLabel)")
            if let error = status.lastErrorMessage { print("    ERROR         \(error)") }
            print(String(format: "    applied       %.0f K at %.0f%%",
                         status.appliedTarget.temperature.kelvin,
                         status.appliedTarget.dimming.factor * 100))
        }

        print("")
        print("What the hardware actually reads back")
        var count: UInt32 = 0
        CGGetOnlineDisplayList(0, nil, &count)
        var ids = [CGDirectDisplayID](repeating: 0, count: Int(count))
        CGGetOnlineDisplayList(count, &ids, &count)
        for id in ids.prefix(Int(count)) {
            let cap = Int(CGDisplayGammaTableCapacity(id))
            var r = [Float](repeating: 0, count: cap), g = r, b = r
            var n: UInt32 = 0
            if CGGetDisplayTransferByTable(id, UInt32(cap), &r, &g, &b, &n) == .success, n > 0 {
                let k = Int(n) - 1
                print(String(format: "  display %u   R %.4f  G %.4f  B %.4f", id, r[k], g[k], b[k]))
            }
        }

        print("")
        print("Restoring and exiting.")
        coordinator.shutdown(restore: true)
        fflush(stdout)
        exit(0)
    }

    static func run(watch: Bool) {
        print("\(Branding.productName) \(Branding.version) — display diagnostics")
        print(String(repeating: "=", count: 64))
        print("macOS \(ProcessInfo.processInfo.operatingSystemVersionString)")
        print("Run at \(ISO8601DateFormatter().string(from: Date()))")
        print("")
        report()

        guard watch else { fflush(stdout); exit(0) }

        print("")
        print("Watching for display changes. Dock, undock, sleep, wake, or")
        print("rearrange your displays — each change will be reported.")
        print("Press Ctrl-C to stop.")
        print("")

        let watcher = Watcher()
        watcher.start()
        NSApplication.shared.setActivationPolicy(.prohibited)
        RunLoop.current.run()
    }

    static func report() {
        let displays = DisplayEnumerator.discover()
        print("Displays found: \(displays.count)")
        if displays.isEmpty { print("  (none — is anything connected?)"); return }

        let keys = displays.map(\.identity.key)
        let duplicates = Set(keys.filter { key in keys.filter { $0 == key }.count > 1 })

        for (index, d) in displays.enumerated() {
            print("")
            print("[\(index + 1)] \(d.name)")
            print("    durable key    \(d.identity.key)")
            print("    transient id   \(d.displayID)   <- changes on reconnect; never stored")
            print("    kind           \(d.identity.isBuiltIn ? "built-in" : "external")\(d.isMain ? ", main" : "")")
            print("    size           \(Int(d.pixelSize.width)) x \(Int(d.pixelSize.height))")
            print("    vendor/model   \(d.identity.vendor) / \(d.identity.model)  serial \(d.identity.serial)")

            if d.isMirrored {
                print("    MIRRORED       shares output with display \(d.mirrorSourceID.map(String.init) ?? "unknown")")
            }
            if duplicates.contains(d.identity.key) {
                print("    AMBIGUOUS      another connected display reports the same identity;")
                print("                   Daylight will share settings between them rather than guess")
            }

            let device = CoreGraphicsDisplayDevice(displayID: d.displayID,
                                                   identity: d.identity, displayName: d.name)
            let caps = device.capabilities
            print("    colour control \(caps.supportsColourTransform ? "yes" : "NO") (\(caps.transferTableCapacity)-entry table)")
            print("    HDR capable    \(caps.isHDRCapable ? "yes — transfer-table interaction with HDR content is unverified" : "no")")

            // Read-only capability check: capture a baseline and read it back.
            // Nothing is written to the display.
            do {
                try device.prepare()
                let source = device.baselineSource.map { String(describing: $0) } ?? "none"
                print("    baseline       \(source)")
                if device.foreignTransformAtCapture {
                    print("    CONFLICT       another utility appears to be adjusting this display")
                }
                if let gains = device.readback() {
                    print(String(format: "    readback       R %.4f  G %.4f  B %.4f",
                                 gains.red, gains.green, gains.blue))
                } else {
                    print("    readback       unavailable — changes could be applied but not confirmed")
                }
            } catch {
                print("    ERROR          \((error as? LocalizedError)?.errorDescription ?? "\(error)")")
            }

            if !d.identity.isBuiltIn {
                if DDCBrightnessChannel.isPossibleOnThisSystem {
                    if let channel = DDCBrightnessChannel(displayID: d.displayID) {
                        if let level = channel.probe() {
                            print(String(format: "    DDC brightness answered a query — currently %.0f%% of max %d",
                                         level * 100, Int(channel.maximum)))
                        } else {
                            print("    DDC brightness no answer — this display, cable or dock does not support it")
                        }
                    } else {
                        print("    DDC brightness could not be matched to a service unambiguously")
                    }
                } else {
                    print("    DDC brightness unavailable — the system APIs it needs are not present")
                }
            }
        }

        print("")
        print("Nothing above changed any display. Baselines were captured read-only.")
        reportEngine()
    }

    /// What Daylight has actually loaded, and what it concludes from it.
    ///
    /// Reads the same settings file the app uses and runs the same engine, so
    /// "the schedule says one thing but my screen shows another" has somewhere
    /// to be answered.
    static func reportEngine() {
        let directory = SettingsStore.defaultDirectory()
        let store = SettingsStore(directory: directory)
        let outcome = store.load()
        let s = outcome.settings

        print("")
        print("Settings")
        print(String(repeating: "-", count: 64))
        print("  file            \(directory.appendingPathComponent("settings.json").path)")
        if outcome.isFirstRun { print("  (no settings file yet; defaults in use)") }
        if outcome.recoveredFromCorruption { print("  RECOVERED       the settings file could not be read") }
        print("  automation      \(s.automationEnabled ? "on" : "OFF")")
        print("  onboarding done \(s.hasCompletedOnboarding)")
        print("  schedules       \(s.schedules.map(\.name).joined(separator: ", "))")
        print("  active schedule \(s.activeSchedule?.name ?? "none")")
        print("  excluded        \(s.displays.filter(\.isExcluded).map(\.id).joined(separator: ", ").ifEmpty("none"))")

        guard let schedule = s.activeSchedule else {
            print("  no active schedule, so nothing would be applied")
            return
        }
        let timeline = ScheduleResolver.timeline(for: schedule, on: Date(),
                                                 timeZone: .current, location: s.location)
        let now = Date()
        let ev = timeline.evaluate(at: now)
        print("")
        print("What the schedule asks for right now")
        print(String(repeating: "-", count: 64))
        print("  step            \(ev.currentAnchorName)")
        print(String(format: "  warmth          %.0f K", ev.target.temperature.kelvin))
        print(String(format: "  dimming         %.0f%%", ev.target.dimming.factor * 100))
        let gains = ev.target.gains
        print(String(format: "  gains           R %.4f  G %.4f  B %.4f", gains.red, gains.green, gains.blue))
        if let next = ev.nextChangeAt {
            let f = DateFormatter(); f.timeStyle = .short
            print("  next change     \(f.string(from: next))")
        }
        for d in timeline.diagnostics { print("  note            \(d.message)") }
        print("")
        print("If a display's readback above does not match these gains while")
        print("Daylight is running, something else is writing to that display.")
    }

    final class Watcher: DisplayManagerDelegate {
        private let manager = DisplayManager()
        private var lastKeys: Set<String> = []

        func start() {
            manager.delegate = self
            manager.start()
            lastKeys = Set(DisplayEnumerator.discover().map(\.identity.key))
        }

        func displayManagerDidChangeConfiguration(_ manager: DisplayManager) {
            let now = Set(DisplayEnumerator.discover().map(\.identity.key))
            let added = now.subtracting(lastKeys)
            let removed = lastKeys.subtracting(now)
            print("--- configuration changed at \(Format.stamp()) ---")
            for key in added { print("    connected:    \(key)") }
            for key in removed { print("    disconnected: \(key)") }
            if added.isEmpty && removed.isEmpty {
                print("    same displays — resolution, arrangement or mirroring changed")
            }
            lastKeys = now
            Diagnostics.report()
            print("")
        }

        func displayManagerWillSleep(_ manager: DisplayManager) {
            print("--- system going to sleep at \(Format.stamp()) ---")
        }

        func displayManagerDidWake(_ manager: DisplayManager) {
            print("--- woke at \(Format.stamp()); re-establishing baselines ---")
            Diagnostics.report()
            print("")
        }
    }

    enum Format {
        static func stamp() -> String {
            let f = DateFormatter(); f.dateFormat = "HH:mm:ss"
            return f.string(from: Date())
        }
    }
}


private extension String {
    /// Small readability helper for diagnostics output.
    func ifEmpty(_ fallback: String) -> String { isEmpty ? fallback : self }
}
