import AppKit
import DaylightCore
import DaylightDisplay

@main
struct DaylightMain {

    /// The application delegate, held for the life of the process.
    ///
    /// `NSApplication.delegate` is a **weak** reference. A delegate kept only
    /// in a local constant can be released by ARC as soon as the assignment is
    /// its last strong use — which is before `run()` ever calls
    /// `applicationDidFinishLaunching`. The app then sits there alive, using no
    /// CPU, with no menu bar icon and no schedule running.
    ///
    /// This bit us: it worked for several builds and then stopped, because
    /// nothing about the original code guaranteed the lifetime — unrelated
    /// edits changed what the optimiser did. A stored reference is the fix.
    private static let delegate = AppDelegate()

    static func main() {
        // A read-only report, for checking what a particular set of monitors
        // actually supports. Runs without the interface and changes nothing.
        let args = ProcessInfo.processInfo.arguments
        if args.contains("--export-site-data") {
            SiteData.run()
            return
        }
        if args.contains("--diagnose") || args.contains("--watch-displays") {
            Diagnostics.run(watch: args.contains("--watch-displays"))
            return
        }
        if args.contains("--self-test") {
            // Needs a real application object: the coordinator listens for
            // workspace notifications and drives timers.
            let app = NSApplication.shared
            app.setActivationPolicy(.prohibited)
            Diagnostics.selfTest()
            return
        }

        let app = NSApplication.shared
        app.delegate = delegate
        // A menu bar utility, not a windowed app: no Dock icon by default.
        app.setActivationPolicy(.accessory)
        app.run()
    }
}
