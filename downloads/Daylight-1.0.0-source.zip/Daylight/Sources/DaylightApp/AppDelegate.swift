import AppKit
import SwiftUI
import ServiceManagement
import DaylightCore
import DaylightDisplay
import DaylightUI

final class AppDelegate: NSObject, NSApplicationDelegate, NSPopoverDelegate, NSWindowDelegate, AppCommands {

    private(set) var coordinator: LightingCoordinator!
    private var statusItem: NSStatusItem!
    private var popover: NSPopover!
    private var mainWindow: NSWindow?
    private var onboardingWindow: NSWindow?
    private var hotKeys: [Any] = []
    private var iconRefreshTimer: Timer?
    private var paletteWindow: NSPanel?
    private var reminderWindow: NSPanel?
    private var reminderObserver: NSObjectProtocol?
    private var reminderPoll: Timer?
    var unavailableShortcuts: [String] = []

    func applicationDidFinishLaunching(_ notification: Notification) {
        let simulate = ProcessInfo.processInfo.arguments.contains("--simulate")
            || ProcessInfo.processInfo.environment["DAYLIGHT_SIMULATE"] == "1"

        let store = SettingsStore(directory: SettingsStore.defaultDirectory())
        coordinator = LightingCoordinator(store: store, useSimulation: simulate)
        coordinator.onSettingsSaveError = { message in
            NSLog("Daylight settings save failed: %@", message)
        }

        buildStatusItem()
        buildMenus()
        registerHotKeys()

        coordinator.start()
        observeCoordinator()
        observeBreakReminders()

        if !coordinator.settings.hasCompletedOnboarding {
            showOnboarding()
        }
    }

    func applicationShouldTerminate(_ sender: NSApplication) -> NSApplication.TerminateReply {
        reminderPoll?.invalidate()
        iconRefreshTimer?.invalidate()
        closeCommandPalette()
        dismissBreakReminderWindow()
        // Quitting hands every display back before the process exits. macOS
        // would also restore the gamma table on exit, but doing it explicitly
        // means the screen is already correct by the time the app disappears.
        coordinator.shutdown(restore: true)
        return .terminateNow
    }

    /// Closing the settings window leaves the app running in the menu bar,
    /// which is explained during onboarding and again in Settings.
    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows: Bool) -> Bool {
        showMainWindow()
        return true
    }

    // MARK: Status item

    private func buildStatusItem() {
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        statusItem.button?.target = self
        statusItem.button?.action = #selector(statusItemClicked(_:))
        statusItem.button?.sendAction(on: [.leftMouseUp, .rightMouseUp])

        popover = NSPopover()
        popover.behavior = .transient
        popover.animates = true
        popover.delegate = self
        // The popover's view hierarchy is built the first time it is opened.
        // Most launches are a login item that nobody clicks for hours, and
        // holding a whole SwiftUI hosting controller for that is wasted memory.
        refreshStatusIcon()
    }

    private func observeCoordinator() {
        // The icon only needs to keep up with visible change, so it refreshes
        // on a slow timer rather than on every engine tick.
        iconRefreshTimer = Timer.scheduledTimer(withTimeInterval: 20, repeats: true) { [weak self] _ in
            self?.refreshStatusIcon()
        }
        iconRefreshTimer?.tolerance = 5
    }

    func refreshStatusIcon() {
        guard let button = statusItem.button else { return }
        let off = !coordinator.settings.automationEnabled
        let paused = coordinator.pause != nil
        let temp = coordinator.outcome.target.temperature
        button.image = DaylightUI.statusImage(paused: paused, automationOff: off, temperature: temp)
        button.setAccessibilityLabel(
            DaylightUI.statusAccessibilityLabel(paused: paused, automationOff: off, temperature: temp))
        button.toolTip = coordinator.outcome.explanation

        if coordinator.settings.showsMenuBarPercentage && !off && !paused {
            // "2800 K" would be too wide for a menu bar; "2.8k" reads at a
            // glance and is honest about being approximate.
            button.title = String(format: " %.1fk", temp.kelvin / 1000)
            button.imagePosition = .imageLeading
        } else {
            button.title = ""
            button.imagePosition = .imageOnly
        }
    }

    @objc private func statusItemClicked(_ sender: NSStatusBarButton) {
        let event = NSApp.currentEvent
        if event?.type == .rightMouseUp {
            showContextMenu()
        } else {
            togglePopover()
        }
    }

    private func togglePopover() {
        guard let button = statusItem.button else { return }
        if popover.isShown {
            popover.performClose(nil)
        } else {
            if popover.contentViewController == nil {
                popover.contentViewController = NSHostingController(
                    rootView: DaylightUI.menuBar(coordinator: coordinator, commands: self))
            }
            refreshStatusIcon()
            popover.show(relativeTo: button.bounds, of: button, preferredEdge: .minY)
            popover.contentViewController?.view.window?.makeKey()
        }
    }

    private func showContextMenu() {
        let menu = NSMenu()
        menu.addItem(withTitle: "Open \(Branding.productName)…", action: #selector(showMainWindow), keyEquivalent: "")
            .target = self
        menu.addItem(withTitle: "Restore Normal Output", action: #selector(emergencyRestore), keyEquivalent: "")
            .target = self
        menu.addItem(.separator())
        menu.addItem(withTitle: "Quit \(Branding.productName)", action: #selector(quit), keyEquivalent: "q")
            .target = self
        statusItem.menu = menu
        statusItem.button?.performClick(nil)
        statusItem.menu = nil
    }

    // MARK: Menus (also gives the app real keyboard shortcuts)

    private func buildMenus() {
        let main = NSMenu()

        let appItem = NSMenuItem()
        let appMenu = NSMenu()
        appMenu.addItem(withTitle: "About \(Branding.productName)", action: #selector(showAbout), keyEquivalent: "").target = self
        appMenu.addItem(.separator())
        appMenu.addItem(withTitle: "Settings…", action: #selector(showMainWindow), keyEquivalent: ",").target = self
        let palette = NSMenuItem(title: "Command Palette…", action: #selector(toggleCommandPalette), keyEquivalent: "k")
        palette.keyEquivalentModifierMask = [.command, .shift]
        palette.target = self
        appMenu.addItem(palette)
        appMenu.addItem(.separator())
        let restore = NSMenuItem(title: "Restore Normal Output", action: #selector(emergencyRestore), keyEquivalent: "r")
        restore.keyEquivalentModifierMask = [.command, .shift]
        restore.target = self
        appMenu.addItem(restore)
        appMenu.addItem(.separator())
        appMenu.addItem(withTitle: "Hide \(Branding.productName)", action: #selector(NSApplication.hide(_:)), keyEquivalent: "h")
        appMenu.addItem(withTitle: "Quit \(Branding.productName)", action: #selector(quit), keyEquivalent: "q").target = self
        appItem.submenu = appMenu
        main.addItem(appItem)

        let editItem = NSMenuItem()
        let editMenu = NSMenu(title: "Edit")
        editMenu.addItem(withTitle: "Undo", action: Selector(("undo:")), keyEquivalent: "z")
        editMenu.addItem(withTitle: "Redo", action: Selector(("redo:")), keyEquivalent: "Z")
        editMenu.addItem(.separator())
        editMenu.addItem(withTitle: "Cut", action: #selector(NSText.cut(_:)), keyEquivalent: "x")
        editMenu.addItem(withTitle: "Copy", action: #selector(NSText.copy(_:)), keyEquivalent: "c")
        editMenu.addItem(withTitle: "Paste", action: #selector(NSText.paste(_:)), keyEquivalent: "v")
        editMenu.addItem(withTitle: "Select All", action: #selector(NSText.selectAll(_:)), keyEquivalent: "a")
        editItem.submenu = editMenu
        main.addItem(editItem)

        let windowItem = NSMenuItem()
        let windowMenu = NSMenu(title: "Window")
        windowMenu.addItem(withTitle: "Close", action: #selector(NSWindow.performClose(_:)), keyEquivalent: "w")
        windowItem.submenu = windowMenu
        main.addItem(windowItem)

        NSApp.mainMenu = main
        NSApp.windowsMenu = windowMenu
    }

    private func registerHotKeys() {
        unavailableShortcuts = []
        func add(_ combo: (keyCode: UInt32, modifiers: UInt32, description: String),
                 _ name: String, _ action: @escaping () -> Void) {
            if let hk = DaylightUI.registerShortcut(keyCode: combo.keyCode,
                                                    modifiers: combo.modifiers,
                                                    description: combo.description,
                                                    action: action) {
                hotKeys.append(hk)
            } else {
                unavailableShortcuts.append("\(name) (\(combo.description))")
            }
        }
        add(DaylightUI.Shortcuts.restore, "Restore normal output") { [weak self] in
            self?.emergencyRestore()
        }
        add(DaylightUI.Shortcuts.openApp, "Open \(Branding.productName)") { [weak self] in
            self?.showMainWindow()
        }
        add(DaylightUI.Shortcuts.palette, "Command palette") { [weak self] in
            self?.toggleCommandPalette()
        }
        add(DaylightUI.Shortcuts.toggleAutomation, "Pause or resume") { [weak self] in
            guard let self else { return }
            if self.coordinator.pause == nil {
                self.coordinator.pauseAutomation(for: 3600)
            } else {
                self.coordinator.resumeAutomation()
            }
            self.refreshStatusIcon()
        }
    }

    // MARK: Actions

    @objc func emergencyRestore() {
        coordinator.emergencyRestore()
        refreshStatusIcon()
    }

    @objc func quit() { NSApp.terminate(nil) }

    @objc func showAbout() {
        NSApp.activate(ignoringOtherApps: true)
        NSApp.orderFrontStandardAboutPanel(options: [
            .applicationName: Branding.productName,
            .applicationVersion: Branding.version,
            .credits: NSAttributedString(
                string: Branding.tagline,
                attributes: [.font: NSFont.systemFont(ofSize: 11)])
        ])
    }

    @objc func showMainWindow() {
        popover.performClose(nil)
        if mainWindow == nil {
            let hosting = NSHostingController(
                rootView: DaylightUI.mainWindow(coordinator: coordinator, commands: self))
            let window = NSWindow(contentViewController: hosting)
            window.title = Branding.productName
            window.setContentSize(NSSize(width: 940, height: 640))
            window.contentMinSize = NSSize(width: 720, height: 520)
            window.styleMask = [.titled, .closable, .miniaturizable, .resizable, .fullSizeContentView]
            window.titlebarAppearsTransparent = true
            window.isReleasedWhenClosed = false
            window.center()
            window.setFrameAutosaveName("DaylightMainWindow")
            window.delegate = self
            mainWindow = window
        }
        // While a real window is open, behave like a real app: a Dock icon and
        // an entry in the app switcher. Back to a menu bar accessory when it
        // closes, so an app that lives in the menu bar does not permanently
        // occupy the Dock.
        showsAsRegularApp(true)
        NSApp.activate(ignoringOtherApps: true)
        mainWindow?.makeKeyAndOrderFront(nil)
    }

    private func showsAsRegularApp(_ regular: Bool) {
        let wanted: NSApplication.ActivationPolicy = regular ? .regular : .accessory
        guard NSApp.activationPolicy() != wanted else { return }
        NSApp.setActivationPolicy(wanted)
    }

    /// Called when either window closes. The policy drops back only once no
    /// window is left, so closing onboarding while settings is open does not
    /// make the Dock icon flicker away.
    func windowWillClose(_ notification: Notification) {
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            let stillOpen = [self.mainWindow, self.onboardingWindow]
                .compactMap { $0 }
                .contains { $0.isVisible }
            if !stillOpen { self.showsAsRegularApp(false) }
        }
    }

    func showOnboarding() {
        if onboardingWindow == nil {
            let hosting = NSHostingController(
                rootView: DaylightUI.onboarding(coordinator: coordinator, commands: self))
            let window = NSWindow(contentViewController: hosting)
            window.title = "Welcome to \(Branding.productName)"
            window.setContentSize(NSSize(width: 640, height: 560))
            window.styleMask = [.titled, .closable, .fullSizeContentView]
            window.titlebarAppearsTransparent = true
            window.isReleasedWhenClosed = false
            window.center()
            window.delegate = self
            onboardingWindow = window
        }
        showsAsRegularApp(true)
        NSApp.activate(ignoringOtherApps: true)
        onboardingWindow?.makeKeyAndOrderFront(nil)
    }

    func finishOnboarding() {
        // Whatever happened during setup, the display must not be left holding
        // a preview value.
        coordinator.cancelPreview()
        coordinator.settings.hasCompletedOnboarding = true
        onboardingWindow?.close()
        onboardingWindow = nil
        showMainWindow()
    }

    func closePopover() { popover.performClose(nil) }

    // MARK: Command palette

    @objc func toggleCommandPalette() {
        if let existing = paletteWindow, existing.isVisible {
            closeCommandPalette()
            return
        }
        let content = DaylightUI.commandPalette(coordinator: coordinator) { [weak self] in
            self?.closeCommandPalette()
            self?.refreshStatusIcon()
        }
        let panel = NSPanel(contentRect: NSRect(x: 0, y: 0, width: 460, height: 200),
                            styleMask: [.titled, .fullSizeContentView, .nonactivatingPanel],
                            backing: .buffered, defer: false)
        panel.contentViewController = NSHostingController(rootView: content)
        panel.titlebarAppearsTransparent = true
        panel.titleVisibility = .hidden
        panel.isFloatingPanel = true
        panel.level = .floating
        panel.hidesOnDeactivate = true
        panel.isReleasedWhenClosed = false
        panel.center()
        // Sit a little above centre, where a launcher is expected to be.
        if let screen = NSScreen.main {
            var frame = panel.frame
            frame.origin.y = screen.visibleFrame.midY + screen.visibleFrame.height * 0.12
            panel.setFrameOrigin(frame.origin)
        }
        paletteWindow = panel
        NSApp.activate(ignoringOtherApps: true)
        panel.makeKeyAndOrderFront(nil)
    }

    func closeCommandPalette() {
        paletteWindow?.orderOut(nil)
        paletteWindow = nil
    }

    // MARK: Break reminders

    private func observeBreakReminders() {
        // The coordinator raises a flag; the shell decides how to show it.
        // Polled rather than observed so a missed publish cannot strand it.
        reminderPoll = Timer.scheduledTimer(withTimeInterval: 20, repeats: true) { [weak self] _ in
            guard let self, self.coordinator.breakReminderIsDue else { return }
            self.showBreakReminder()
        }
        reminderPoll?.tolerance = 5
    }

    private func showBreakReminder() {
        guard reminderWindow == nil else { return }
        let content = DaylightUI.breakReminder(
            message: coordinator.breakReminderMessage(),
            onSnooze: { [weak self] in
                self?.coordinator.snoozeBreakReminder()
                self?.dismissBreakReminderWindow()
            },
            onDismiss: { [weak self] in
                self?.coordinator.acknowledgeBreakReminder()
                self?.dismissBreakReminderWindow()
            })
        let panel = NSPanel(contentRect: NSRect(x: 0, y: 0, width: 300, height: 120),
                            styleMask: [.titled, .fullSizeContentView, .nonactivatingPanel],
                            backing: .buffered, defer: false)
        panel.contentViewController = NSHostingController(rootView: content)
        panel.titlebarAppearsTransparent = true
        panel.titleVisibility = .hidden
        panel.isFloatingPanel = true
        panel.level = .floating
        panel.isReleasedWhenClosed = false
        // Top-right, out of the way, and never stealing focus — a reminder
        // should not interrupt what someone is typing.
        if let screen = NSScreen.main {
            let f = screen.visibleFrame
            panel.setFrameOrigin(NSPoint(x: f.maxX - 320, y: f.maxY - 160))
        }
        reminderWindow = panel
        panel.orderFrontRegardless()

        // Goes away on its own if it is ignored. Being ignorable is the point.
        DispatchQueue.main.asyncAfter(deadline: .now() + 25) { [weak self] in
            guard let self, self.reminderWindow === panel else { return }
            self.coordinator.acknowledgeBreakReminder()
            self.dismissBreakReminderWindow()
        }
    }

    private func dismissBreakReminderWindow() {
        reminderWindow?.orderOut(nil)
        reminderWindow = nil
    }

    // MARK: Launch at login

    func setLaunchAtLogin(_ enabled: Bool) -> String? {
        do {
            if enabled { try SMAppService.mainApp.register() }
            else { try SMAppService.mainApp.unregister() }
            return nil
        } catch {
            return "macOS did not accept the change. You can set this in System Settings under General › Login Items."
        }
    }

    var launchAtLoginIsOn: Bool { SMAppService.mainApp.status == .enabled }
}
