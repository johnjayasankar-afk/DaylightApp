import Foundation

/// Optional prompts to look away from the screen for a moment.
///
/// Deliberately modest in what it claims and in what it does: no streaks, no
/// counters, no blocking the screen, and nothing that implies a health outcome.
/// A reminder you can ignore without being nagged is the whole design.
public struct BreakReminderSettings: Codable, Hashable, Sendable {
    public var isEnabled: Bool
    public var intervalMinutes: Double
    public var snoozeMinutes: Double
    /// Seconds from local midnight. A range that wraps past midnight is normal.
    public var quietStartSeconds: Int?
    public var quietEndSeconds: Int?
    /// Suppressed while a mode or rule that silences reminders is active.
    public var respectsSilencingModes: Bool

    public init(isEnabled: Bool = false,
                intervalMinutes: Double = 30,
                snoozeMinutes: Double = 10,
                quietStartSeconds: Int? = 22 * 3600,
                quietEndSeconds: Int? = 8 * 3600,
                respectsSilencingModes: Bool = true) {
        self.isEnabled = isEnabled
        self.intervalMinutes = intervalMinutes
        self.snoozeMinutes = snoozeMinutes
        self.quietStartSeconds = quietStartSeconds
        self.quietEndSeconds = quietEndSeconds
        self.respectsSilencingModes = respectsSilencingModes
    }

    enum CodingKeys: String, CodingKey {
        case isEnabled, intervalMinutes, snoozeMinutes
        case quietStartSeconds, quietEndSeconds, respectsSilencingModes
    }

    /// Hand-written so a settings file from before reminders existed still
    /// loads, with reminders simply off.
    public init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        isEnabled = (try? c.decodeIfPresent(Bool.self, forKey: .isEnabled)) .flatMap { $0 } ?? false
        intervalMinutes = (try? c.decodeIfPresent(Double.self, forKey: .intervalMinutes)) .flatMap { $0 } ?? 30
        snoozeMinutes = (try? c.decodeIfPresent(Double.self, forKey: .snoozeMinutes)) .flatMap { $0 } ?? 10
        quietStartSeconds = try? c.decodeIfPresent(Int.self, forKey: .quietStartSeconds)
        quietEndSeconds = try? c.decodeIfPresent(Int.self, forKey: .quietEndSeconds)
        respectsSilencingModes =
            (try? c.decodeIfPresent(Bool.self, forKey: .respectsSilencingModes)) .flatMap { $0 } ?? true
    }

    public static let intervalChoices: [Double] = [20, 30, 45, 60, 90]
    public static let snoozeChoices: [Double] = [5, 10, 15, 30]

    public mutating func validate() {
        intervalMinutes = min(max(intervalMinutes, 5), 240)
        snoozeMinutes = min(max(snoozeMinutes, 1), 120)
        if let s = quietStartSeconds { quietStartSeconds = min(max(s, 0), 86_399) }
        if let e = quietEndSeconds { quietEndSeconds = min(max(e, 0), 86_399) }
    }
}

public struct BreakReminderState: Equatable, Sendable {
    public var lastShownAt: Date?
    public var snoozedUntil: Date?
    public var startedAt: Date

    public init(startedAt: Date, lastShownAt: Date? = nil, snoozedUntil: Date? = nil) {
        self.startedAt = startedAt
        self.lastShownAt = lastShownAt
        self.snoozedUntil = snoozedUntil
    }
}

public enum BreakReminderScheduler {

    public static func isInQuietHours(secondsFromMidnight t: Int,
                                      settings: BreakReminderSettings) -> Bool {
        guard let start = settings.quietStartSeconds, let end = settings.quietEndSeconds else {
            return false
        }
        if start == end { return false }
        return start <= end ? (t >= start && t < end) : (t >= start || t < end)
    }

    /// When the next reminder is due, or nil if reminders are off, snoozed
    /// indefinitely, or otherwise not applicable.
    public static func nextDue(state: BreakReminderState,
                               settings: BreakReminderSettings) -> Date? {
        guard settings.isEnabled else { return nil }
        let base = state.lastShownAt ?? state.startedAt
        let due = base.addingTimeInterval(settings.intervalMinutes * 60)
        if let snoozed = state.snoozedUntil, snoozed > due { return snoozed }
        return due
    }

    /// Whether a reminder should appear right now.
    ///
    /// Quiet hours and silencing modes defer the reminder rather than skipping
    /// it: it appears once the quiet period ends, rather than the person
    /// silently losing a whole evening's worth.
    public static func shouldShow(state: BreakReminderState,
                                  settings: BreakReminderSettings,
                                  now: Date,
                                  secondsFromMidnight: Int,
                                  isSilencedByMode: Bool) -> Bool {
        guard settings.isEnabled else { return false }
        guard let due = nextDue(state: state, settings: settings), now >= due else { return false }
        if isInQuietHours(secondsFromMidnight: secondsFromMidnight, settings: settings) { return false }
        if settings.respectsSilencingModes && isSilencedByMode { return false }
        return true
    }

    /// Wording that suggests without instructing, and never implies a
    /// medical benefit.
    public static func message(for now: Date) -> String {
        [
            "A good moment to look away from the screen for a bit.",
            "Time to rest your eyes on something further away.",
            "Worth a short break if you can take one.",
            "A moment to stand up and look at something else.",
        ][abs(Int(now.timeIntervalSince1970 / 60)) % 4]
    }
}

// MARK: - Command palette

/// One thing the palette can do.
public struct Command: Identifiable, Hashable, Sendable {
    public var id: String
    public var title: String
    /// Extra words that should match this command, so "dark" finds "Wind Down".
    public var keywords: [String]
    public var subtitle: String?
    public var symbolName: String

    public init(id: String, title: String, keywords: [String] = [],
                subtitle: String? = nil, symbolName: String = "circle") {
        self.id = id; self.title = title; self.keywords = keywords
        self.subtitle = subtitle; self.symbolName = symbolName
    }
}

public enum CommandMatcher {

    /// Ranks commands for a query.
    ///
    /// Subsequence matching, so "wd" finds "Wind Down", with prefix and
    /// word-boundary matches ranked above scattered ones. An empty query
    /// returns everything in its original order, which is what makes the
    /// palette usable as a menu rather than only as a search box.
    public static func rank(_ commands: [Command], query: String) -> [Command] {
        let q = query.trimmingCharacters(in: .whitespaces).lowercased()
        guard !q.isEmpty else { return commands }
        return commands
            .compactMap { command -> (Command, Int)? in
                guard let score = score(command, q) else { return nil }
                return (command, score)
            }
            .sorted { a, b in
                if a.1 != b.1 { return a.1 > b.1 }
                return a.0.title < b.0.title
            }
            .map(\.0)
    }

    static func score(_ command: Command, _ query: String) -> Int? {
        let title = command.title.lowercased()
        if title == query { return 1000 }
        if title.hasPrefix(query) { return 800 }
        if title.contains(query) { return 600 }
        // Initials: "cw" -> "Colour Work".
        let initials = title.split(separator: " ").compactMap(\.first)
        if String(initials).hasPrefix(query) { return 500 }
        if command.keywords.contains(where: { $0.lowercased().hasPrefix(query) }) { return 400 }
        if command.keywords.contains(where: { $0.lowercased().contains(query) }) { return 300 }
        if isSubsequence(query, of: title) { return 200 }
        return nil
    }

    static func isSubsequence(_ needle: String, of haystack: String) -> Bool {
        var i = needle.startIndex
        for ch in haystack {
            if i == needle.endIndex { break }
            if ch == needle[i] { i = needle.index(after: i) }
        }
        return i == needle.endIndex
    }
}
