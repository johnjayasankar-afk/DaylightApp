import Foundation

/// Monotonic seconds. Transitions must never be driven by wall-clock time:
/// a clock correction, a time-zone change or a DST jump would otherwise make a
/// fade leap or stall. Wall clock decides *what* the target is; elapsed
/// time decides how we get there.
public func monotonicNow() -> Double {
    var ts = timespec()
    clock_gettime(CLOCK_MONOTONIC_RAW, &ts)
    return Double(ts.tv_sec) + Double(ts.tv_nsec) / 1_000_000_000
}

/// Smoothly carries the output from wherever it is to wherever it should be.
///
/// Retargeting mid-fade restarts from the *current interpolated value*, which
/// is what keeps changes from snapping when a rule fires or an override ends.
public struct TransitionEngine: Sendable {
    public private(set) var current: ResolvedTarget
    private var from: ResolvedTarget
    private var to: ResolvedTarget
    private var startedAt: Double
    private var duration: Double

    public init(initial: ResolvedTarget = .neutral, now: Double = monotonicNow()) {
        self.current = initial
        self.from = initial
        self.to = initial
        self.startedAt = now
        self.duration = 0
    }

    public var target: ResolvedTarget { to }

    public var isSettled: Bool {
        duration <= 0 || monotonicNow() - startedAt >= duration
    }

    /// Ease-in-out. Linear fades read as mechanical; a gentle curve reads as
    /// deliberate. Kept cheap — this runs on every tick.
    private static func ease(_ t: Double) -> Double {
        let t = min(max(t, 0), 1)
        return t < 0.5 ? 2 * t * t : 1 - pow(-2 * t + 2, 2) / 2
    }

    public mutating func advance(to now: Double) -> ResolvedTarget {
        guard duration > 0 else { current = to; return current }
        let raw = (now - startedAt) / duration
        if raw >= 1 {
            current = to
            duration = 0
        } else {
            current = .interpolate(from, to, Self.ease(raw))
        }
        return current
    }

    public mutating func retarget(_ newTarget: ResolvedTarget,
                                  duration newDuration: Double,
                                  now: Double = monotonicNow()) {
        _ = advance(to: now)
        guard newTarget != to || duration > 0 else { return }
        from = current
        to = newTarget
        startedAt = now
        duration = max(0, newDuration)
        if duration == 0 { current = newTarget }
    }

    /// Used by emergency restore: get to neutral with no ceremony.
    public mutating func snap(to newTarget: ResolvedTarget, now: Double = monotonicNow()) {
        from = newTarget; to = newTarget; current = newTarget
        startedAt = now; duration = 0
    }
}

// MARK: - Deciding how often to do anything

public enum TickPlanner {

    /// A change smaller than this is not worth a hardware write. One mired is
    /// below the threshold most people can see as a step.
    public static let miredStep: Double = 1.0
    /// Roughly one step in 8-bit output.
    public static let dimmingStep: Double = 1.0 / 255.0

    public static let minimumInterval: Double = 1.0 / 30.0
    public static let maximumInterval: Double = 60.0
    /// Safety net so a clock change, missed notification or resumed sleep can
    /// never leave the output stale for long. Four wakes an hour costs nothing.
    public static let idleHeartbeat: Double = 300.0

    /// Interval that keeps a fade visually smooth while doing the fewest
    /// possible writes: derived from how much the value actually changes, not
    /// from a fixed frame rate.
    public static func interval(from a: ResolvedTarget,
                                to b: ResolvedTarget,
                                duration: Double) -> Double {
        guard duration > 0 else { return minimumInterval }
        let miredDelta = abs(a.temperature.mired - b.temperature.mired)
        let dimDelta = abs(a.dimming.factor - b.dimming.factor)
        let steps = max(miredDelta / miredStep, dimDelta / dimmingStep)
        guard steps > 1 else { return min(duration, maximumInterval) }
        return min(max(duration / steps, minimumInterval), maximumInterval)
    }

    /// How long the coordinator may sleep when nothing is fading.
    public static func idleInterval(nextChangeAt: Date?, now: Date) -> Double {
        guard let next = nextChangeAt else { return idleHeartbeat }
        let delta = next.timeIntervalSince(now)
        if delta <= 0 { return minimumInterval }
        return min(delta, idleHeartbeat)
    }
}

// MARK: - Write suppression

/// Decides whether a computed value is worth sending to hardware.
///
/// Two jobs: don't send changes nobody can see, and don't exceed what a given
/// device can absorb. External devices are far slower than a gamma table, so
/// the limit is per-device rather than global.
public struct WritePolicy: Sendable {
    public var minimumIntervalSeconds: Double
    public var minimumGainDelta: Double

    public init(minimumIntervalSeconds: Double = 0, minimumGainDelta: Double = 0.0015) {
        self.minimumIntervalSeconds = minimumIntervalSeconds
        self.minimumGainDelta = minimumGainDelta
    }

    /// Gamma tables are cheap: a full table write is a single fast call.
    public static let gamma = WritePolicy(minimumIntervalSeconds: 0, minimumGainDelta: 0.0015)
    /// Placeholder for future external lights, which need far gentler pacing.
    public static let slowExternalDevice = WritePolicy(minimumIntervalSeconds: 1.0, minimumGainDelta: 0.01)

    public func shouldWrite(new: ChannelGains,
                            last: ChannelGains?,
                            lastWriteAt: Double?,
                            now: Double,
                            force: Bool = false) -> Bool {
        if force { return true }
        guard let last else { return true }
        if let lastWriteAt, now - lastWriteAt < minimumIntervalSeconds { return false }
        return new.maxDifference(from: last) >= minimumGainDelta
    }
}

// MARK: - Debounce

/// Coalesces a burst of values (a slider being dragged) into occasional
/// applications, while guaranteeing the final value always lands.
public final class Debouncer: @unchecked Sendable {
    private let interval: Double
    private var lastFire: Double = -.infinity
    private var pending: (() -> Void)?
    private let queue: DispatchQueue
    private var scheduled = false

    public init(interval: Double = 1.0 / 30.0, queue: DispatchQueue = .main) {
        self.interval = interval
        self.queue = queue
    }

    public func submit(_ work: @escaping () -> Void) {
        let now = monotonicNow()
        if now - lastFire >= interval && !scheduled {
            lastFire = now
            work()
            return
        }
        pending = work
        guard !scheduled else { return }
        scheduled = true
        let delay = max(0, interval - (now - lastFire))
        queue.asyncAfter(deadline: .now() + delay) { [weak self] in
            guard let self else { return }
            self.scheduled = false
            self.lastFire = monotonicNow()
            let w = self.pending
            self.pending = nil
            w?()
        }
    }
}
