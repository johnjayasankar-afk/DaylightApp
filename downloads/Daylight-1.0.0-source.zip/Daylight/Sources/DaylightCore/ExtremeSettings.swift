import Foundation

// MARK: - Extreme settings

/// Values low enough that the interface asks before saving them.
///
/// Not a nanny prompt: it fires only at genuinely awkward settings, it says
/// what will happen in plain language, and it can be turned off.
public enum ExtremeSettings {

    public struct Concern: Equatable {
        public var title: String
        public var detail: String
    }

    /// `restoreShortcut` is passed in rather than looked up: this type has no
    /// business knowing how the interface spells a key combination.
    public static func concern(temperature: ColourTemperature?,
                               dimming: SoftwareDimming?,
                               restoreShortcut: String = "the Restore command") -> Concern? {
        let veryWarm = (temperature?.kelvin ?? 6500) < ColourTemperature.legibilityWarningBelow
        let veryDim = (dimming?.factor ?? 1) < 0.35

        switch (veryWarm, veryDim) {
        case (true, true):
            return Concern(
                title: "That is very warm and very dim",
                detail: "At about \(kelvinText(temperature!)) and \(percentText(dimming!.factor)) brightness, text and images will be hard to make out. You can always restore normal output with \(restoreShortcut).")
        case (true, false):
            return Concern(
                title: "That is very warm",
                detail: "Below about \(Int(ColourTemperature.legibilityWarningBelow)) K, colours shift enough that text can be tiring to read and images will look strongly orange.")
        case (false, true):
            return Concern(
                title: "That is very dim",
                detail: "At \(percentText(dimming!.factor)) the screen may be hard to read in a lit room. This is software dimming, so it cannot go below what your backlight is already doing.")
        case (false, false):
            return nil
        }
    }
}

private func kelvinText(_ t: ColourTemperature) -> String {
    String(format: "%.0f K", (t.kelvin / 50).rounded() * 50)
}
private func percentText(_ v: Double) -> String {
    String(format: "%.0f%%", (v * 100).rounded())
}
