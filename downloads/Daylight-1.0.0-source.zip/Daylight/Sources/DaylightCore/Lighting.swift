import Foundation

// MARK: - Colour temperature
//
// Everything here produces an *approximate display target*. These are not
// measurements of emitted spectral power, and nothing in Daylight should
// present them as such.

/// Approximate correlated colour temperature, in kelvin.
///
/// Stored as kelvin because that is what people recognise, but all
/// interpolation happens in mireds (reciprocal megakelvin) because equal steps
/// in mired are far closer to equal *perceived* steps than equal steps in
/// kelvin. Going 2000 K -> 3000 K is a large visible change; 8000 K -> 9000 K
/// is nearly invisible, yet both are "1000 K".
public struct ColourTemperature: Hashable, Codable, Sendable, Comparable {
    public var kelvin: Double

    public init(kelvin: Double) { self.kelvin = kelvin }

    /// Mired = 1_000_000 / K. Lower mired = cooler/bluer, higher = warmer.
    public var mired: Double { 1_000_000.0 / kelvin }

    public init(mired: Double) { self.kelvin = 1_000_000.0 / mired }

    /// The neutral reference. At this value Daylight applies no colour shift at all.
    public static let neutral = ColourTemperature(kelvin: 6500)

    /// Conservative range offered by default. The advanced range may extend
    /// further, but only where the adapter reports it can do so safely.
    public static let normalRange: ClosedRange<Double> = 2700...6500
    public static let advancedRange: ClosedRange<Double> = 1900...6500

    /// Below this, text legibility degrades enough that Daylight asks for
    /// confirmation before saving the value.
    public static let legibilityWarningBelow: Double = 2400

    public static func < (a: ColourTemperature, b: ColourTemperature) -> Bool { a.kelvin < b.kelvin }

    /// Perceptually-even interpolation. `t` is clamped to 0...1.
    public static func interpolate(_ a: ColourTemperature, _ b: ColourTemperature, _ t: Double) -> ColourTemperature {
        let t = min(max(t, 0), 1)
        return ColourTemperature(mired: a.mired + (b.mired - a.mired) * t)
    }

    public func clamped(to range: ClosedRange<Double>) -> ColourTemperature {
        ColourTemperature(kelvin: min(max(kelvin, range.lowerBound), range.upperBound))
    }
}

// MARK: - Planckian locus

/// CCT -> CIE 1931 xy chromaticity, using Kim et al. (2002) cubic-spline
/// approximation of the Planckian locus. Valid 1667 K - 25000 K.
public func planckianChromaticity(kelvin T: Double) -> (x: Double, y: Double) {
    let t = min(max(T, 1667), 25000)
    let i = 1.0 / t, i2 = i * i, i3 = i2 * i
    let x: Double = t <= 4000
        ? (-0.2661239e9 * i3 - 0.2343589e6 * i2 + 0.8776956e3 * i + 0.179910)
        : (-3.0258469e9 * i3 + 2.1070379e6 * i2 + 0.2226347e3 * i + 0.240390)
    let x2 = x * x, x3 = x2 * x
    let y: Double
    if t <= 2222 {
        y = -1.1063814 * x3 - 1.34811020 * x2 + 2.18555832 * x - 0.20219683
    } else if t <= 4000 {
        y = -0.9549476 * x3 - 1.37418593 * x2 + 2.09137015 * x - 0.16748867
    } else {
        y =  3.0817580 * x3 - 5.87338670 * x2 + 3.75112997 * x - 0.37001483
    }
    return (x, y)
}

/// Per-channel linear gains that shift a display towards `temperature`,
/// normalised so that `ColourTemperature.neutral` yields exactly (1, 1, 1)
/// and no channel ever exceeds 1.
///
/// Gains are multiplicative and always <= 1, so applying them can only remove
/// light. That matters: it means Daylight can never push a channel past the
/// panel's white point and clip.
public struct ChannelGains: Equatable, Sendable {
    public var red: Double
    public var green: Double
    public var blue: Double

    public init(red: Double, green: Double, blue: Double) {
        self.red = red; self.green = green; self.blue = blue
    }

    public static let identity = ChannelGains(red: 1, green: 1, blue: 1)

    public func scaled(by factor: Double) -> ChannelGains {
        ChannelGains(red: red * factor, green: green * factor, blue: blue * factor)
    }

    /// Largest per-channel difference. Used to suppress hardware writes that
    /// would not produce a visible change.
    public func maxDifference(from other: ChannelGains) -> Double {
        max(abs(red - other.red), max(abs(green - other.green), abs(blue - other.blue)))
    }
}

public func channelGains(for temperature: ColourTemperature) -> ChannelGains {
    func linearRGB(_ T: Double) -> (Double, Double, Double) {
        let (x, y) = planckianChromaticity(kelvin: T)
        guard y > 1e-9 else { return (1, 1, 1) }
        let X = x / y, Y = 1.0, Z = (1 - x - y) / y
        // XYZ -> linear sRGB (D65)
        return ( 3.2404542 * X - 1.5371385 * Y - 0.4985314 * Z,
                -0.9692660 * X + 1.8760108 * Y + 0.0415560 * Z,
                 0.0556434 * X - 0.2040259 * Y + 1.0572252 * Z)
    }
    let (r, g, b)    = linearRGB(temperature.kelvin)
    let (rw, gw, bw) = linearRGB(ColourTemperature.neutral.kelvin)
    var v = [max(r / rw, 0), max(g / gw, 0), max(b / bw, 0)]
    if let m = v.max(), m > 0 { v = v.map { $0 / m } }
    return ChannelGains(red: v[0], green: v[1], blue: v[2])
}

// MARK: - Brightness

/// Software dimming: a multiplier applied to the display's transfer function.
///
/// This is *not* a backlight change. It reduces the values sent to the panel,
/// which looks dimmer but does not reduce backlight power, panel flicker, or
/// the display's minimum luminance. Daylight must always label it as such.
public struct SoftwareDimming: Hashable, Codable, Sendable {
    /// 1.0 = untouched. 0.3 = heavily dimmed.
    public var factor: Double
    public init(factor: Double) { self.factor = factor }
    public static let none = SoftwareDimming(factor: 1.0)

    /// Going much below this makes most content unreadable and can make the
    /// machine feel broken, so it is the floor Daylight offers.
    public static let safeFloor: Double = 0.20
    public static let range: ClosedRange<Double> = safeFloor...1.0

    public func clamped(to range: ClosedRange<Double> = SoftwareDimming.range) -> SoftwareDimming {
        SoftwareDimming(factor: min(max(factor, range.lowerBound), range.upperBound))
    }

    public static func interpolate(_ a: SoftwareDimming, _ b: SoftwareDimming, _ t: Double) -> SoftwareDimming {
        let t = min(max(t, 0), 1)
        return SoftwareDimming(factor: a.factor + (b.factor - a.factor) * t)
    }
}

/// Hardware brightness, where a display actually supports it.
///
/// Kept deliberately separate from `SoftwareDimming` in both the model and the
/// interface. They are different physical things and conflating them would be
/// a lie about what the app is doing.
public struct HardwareBrightness: Hashable, Codable, Sendable {
    public var level: Double  // 0...1
    public init(level: Double) { self.level = level }
    public func clamped() -> HardwareBrightness {
        HardwareBrightness(level: min(max(level, 0), 1))
    }
    public static func interpolate(_ a: HardwareBrightness, _ b: HardwareBrightness, _ t: Double) -> HardwareBrightness {
        let t = min(max(t, 0), 1)
        return HardwareBrightness(level: a.level + (b.level - a.level) * t)
    }
}

// MARK: - The value the engine produces

/// A complete description of what Daylight wants a display to look like.
///
/// Fields are optional so that a rule can speak about warmth without silently
/// discarding another rule's brightness decision. Resolution happens
/// per-control; see `PrecedenceResolver`.
public struct LightingTarget: Codable, Hashable, Sendable {
    public var temperature: ColourTemperature?
    public var dimming: SoftwareDimming?
    public var hardwareBrightness: HardwareBrightness?

    public init(temperature: ColourTemperature? = nil,
                dimming: SoftwareDimming? = nil,
                hardwareBrightness: HardwareBrightness? = nil) {
        self.temperature = temperature
        self.dimming = dimming
        self.hardwareBrightness = hardwareBrightness
    }

    /// Fully neutral output: what "restore normal output" means.
    public static let neutral = LightingTarget(
        temperature: .neutral, dimming: SoftwareDimming.none, hardwareBrightness: nil
    )

    public var isFullyNeutral: Bool {
        (temperature ?? .neutral).kelvin >= ColourTemperature.neutral.kelvin - 1
            && (dimming ?? .none).factor >= 0.999
    }
}

/// A resolved, non-optional target ready to hand to an adapter.
public struct ResolvedTarget: Codable, Hashable, Sendable {
    public var temperature: ColourTemperature
    public var dimming: SoftwareDimming
    public var hardwareBrightness: HardwareBrightness?

    public init(temperature: ColourTemperature,
                dimming: SoftwareDimming,
                hardwareBrightness: HardwareBrightness? = nil) {
        self.temperature = temperature
        self.dimming = dimming
        self.hardwareBrightness = hardwareBrightness
    }

    public static let neutral = ResolvedTarget(temperature: .neutral, dimming: .none)

    /// Combined gains actually sent to a gamma-based adapter.
    public var gains: ChannelGains {
        channelGains(for: temperature).scaled(by: dimming.factor)
    }

    public static func interpolate(_ a: ResolvedTarget, _ b: ResolvedTarget, _ t: Double) -> ResolvedTarget {
        ResolvedTarget(
            temperature: .interpolate(a.temperature, b.temperature, t),
            dimming: .interpolate(a.dimming, b.dimming, t),
            hardwareBrightness: {
                guard let x = a.hardwareBrightness, let y = b.hardwareBrightness else {
                    return b.hardwareBrightness ?? a.hardwareBrightness
                }
                return .interpolate(x, y, t)
            }()
        )
    }
}
