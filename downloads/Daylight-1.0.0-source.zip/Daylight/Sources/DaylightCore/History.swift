import Foundation

/// A record of something Daylight did.
///
/// Strictly a log of *software activity*. It says the schedule moved to a
/// warmer setting; it does not claim anything about the person reading it.
/// There are no scores, no streaks, and nothing is inferred.
public struct HistoryEntry: Identifiable, Codable, Hashable, Sendable {
    public enum Kind: String, Codable, Sendable, CaseIterable {
        case scheduleChange, modeApplied, manualChange, paused, resumed
        case restored, deviceProblem, conflict, displayChange, settingsChange

        public var symbolName: String {
            switch self {
            case .scheduleChange: return "calendar"
            case .modeApplied:    return "square.stack"
            case .manualChange:   return "hand.draw"
            case .paused:         return "pause.circle"
            case .resumed:        return "play.circle"
            case .restored:       return "arrow.counterclockwise"
            case .deviceProblem:  return "exclamationmark.triangle"
            case .conflict:       return "arrow.triangle.2.circlepath"
            case .displayChange:  return "display"
            case .settingsChange: return "gearshape"
            }
        }

        public var isProblem: Bool {
            self == .deviceProblem || self == .conflict
        }
    }

    public var id: UUID
    public var at: Date
    public var kind: Kind
    /// One plain sentence. This is what a person reads.
    public var summary: String
    /// Optional technical detail, shown only on request.
    public var detail: String?

    public init(id: UUID = UUID(), at: Date = Date(), kind: Kind,
                summary: String, detail: String? = nil) {
        self.id = id; self.at = at; self.kind = kind
        self.summary = summary; self.detail = detail
    }
}

public struct HistorySettings: Codable, Hashable, Sendable {
    /// Off until asked for. Nothing is written to disk while this is false.
    public var isEnabled: Bool
    public var retentionDays: Int

    public init(isEnabled: Bool = false, retentionDays: Int = 7) {
        self.isEnabled = isEnabled
        self.retentionDays = retentionDays
    }

    public static let retentionChoices = [1, 3, 7, 14, 30]

    public mutating func validate() {
        retentionDays = min(max(retentionDays, 1), 90)
    }
}

/// A bounded, local, plain-language log.
///
/// Kept in its own file so the settings document stays small, and capped by
/// both age and count so it can never grow without limit.
public final class HistoryLog: @unchecked Sendable {
    /// A hard ceiling regardless of the retention setting, so a busy day cannot
    /// produce an unbounded file.
    public static let maximumEntries = 2000

    private let fileURL: URL
    private let queue = DispatchQueue(label: "app.daylight.history")
    private var entries: [HistoryEntry] = []
    private var isDirty = false

    public init(directory: URL) {
        self.fileURL = directory.appendingPathComponent("history.json")
        load()
    }

    private func load() {
        guard let data = try? Data(contentsOf: fileURL) else { return }
        let decoder = JSONDecoder(); decoder.dateDecodingStrategy = .iso8601
        entries = (try? decoder.decode([HistoryEntry].self, from: data)) ?? []
    }

    public func all() -> [HistoryEntry] {
        queue.sync { entries.sorted { $0.at > $1.at } }
    }

    public var count: Int { queue.sync { entries.count } }

    /// Records an entry, unless the same thing was just recorded.
    ///
    /// Deduplication matters more than it sounds: a schedule ramp produces a
    /// new value every minute, and a log that says "warmth changed" sixty times
    /// an hour is not a log anyone will read.
    public func record(_ entry: HistoryEntry, settings: HistorySettings) {
        guard settings.isEnabled else { return }
        queue.sync {
            if let last = entries.last,
               last.kind == entry.kind,
               last.summary == entry.summary,
               entry.at.timeIntervalSince(last.at) < 60 {
                return
            }
            entries.append(entry)
            if entries.count > Self.maximumEntries {
                entries.removeFirst(entries.count - Self.maximumEntries)
            }
            isDirty = true
        }
    }

    public func prune(settings: HistorySettings, now: Date = Date()) {
        queue.sync {
            let cutoff = now.addingTimeInterval(-Double(settings.retentionDays) * 86_400)
            let before = entries.count
            entries.removeAll { $0.at < cutoff }
            if entries.count != before { isDirty = true }
        }
    }

    public func clear() {
        queue.sync {
            entries.removeAll()
            try? FileManager.default.removeItem(at: fileURL)
            isDirty = false
        }
    }

    /// Writes only if something changed, so an idle app does no disk work.
    public func flush() {
        queue.sync {
            guard isDirty else { return }
            let encoder = JSONEncoder()
            encoder.dateEncodingStrategy = .iso8601
            guard let data = try? encoder.encode(entries) else { return }
            try? FileManager.default.createDirectory(
                at: fileURL.deletingLastPathComponent(), withIntermediateDirectories: true)
            try? data.write(to: fileURL, options: .atomic)
            isDirty = false
        }
    }

    /// Turning history off removes what was already stored, rather than leaving
    /// a file behind that the interface no longer shows.
    public func disableAndErase() { clear() }
}
