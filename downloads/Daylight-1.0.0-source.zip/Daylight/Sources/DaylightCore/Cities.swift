import Foundation

/// A place you can pick instead of typing coordinates.
public struct City: Hashable, Sendable, Identifiable {
    public var id: String { "\(name),\(region)" }
    public var name: String
    public var region: String
    public var latitude: Double
    public var longitude: Double
    /// The IANA time zone this city sits in. Used to offer a starting
    /// suggestion, never to look anything up.
    public var timeZoneIdentifier: String

    public var label: String { "\(name), \(region)" }

    public var location: GeoLocation {
        GeoLocation(latitude: latitude, longitude: longitude, label: label,
                    timeZoneIdentifier: timeZoneIdentifier)
    }
}

/// A small bundled list of places, for setting a location without typing
/// coordinates and without asking for permission.
///
/// Deliberately offline and deliberately partial: it exists so that most people
/// can pick something close enough for sunrise and sunset, not so that every
/// settlement is represented. Anywhere not listed is still reachable by typing
/// coordinates, and being a few tens of kilometres out moves sunset by about a
/// minute — far below anything a lighting schedule cares about.
public enum Cities {

    public static let all: [City] = [
        // Europe
        City(name: "London", region: "United Kingdom", latitude: 51.5074, longitude: -0.1278, timeZoneIdentifier: "Europe/London"),
        City(name: "Manchester", region: "United Kingdom", latitude: 53.4808, longitude: -2.2426, timeZoneIdentifier: "Europe/London"),
        City(name: "Edinburgh", region: "United Kingdom", latitude: 55.9533, longitude: -3.1883, timeZoneIdentifier: "Europe/London"),
        City(name: "Dublin", region: "Ireland", latitude: 53.3498, longitude: -6.2603, timeZoneIdentifier: "Europe/Dublin"),
        City(name: "Paris", region: "France", latitude: 48.8566, longitude: 2.3522, timeZoneIdentifier: "Europe/Paris"),
        City(name: "Berlin", region: "Germany", latitude: 52.5200, longitude: 13.4050, timeZoneIdentifier: "Europe/Berlin"),
        City(name: "Munich", region: "Germany", latitude: 48.1351, longitude: 11.5820, timeZoneIdentifier: "Europe/Berlin"),
        City(name: "Amsterdam", region: "Netherlands", latitude: 52.3676, longitude: 4.9041, timeZoneIdentifier: "Europe/Amsterdam"),
        City(name: "Brussels", region: "Belgium", latitude: 50.8503, longitude: 4.3517, timeZoneIdentifier: "Europe/Brussels"),
        City(name: "Zurich", region: "Switzerland", latitude: 47.3769, longitude: 8.5417, timeZoneIdentifier: "Europe/Zurich"),
        City(name: "Vienna", region: "Austria", latitude: 48.2082, longitude: 16.3738, timeZoneIdentifier: "Europe/Vienna"),
        City(name: "Madrid", region: "Spain", latitude: 40.4168, longitude: -3.7038, timeZoneIdentifier: "Europe/Madrid"),
        City(name: "Barcelona", region: "Spain", latitude: 41.3874, longitude: 2.1686, timeZoneIdentifier: "Europe/Madrid"),
        City(name: "Lisbon", region: "Portugal", latitude: 38.7223, longitude: -9.1393, timeZoneIdentifier: "Europe/Lisbon"),
        City(name: "Rome", region: "Italy", latitude: 41.9028, longitude: 12.4964, timeZoneIdentifier: "Europe/Rome"),
        City(name: "Milan", region: "Italy", latitude: 45.4642, longitude: 9.1900, timeZoneIdentifier: "Europe/Rome"),
        City(name: "Copenhagen", region: "Denmark", latitude: 55.6761, longitude: 12.5683, timeZoneIdentifier: "Europe/Copenhagen"),
        City(name: "Stockholm", region: "Sweden", latitude: 59.3293, longitude: 18.0686, timeZoneIdentifier: "Europe/Stockholm"),
        City(name: "Oslo", region: "Norway", latitude: 59.9139, longitude: 10.7522, timeZoneIdentifier: "Europe/Oslo"),
        City(name: "Tromsø", region: "Norway", latitude: 69.6496, longitude: 18.9560, timeZoneIdentifier: "Europe/Oslo"),
        City(name: "Helsinki", region: "Finland", latitude: 60.1699, longitude: 24.9384, timeZoneIdentifier: "Europe/Helsinki"),
        City(name: "Reykjavík", region: "Iceland", latitude: 64.1466, longitude: -21.9426, timeZoneIdentifier: "Atlantic/Reykjavik"),
        City(name: "Warsaw", region: "Poland", latitude: 52.2297, longitude: 21.0122, timeZoneIdentifier: "Europe/Warsaw"),
        City(name: "Prague", region: "Czechia", latitude: 50.0755, longitude: 14.4378, timeZoneIdentifier: "Europe/Prague"),
        City(name: "Budapest", region: "Hungary", latitude: 47.4979, longitude: 19.0402, timeZoneIdentifier: "Europe/Budapest"),
        City(name: "Athens", region: "Greece", latitude: 37.9838, longitude: 23.7275, timeZoneIdentifier: "Europe/Athens"),
        City(name: "Bucharest", region: "Romania", latitude: 44.4268, longitude: 26.1025, timeZoneIdentifier: "Europe/Bucharest"),
        City(name: "Kyiv", region: "Ukraine", latitude: 50.4501, longitude: 30.5234, timeZoneIdentifier: "Europe/Kyiv"),
        City(name: "Istanbul", region: "Türkiye", latitude: 41.0082, longitude: 28.9784, timeZoneIdentifier: "Europe/Istanbul"),
        City(name: "Moscow", region: "Russia", latitude: 55.7558, longitude: 37.6173, timeZoneIdentifier: "Europe/Moscow"),

        // North America
        City(name: "New York", region: "United States", latitude: 40.7128, longitude: -74.0060, timeZoneIdentifier: "America/New_York"),
        City(name: "Boston", region: "United States", latitude: 42.3601, longitude: -71.0589, timeZoneIdentifier: "America/New_York"),
        City(name: "Washington", region: "United States", latitude: 38.9072, longitude: -77.0369, timeZoneIdentifier: "America/New_York"),
        City(name: "Atlanta", region: "United States", latitude: 33.7490, longitude: -84.3880, timeZoneIdentifier: "America/New_York"),
        City(name: "Miami", region: "United States", latitude: 25.7617, longitude: -80.1918, timeZoneIdentifier: "America/New_York"),
        City(name: "Toronto", region: "Canada", latitude: 43.6532, longitude: -79.3832, timeZoneIdentifier: "America/Toronto"),
        City(name: "Montréal", region: "Canada", latitude: 45.5017, longitude: -73.5673, timeZoneIdentifier: "America/Toronto"),
        City(name: "Chicago", region: "United States", latitude: 41.8781, longitude: -87.6298, timeZoneIdentifier: "America/Chicago"),
        City(name: "Austin", region: "United States", latitude: 30.2672, longitude: -97.7431, timeZoneIdentifier: "America/Chicago"),
        City(name: "Dallas", region: "United States", latitude: 32.7767, longitude: -96.7970, timeZoneIdentifier: "America/Chicago"),
        City(name: "Houston", region: "United States", latitude: 29.7604, longitude: -95.3698, timeZoneIdentifier: "America/Chicago"),
        City(name: "Minneapolis", region: "United States", latitude: 44.9778, longitude: -93.2650, timeZoneIdentifier: "America/Chicago"),
        City(name: "Mexico City", region: "Mexico", latitude: 19.4326, longitude: -99.1332, timeZoneIdentifier: "America/Mexico_City"),
        City(name: "Denver", region: "United States", latitude: 39.7392, longitude: -104.9903, timeZoneIdentifier: "America/Denver"),
        City(name: "Salt Lake City", region: "United States", latitude: 40.7608, longitude: -111.8910, timeZoneIdentifier: "America/Denver"),
        City(name: "Phoenix", region: "United States", latitude: 33.4484, longitude: -112.0740, timeZoneIdentifier: "America/Phoenix"),
        City(name: "Los Angeles", region: "United States", latitude: 34.0522, longitude: -118.2437, timeZoneIdentifier: "America/Los_Angeles"),
        City(name: "San Francisco", region: "United States", latitude: 37.7749, longitude: -122.4194, timeZoneIdentifier: "America/Los_Angeles"),
        City(name: "Seattle", region: "United States", latitude: 47.6062, longitude: -122.3321, timeZoneIdentifier: "America/Los_Angeles"),
        City(name: "Portland", region: "United States", latitude: 45.5152, longitude: -122.6784, timeZoneIdentifier: "America/Los_Angeles"),
        City(name: "San Diego", region: "United States", latitude: 32.7157, longitude: -117.1611, timeZoneIdentifier: "America/Los_Angeles"),
        City(name: "Vancouver", region: "Canada", latitude: 49.2827, longitude: -123.1207, timeZoneIdentifier: "America/Vancouver"),
        City(name: "Calgary", region: "Canada", latitude: 51.0447, longitude: -114.0719, timeZoneIdentifier: "America/Edmonton"),
        City(name: "Anchorage", region: "United States", latitude: 61.2181, longitude: -149.9003, timeZoneIdentifier: "America/Anchorage"),
        City(name: "Honolulu", region: "United States", latitude: 21.3069, longitude: -157.8583, timeZoneIdentifier: "Pacific/Honolulu"),

        // South America
        City(name: "São Paulo", region: "Brazil", latitude: -23.5505, longitude: -46.6333, timeZoneIdentifier: "America/Sao_Paulo"),
        City(name: "Rio de Janeiro", region: "Brazil", latitude: -22.9068, longitude: -43.1729, timeZoneIdentifier: "America/Sao_Paulo"),
        City(name: "Buenos Aires", region: "Argentina", latitude: -34.6037, longitude: -58.3816, timeZoneIdentifier: "America/Argentina/Buenos_Aires"),
        City(name: "Santiago", region: "Chile", latitude: -33.4489, longitude: -70.6693, timeZoneIdentifier: "America/Santiago"),
        City(name: "Lima", region: "Peru", latitude: -12.0464, longitude: -77.0428, timeZoneIdentifier: "America/Lima"),
        City(name: "Bogotá", region: "Colombia", latitude: 4.7110, longitude: -74.0721, timeZoneIdentifier: "America/Bogota"),

        // Africa and the Middle East
        City(name: "Lagos", region: "Nigeria", latitude: 6.5244, longitude: 3.3792, timeZoneIdentifier: "Africa/Lagos"),
        City(name: "Accra", region: "Ghana", latitude: 5.6037, longitude: -0.1870, timeZoneIdentifier: "Africa/Accra"),
        City(name: "Cairo", region: "Egypt", latitude: 30.0444, longitude: 31.2357, timeZoneIdentifier: "Africa/Cairo"),
        City(name: "Nairobi", region: "Kenya", latitude: -1.2921, longitude: 36.8219, timeZoneIdentifier: "Africa/Nairobi"),
        City(name: "Johannesburg", region: "South Africa", latitude: -26.2041, longitude: 28.0473, timeZoneIdentifier: "Africa/Johannesburg"),
        City(name: "Cape Town", region: "South Africa", latitude: -33.9249, longitude: 18.4241, timeZoneIdentifier: "Africa/Johannesburg"),
        City(name: "Casablanca", region: "Morocco", latitude: 33.5731, longitude: -7.5898, timeZoneIdentifier: "Africa/Casablanca"),
        City(name: "Dubai", region: "United Arab Emirates", latitude: 25.2048, longitude: 55.2708, timeZoneIdentifier: "Asia/Dubai"),
        City(name: "Tel Aviv", region: "Israel", latitude: 32.0853, longitude: 34.7818, timeZoneIdentifier: "Asia/Jerusalem"),
        City(name: "Riyadh", region: "Saudi Arabia", latitude: 24.7136, longitude: 46.6753, timeZoneIdentifier: "Asia/Riyadh"),
        City(name: "Doha", region: "Qatar", latitude: 25.2854, longitude: 51.5310, timeZoneIdentifier: "Asia/Qatar"),

        // Asia
        City(name: "Mumbai", region: "India", latitude: 19.0760, longitude: 72.8777, timeZoneIdentifier: "Asia/Kolkata"),
        City(name: "Delhi", region: "India", latitude: 28.6139, longitude: 77.2090, timeZoneIdentifier: "Asia/Kolkata"),
        City(name: "Bengaluru", region: "India", latitude: 12.9716, longitude: 77.5946, timeZoneIdentifier: "Asia/Kolkata"),
        City(name: "Chennai", region: "India", latitude: 13.0827, longitude: 80.2707, timeZoneIdentifier: "Asia/Kolkata"),
        City(name: "Hyderabad", region: "India", latitude: 17.3850, longitude: 78.4867, timeZoneIdentifier: "Asia/Kolkata"),
        City(name: "Kolkata", region: "India", latitude: 22.5726, longitude: 88.3639, timeZoneIdentifier: "Asia/Kolkata"),
        City(name: "Karachi", region: "Pakistan", latitude: 24.8607, longitude: 67.0011, timeZoneIdentifier: "Asia/Karachi"),
        City(name: "Dhaka", region: "Bangladesh", latitude: 23.8103, longitude: 90.4125, timeZoneIdentifier: "Asia/Dhaka"),
        City(name: "Bangkok", region: "Thailand", latitude: 13.7563, longitude: 100.5018, timeZoneIdentifier: "Asia/Bangkok"),
        City(name: "Singapore", region: "Singapore", latitude: 1.3521, longitude: 103.8198, timeZoneIdentifier: "Asia/Singapore"),
        City(name: "Kuala Lumpur", region: "Malaysia", latitude: 3.1390, longitude: 101.6869, timeZoneIdentifier: "Asia/Kuala_Lumpur"),
        City(name: "Jakarta", region: "Indonesia", latitude: -6.2088, longitude: 106.8456, timeZoneIdentifier: "Asia/Jakarta"),
        City(name: "Manila", region: "Philippines", latitude: 14.5995, longitude: 120.9842, timeZoneIdentifier: "Asia/Manila"),
        City(name: "Ho Chi Minh City", region: "Vietnam", latitude: 10.8231, longitude: 106.6297, timeZoneIdentifier: "Asia/Ho_Chi_Minh"),
        City(name: "Hong Kong", region: "Hong Kong", latitude: 22.3193, longitude: 114.1694, timeZoneIdentifier: "Asia/Hong_Kong"),
        City(name: "Shanghai", region: "China", latitude: 31.2304, longitude: 121.4737, timeZoneIdentifier: "Asia/Shanghai"),
        City(name: "Beijing", region: "China", latitude: 39.9042, longitude: 116.4074, timeZoneIdentifier: "Asia/Shanghai"),
        City(name: "Shenzhen", region: "China", latitude: 22.5431, longitude: 114.0579, timeZoneIdentifier: "Asia/Shanghai"),
        City(name: "Taipei", region: "Taiwan", latitude: 25.0330, longitude: 121.5654, timeZoneIdentifier: "Asia/Taipei"),
        City(name: "Seoul", region: "South Korea", latitude: 37.5665, longitude: 126.9780, timeZoneIdentifier: "Asia/Seoul"),
        City(name: "Tokyo", region: "Japan", latitude: 35.6762, longitude: 139.6503, timeZoneIdentifier: "Asia/Tokyo"),
        City(name: "Osaka", region: "Japan", latitude: 34.6937, longitude: 135.5023, timeZoneIdentifier: "Asia/Tokyo"),

        // Oceania
        City(name: "Sydney", region: "Australia", latitude: -33.8688, longitude: 151.2093, timeZoneIdentifier: "Australia/Sydney"),
        City(name: "Melbourne", region: "Australia", latitude: -37.8136, longitude: 144.9631, timeZoneIdentifier: "Australia/Melbourne"),
        City(name: "Brisbane", region: "Australia", latitude: -27.4698, longitude: 153.0251, timeZoneIdentifier: "Australia/Brisbane"),
        City(name: "Perth", region: "Australia", latitude: -31.9505, longitude: 115.8605, timeZoneIdentifier: "Australia/Perth"),
        City(name: "Adelaide", region: "Australia", latitude: -34.9285, longitude: 138.6007, timeZoneIdentifier: "Australia/Adelaide"),
        City(name: "Auckland", region: "New Zealand", latitude: -36.8485, longitude: 174.7633, timeZoneIdentifier: "Pacific/Auckland"),
        City(name: "Wellington", region: "New Zealand", latitude: -41.2866, longitude: 174.7756, timeZoneIdentifier: "Pacific/Auckland"),
    ]

    /// Normalises a string for searching.
    ///
    /// Unicode folding strips diacritics, but several letters are not "a letter
    /// plus a mark" and survive it: ø, æ, ß, ð and friends are distinct
    /// letters. Someone typing "tromso" still expects to find Tromsø, so those
    /// are mapped by hand before folding.
    public static func normalise(_ s: String) -> String {
        var out = s
        let substitutions: [(String, String)] = [
            ("ø", "o"), ("Ø", "o"), ("æ", "ae"), ("Æ", "ae"),
            ("å", "a"), ("Å", "a"), ("ß", "ss"),
            ("ð", "d"), ("Ð", "d"), ("þ", "th"), ("Þ", "th"),
            ("ł", "l"), ("Ł", "l"), ("đ", "d"), ("Đ", "d"),
        ]
        for (from, to) in substitutions { out = out.replacingOccurrences(of: from, with: to) }
        return out.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: .current)
    }

    /// Case- and accent-insensitive search over name and region.
    public static func search(_ query: String, limit: Int = 20) -> [City] {
        let q = normalise(query).trimmingCharacters(in: .whitespaces)
        guard !q.isEmpty else { return Array(all.prefix(limit)) }

        func fold(_ s: String) -> String { normalise(s) }
        return all
            .compactMap { city -> (City, Int)? in
                let name = fold(city.name), region = fold(city.region)
                if name.hasPrefix(q) { return (city, 3) }
                if region.hasPrefix(q) { return (city, 2) }
                if name.contains(q) || region.contains(q) { return (city, 1) }
                return nil
            }
            .sorted { a, b in
                if a.1 != b.1 { return a.1 > b.1 }
                return a.0.name < b.0.name
            }
            .prefix(limit)
            .map(\.0)
    }

    /// A starting suggestion drawn from the system time zone.
    ///
    /// This asks macOS nothing about location — a time zone is a setting, not a
    /// position — so it needs no permission. It is a guess offered for
    /// confirmation, never applied silently, and is exact only for someone in
    /// the city that names their zone.
    public static func suggestion(forTimeZone identifier: String = TimeZone.current.identifier) -> City? {
        if let exact = all.first(where: { $0.timeZoneIdentifier == identifier }) { return exact }
        // Fall back to the region: "Europe/Ljubljana" is at least European.
        guard let region = identifier.split(separator: "/").first else { return nil }
        return all.first { $0.timeZoneIdentifier.hasPrefix(region + "/") }
    }
}
