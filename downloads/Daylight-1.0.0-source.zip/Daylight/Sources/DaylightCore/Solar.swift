import Foundation

/// A place, entered manually or (only with permission) supplied by the system.
/// Daylight never requires this; every schedule type has a clock-time fallback.
public struct GeoLocation: Hashable, Codable, Sendable {
    public var latitude: Double
    public var longitude: Double
    public var label: String
    /// The time zone this place actually sits in, when it is known.
    ///
    /// Recorded so the interface can notice the common mistake of picking a
    /// city in a different zone from the Mac's own — which makes sunrise show
    /// up at an hour that looks like a bug but is not.
    public var timeZoneIdentifier: String?

    public init(latitude: Double, longitude: Double, label: String,
                timeZoneIdentifier: String? = nil) {
        self.latitude = latitude
        self.longitude = longitude
        self.label = label
        self.timeZoneIdentifier = timeZoneIdentifier
    }

    public var isValid: Bool {
        latitude >= -90 && latitude <= 90 && longitude >= -180 && longitude <= 180
    }

    enum CodingKeys: String, CodingKey { case latitude, longitude, label, timeZoneIdentifier }

    /// Hand-written so a settings file written before `timeZoneIdentifier`
    /// existed still yields a location rather than silently losing it.
    public init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        latitude = try c.decode(Double.self, forKey: .latitude)
        longitude = try c.decode(Double.self, forKey: .longitude)
        label = (try? c.decodeIfPresent(String.self, forKey: .label)) .flatMap { $0 } ?? "My location"
        timeZoneIdentifier = try? c.decodeIfPresent(String.self, forKey: .timeZoneIdentifier)
    }

    /// True when this place keeps a different clock from the Mac, which is
    /// almost always either travel or a mistake.
    public func disagreesWithSystemClock(_ system: TimeZone = .current) -> Bool {
        guard let identifier = timeZoneIdentifier, let zone = TimeZone(identifier: identifier)
        else { return false }
        return zone.secondsFromGMT(for: Date()) != system.secondsFromGMT(for: Date())
    }
}

/// The outcome of asking for a solar event on a given day.
///
/// Sunrise and sunset genuinely do not exist on some days at high latitudes.
/// Modelling that as an enum rather than an optional forces every caller to
/// decide what to do, instead of silently defaulting to midnight.
public enum SolarEventResult: Equatable, Sendable {
    case occurs(secondsFromLocalMidnight: Double)
    /// The sun stays up for the whole day.
    case polarDay
    /// The sun never rises.
    case polarNight

    public var seconds: Double? {
        if case .occurs(let s) = self { return s }
        return nil
    }
}

public enum SolarEvent: String, Codable, Sendable, CaseIterable {
    case sunrise, sunset
    case civilDawn, civilDusk

    /// Solar elevation angle used for the calculation.
    var zenithDegrees: Double {
        switch self {
        case .sunrise, .sunset: return 90.833   // includes refraction + solar radius
        case .civilDawn, .civilDusk: return 96.0
        }
    }
    public var isMorning: Bool {
        switch self {
        case .sunrise, .civilDawn: return true
        case .sunset, .civilDusk: return false
        }
    }
}

/// Local sunrise/sunset computation (NOAA solar position algorithm).
///
/// Runs entirely offline. Accurate to roughly a minute for ordinary latitudes,
/// which is far finer than anything a lighting schedule needs.
public enum SolarCalculator {

    /// Days since 2000-01-01 12:00 UTC for the *local* civil date, so that a
    /// "day" means the user's day rather than a UTC day.
    private static func julianDay(year: Int, month: Int, day: Int) -> Double {
        var y = year, m = month
        if m <= 2 { y -= 1; m += 12 }
        let a = Int(floor(Double(y) / 100.0))
        let b = 2 - a + Int(floor(Double(a) / 4.0))
        return floor(365.25 * Double(y + 4716))
             + floor(30.6001 * Double(m + 1))
             + Double(day) + Double(b) - 1524.5
    }

    /// Returns the event time expressed as seconds from local midnight of the
    /// given civil date, in the given time zone.
    public static func event(
        _ event: SolarEvent,
        date: Date,
        location: GeoLocation,
        timeZone: TimeZone
    ) -> SolarEventResult {
        guard location.isValid else { return .polarNight }

        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = timeZone
        let c = cal.dateComponents([.year, .month, .day], from: date)
        guard let y = c.year, let mo = c.month, let d = c.day else { return .polarNight }

        let jd = julianDay(year: y, month: mo, day: d)
        // Fractional day offset so the iteration starts near the event.
        let t0 = (jd - 2451545.0) / 36525.0

        func solve(_ tCentury: Double) -> (declination: Double, eqTimeMinutes: Double) {
            let t = tCentury
            let geomMeanLong = fmod(280.46646 + t * (36000.76983 + t * 0.0003032), 360.0)
            let geomMeanAnom = 357.52911 + t * (35999.05029 - 0.0001537 * t)
            let eccent = 0.016708634 - t * (0.000042037 + 0.0000001267 * t)
            let mRad = geomMeanAnom * .pi / 180
            let sunEqCtr = sin(mRad) * (1.914602 - t * (0.004817 + 0.000014 * t))
                         + sin(2 * mRad) * (0.019993 - 0.000101 * t)
                         + sin(3 * mRad) * 0.000289
            let sunTrueLong = geomMeanLong + sunEqCtr
            let omega = 125.04 - 1934.136 * t
            let appLong = sunTrueLong - 0.00569 - 0.00478 * sin(omega * .pi / 180)
            let seconds = 21.448 - t * (46.8150 + t * (0.00059 - t * 0.001813))
            let meanObliq = 23.0 + (26.0 + seconds / 60.0) / 60.0
            let obliqCorr = meanObliq + 0.00256 * cos(omega * .pi / 180)
            let declination = asin(sin(obliqCorr * .pi / 180) * sin(appLong * .pi / 180)) * 180 / .pi

            let vy = pow(tan(obliqCorr * .pi / 360), 2)
            let l0 = geomMeanLong * .pi / 180
            let eqTime = 4.0 * (vy * sin(2 * l0)
                        - 2.0 * eccent * sin(mRad)
                        + 4.0 * eccent * vy * sin(mRad) * cos(2 * l0)
                        - 0.5 * vy * vy * sin(4 * l0)
                        - 1.25 * eccent * eccent * sin(2 * mRad)) * 180 / .pi
            return (declination, eqTime)
        }

        // Two passes: solve at solar noon, then refine at the estimated event.
        var (decl, eqTime) = solve(t0)
        var hourAngle: Double = .nan

        for _ in 0..<2 {
            let latRad = location.latitude * .pi / 180
            let declRad = decl * .pi / 180
            let cosH = (cos(event.zenithDegrees * .pi / 180) - sin(latRad) * sin(declRad))
                     / (cos(latRad) * cos(declRad))
            if cosH > 1 { return .polarNight }   // sun never reaches the angle
            if cosH < -1 { return .polarDay }    // sun never drops to the angle
            hourAngle = acos(cosH) * 180 / .pi
            let signed = event.isMorning ? hourAngle : -hourAngle
            let minutesUTC = 720 - 4 * (location.longitude + signed) - eqTime
            let refined = t0 + (minutesUTC / 1440.0) / 36525.0
            (decl, eqTime) = solve(refined)
        }
        guard hourAngle.isFinite else { return .polarNight }

        let signed = event.isMorning ? hourAngle : -hourAngle
        let minutesUTC = 720 - 4 * (location.longitude + signed) - eqTime

        // Convert UTC minutes-of-day to local seconds-from-midnight using the
        // offset actually in effect on that date (so DST is handled by the OS
        // time zone database rather than by us guessing).
        guard let localMidnight = cal.date(from: DateComponents(year: y, month: mo, day: d)) else {
            return .polarNight
        }
        let offset = Double(timeZone.secondsFromGMT(for: localMidnight))
        var seconds = minutesUTC * 60 + offset
        // Normalise into the day; solar events can land just outside due to
        // longitude/time-zone mismatch (e.g. far-west China).
        while seconds < 0 { seconds += 86_400 }
        while seconds >= 86_400 { seconds -= 86_400 }
        return .occurs(secondsFromLocalMidnight: seconds)
    }
}
