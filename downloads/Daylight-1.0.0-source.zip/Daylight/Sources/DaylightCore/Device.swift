import Foundation

// MARK: - Identity

/// A display's durable identity.
///
/// Never an index. Display indices are reassigned freely when monitors are
/// docked, rearranged or woken, and keying settings on one is how an app ends
/// up applying a saved 2400 K night profile to a colleague's projector.
public struct DisplayIdentity: Hashable, Sendable, Codable {
    public var key: String
    public var uuid: String?
    public var vendor: UInt32
    public var model: UInt32
    public var serial: UInt32
    public var isBuiltIn: Bool
    /// True when this display cannot be told apart from another connected one
    /// (identical model, no serial). Surfaced rather than hidden.
    public var isAmbiguous: Bool

    public init(key: String, uuid: String? = nil, vendor: UInt32 = 0, model: UInt32 = 0,
                serial: UInt32 = 0, isBuiltIn: Bool = false, isAmbiguous: Bool = false) {
        self.key = key; self.uuid = uuid; self.vendor = vendor; self.model = model
        self.serial = serial; self.isBuiltIn = isBuiltIn; self.isAmbiguous = isAmbiguous
    }

    /// Prefers the system's persistent UUID, falling back to EDID-derived
    /// numbers. Both survive reboots; the UUID also survives a display moving
    /// to a different port.
    public static func makeKey(uuid: String?, vendor: UInt32, model: UInt32,
                               serial: UInt32, isBuiltIn: Bool) -> String {
        if let uuid, !uuid.isEmpty { return "uuid:\(uuid)" }
        if vendor != 0 || model != 0 || serial != 0 {
            return String(format: "edid:%08x-%08x-%08x", vendor, model, serial)
        }
        return isBuiltIn ? "builtin" : "unknown"
    }
}

// MARK: - Capabilities

public struct DisplayCapabilities: Hashable, Sendable {
    public var supportsColourTransform: Bool
    public var transferTableCapacity: Int
    public var supportsSoftwareDimming: Bool
    /// Real backlight control. Distinct from software dimming, and false
    /// unless an adapter has actually demonstrated it.
    public var supportsHardwareBrightness: Bool
    public var isHDRCapable: Bool
    /// Plain-language limitations to show in the Displays view.
    public var notes: [String]

    public init(supportsColourTransform: Bool = false,
                transferTableCapacity: Int = 0,
                supportsSoftwareDimming: Bool = false,
                supportsHardwareBrightness: Bool = false,
                isHDRCapable: Bool = false,
                notes: [String] = []) {
        self.supportsColourTransform = supportsColourTransform
        self.transferTableCapacity = transferTableCapacity
        self.supportsSoftwareDimming = supportsSoftwareDimming
        self.supportsHardwareBrightness = supportsHardwareBrightness
        self.isHDRCapable = isHDRCapable
        self.notes = notes
    }
}

// MARK: - How sure are we?

/// How strongly a reported state is actually supported by evidence.
///
/// Kept explicit because "the API returned success" and "the picture changed"
/// are genuinely different claims, and conflating them is how a lighting app
/// ends up lying to its user.
public enum ApplicationConfidence: Int, Sendable, Comparable, Codable {
    /// We computed a value and asked for it.
    case requested = 0
    /// The system accepted the call without error.
    case acceptedBySystem = 1
    /// We read the state back and it matches what we asked for.
    case readbackConfirmed = 2

    public static func < (a: Self, b: Self) -> Bool { a.rawValue < b.rawValue }

    public var shortLabel: String {
        switch self {
        case .requested:         return "Requested"
        case .acceptedBySystem:  return "Accepted"
        case .readbackConfirmed: return "Confirmed by readback"
        }
    }
}

public struct AppliedResult: Sendable, Equatable {
    public var confidence: ApplicationConfidence
    public var requested: ChannelGains
    public var readback: ChannelGains?
    public var deviation: Double?
    /// Set when readback shows a value we did not write, which means something
    /// else is driving this display.
    public var foreignChangeDetected: Bool

    public init(confidence: ApplicationConfidence, requested: ChannelGains,
                readback: ChannelGains? = nil, deviation: Double? = nil,
                foreignChangeDetected: Bool = false) {
        self.confidence = confidence; self.requested = requested
        self.readback = readback; self.deviation = deviation
        self.foreignChangeDetected = foreignChangeDetected
    }
}

public enum ConnectionState: String, Sendable, Codable {
    case connected, disconnected, asleep

    public var displayName: String {
        switch self {
        case .connected: return "Connected"
        case .disconnected: return "Not connected"
        case .asleep: return "Asleep"
        }
    }
}

public enum DeviceError: Error, LocalizedError, Equatable {
    case notConnected
    case unsupportedControl(String)
    case writeFailed(code: Int32)
    case readbackUnavailable
    case timedOut

    public var errorDescription: String? {
        switch self {
        case .notConnected:            return "The display is not connected."
        case .unsupportedControl(let c): return "This display does not support \(c)."
        case .writeFailed(let c):      return "The system refused the change (code \(c))."
        case .readbackUnavailable:     return "This display cannot report its current state."
        case .timedOut:                return "The display did not respond in time."
        }
    }
}

// MARK: - The adapter seam

/// One physical output Daylight can drive.
///
/// Implemented once for real CoreGraphics displays and once as a controllable
/// fake, so every failure mode below can be exercised in tests without
/// needing the hardware that produces it.
public protocol LightingDevice: AnyObject {
    var identity: DisplayIdentity { get }
    var displayName: String { get }
    var capabilities: DisplayCapabilities { get }
    var connectionState: ConnectionState { get }

    /// Establish a baseline and take ownership. Must be safe to call again
    /// after a reconnect.
    func prepare() throws

    func apply(_ target: ResolvedTarget) throws -> AppliedResult

    /// Remove Daylight's adjustments, leaving unrelated settings alone.
    func restore() throws

    /// Current output as gains, if the device can report it.
    func readback() -> ChannelGains?
}

// MARK: - Baseline and ownership

public enum BaselineSource: String, Sendable, Codable {
    /// Read from the display's colour profile — the correct baseline.
    case colourProfile
    /// A plain linear ramp, used when the profile could not be trusted.
    case identityFallback
    /// The captured table looked like another app's transform, so we refused
    /// to adopt it. Recorded so the interface can explain the situation.
    case rejectedForeignTransform
}

/// Checks whether a captured transfer table is plausible as a *neutral*
/// baseline, so Daylight never bakes another utility's warm transform into its
/// own idea of "normal".
public enum BaselineValidator {

    /// A genuine display profile keeps the three channels close together at
    /// full scale. f.lux at a warm setting, for example, reads back around
    /// R 1.00 / G 0.36 / B 0.10 — obviously not a neutral baseline.
    public static let maxNeutralChannelSpread: Double = 0.12

    public static func looksNeutral(red: [Float], green: [Float], blue: [Float]) -> Bool {
        guard let r = red.last, let g = green.last, let b = blue.last else { return false }
        let hi = Double(max(r, max(g, b))), lo = Double(min(r, min(g, b)))
        guard hi > 0.5 else { return false }   // a very dark ramp is not a baseline either
        return (hi - lo) <= maxNeutralChannelSpread
    }

    public static func isMonotonic(_ v: [Float]) -> Bool {
        guard v.count > 1 else { return false }
        for i in 1..<v.count where v[i] < v[i - 1] - 1e-4 { return false }
        return true
    }

    public static func isPlausibleBaseline(red: [Float], green: [Float], blue: [Float]) -> Bool {
        looksNeutral(red: red, green: green, blue: blue)
            && isMonotonic(red) && isMonotonic(green) && isMonotonic(blue)
    }
}

// MARK: - Controllable fake device

/// A fake display for tests and for running the app with no hardware risk.
///
/// Everything the real adapter can do wrong, this can do on demand: refuse
/// writes, time out, disconnect mid-write, report unsupported controls, or
/// accept a write and then lie about it on readback.
public final class SimulatedDisplayDevice: LightingDevice, @unchecked Sendable {
    public struct Faults: Sendable {
        public var failWrites = false
        public var timeOut = false
        public var disconnected = false
        /// Online but asleep — writable, unlike a disconnected display.
        public var asleep = false
        public var readbackUnavailable = false
        /// Accepts the call, but readback shows something else — the
        /// "successful API call with unverifiable output" case.
        public var readbackDisagrees = false
        /// Simulates another application overwriting our value.
        public var foreignOverwrite: ChannelGains?
        public var minimumWriteInterval: Double = 0
        public init() {}
    }

    public let identity: DisplayIdentity
    public var displayName: String
    public var capabilities: DisplayCapabilities
    public var faults = Faults()
    public private(set) var appliedGains: ChannelGains?
    public private(set) var writeCount = 0
    public private(set) var isPrepared = false
    public private(set) var restoreCount = 0
    private var lastWriteAt: Double?

    public var connectionState: ConnectionState {
        if faults.disconnected { return .disconnected }
        return faults.asleep ? .asleep : .connected
    }

    public init(key: String = "sim:1",
                displayName: String = "Simulated Display",
                isBuiltIn: Bool = false,
                capabilities: DisplayCapabilities = DisplayCapabilities(
                    supportsColourTransform: true,
                    transferTableCapacity: 1024,
                    supportsSoftwareDimming: true,
                    supportsHardwareBrightness: false,
                    notes: ["Simulated device. Nothing on screen actually changes."])) {
        self.identity = DisplayIdentity(key: key, isBuiltIn: isBuiltIn)
        self.displayName = displayName
        self.capabilities = capabilities
    }

    public func prepare() throws {
        if faults.disconnected { throw DeviceError.notConnected }
        isPrepared = true
    }

    public func apply(_ target: ResolvedTarget) throws -> AppliedResult {
        if faults.disconnected { throw DeviceError.notConnected }
        if faults.timeOut { throw DeviceError.timedOut }
        if faults.failWrites { throw DeviceError.writeFailed(code: -1) }
        let now = monotonicNow()
        if let last = lastWriteAt, now - last < faults.minimumWriteInterval {
            throw DeviceError.timedOut
        }
        let gains = target.gains
        appliedGains = gains
        writeCount += 1
        lastWriteAt = now

        if faults.readbackUnavailable {
            return AppliedResult(confidence: .acceptedBySystem, requested: gains)
        }
        var observed = gains
        if faults.readbackDisagrees { observed = gains.scaled(by: 0.5) }
        if let foreign = faults.foreignOverwrite { observed = foreign }
        let deviation = observed.maxDifference(from: gains)
        return AppliedResult(
            confidence: deviation < 0.001 ? .readbackConfirmed : .acceptedBySystem,
            requested: gains, readback: observed, deviation: deviation,
            foreignChangeDetected: deviation >= 0.01)
    }

    public func restore() throws {
        if faults.disconnected { throw DeviceError.notConnected }
        appliedGains = nil
        restoreCount += 1
    }

    public func readback() -> ChannelGains? {
        if faults.readbackUnavailable || faults.disconnected { return nil }
        if let foreign = faults.foreignOverwrite { return foreign }
        return appliedGains ?? .identity
    }
}
