import Foundation

// MARK: - Precedence

/// The fixed precedence ladder. Higher raw value wins.
///
/// Deliberately a small closed enum rather than user-assignable integers: a
/// rules system people can actually predict beats one they can fully rewire.
/// The order is shown in advanced settings so it is never a mystery.
public enum ControlLayer: Int, Comparable, Sendable, CaseIterable, Codable {
    case baseSchedule     = 0
    case workspaceProfile = 1
    case activityRule     = 2
    case manualOverride   = 3
    case userPause        = 4
    case emergencyRestore = 5

    public static func < (a: ControlLayer, b: ControlLayer) -> Bool { a.rawValue < b.rawValue }

    public var displayName: String {
        switch self {
        case .baseSchedule:     return "Schedule"
        case .workspaceProfile: return "Workspace"
        case .activityRule:     return "App rule"
        case .manualOverride:   return "Manual override"
        case .userPause:        return "Paused"
        case .emergencyRestore: return "Restored"
        }
    }
}

public struct LayerProposal: Equatable, Sendable {
    public var layer: ControlLayer
    /// What to call this in the interface, e.g. "Reading" or "Weekday schedule".
    public var label: String
    public var target: LightingTarget

    public init(layer: ControlLayer, label: String, target: LightingTarget) {
        self.layer = layer; self.label = label; self.target = target
    }
}

public struct ControlAttribution: Equatable, Sendable {
    public var layer: ControlLayer
    public var label: String
}

public struct ResolutionOutcome: Equatable, Sendable {
    public var target: ResolvedTarget
    public var temperatureFrom: ControlAttribution
    public var dimmingFrom: ControlAttribution
    /// The highest layer that contributed anything — what the UI calls "active".
    public var dominant: ControlAttribution
    public var explanation: String
}

public enum PrecedenceResolver {

    /// Resolve per-control, so a rule that only speaks about brightness does
    /// not silently throw away another rule's warmth decision.
    public static func resolve(_ proposals: [LayerProposal]) -> ResolutionOutcome {
        let ordered = proposals.sorted { $0.layer > $1.layer }
        let fallback = ControlAttribution(layer: .baseSchedule, label: "Neutral")

        var temperature: ColourTemperature?
        var temperatureFrom = fallback
        var dimming: SoftwareDimming?
        var dimmingFrom = fallback
        var hardware: HardwareBrightness?

        for p in ordered {
            if temperature == nil, let t = p.target.temperature {
                temperature = t
                temperatureFrom = ControlAttribution(layer: p.layer, label: p.label)
            }
            if dimming == nil, let d = p.target.dimming {
                dimming = d
                dimmingFrom = ControlAttribution(layer: p.layer, label: p.label)
            }
            if hardware == nil, let h = p.target.hardwareBrightness { hardware = h }
            if temperature != nil && dimming != nil && hardware != nil { break }
        }

        let dominant = ordered.first.map { ControlAttribution(layer: $0.layer, label: $0.label) } ?? fallback
        let resolved = ResolvedTarget(
            temperature: temperature ?? .neutral,
            dimming: dimming ?? .none,
            hardwareBrightness: hardware
        )

        return ResolutionOutcome(
            target: resolved,
            temperatureFrom: temperatureFrom,
            dimmingFrom: dimmingFrom,
            dominant: dominant,
            explanation: explain(resolved: resolved,
                                 temperatureFrom: temperatureFrom,
                                 dimmingFrom: dimmingFrom)
        )
    }

    /// Plain language, no jargon, no error codes. This string is the answer to
    /// "why does my screen look like this?" and it needs to read like a
    /// sentence a person would say.
    static func explain(resolved: ResolvedTarget,
                        temperatureFrom: ControlAttribution,
                        dimmingFrom: ControlAttribution) -> String {
        if temperatureFrom.layer == .emergencyRestore {
            return "Your display is back to its normal output because you chose Restore."
        }
        if temperatureFrom.layer == .userPause {
            return "Daylight is paused, so your display is at its normal output."
        }
        let warmth = describeWarmth(resolved.temperature)
        var s: String
        switch temperatureFrom.layer {
        case .manualOverride:
            s = "Your display is \(warmth) because you set it manually."
        case .activityRule:
            s = "Your display is \(warmth) because “\(temperatureFrom.label)” is active for this app."
        case .workspaceProfile:
            s = "Your display is \(warmth) because you are set up at \(temperatureFrom.label)."
        case .baseSchedule:
            s = "Your display is \(warmth), following \(temperatureFrom.label)."
        default:
            s = "Your display is \(warmth)."
        }
        if resolved.dimming.factor < 0.995 && dimmingFrom.layer != temperatureFrom.layer {
            s += " Dimming comes from “\(dimmingFrom.label)”."
        }
        return s
    }

    public static func describeWarmth(_ t: ColourTemperature) -> String {
        switch t.kelvin {
        case ..<2400:  return "very warm"
        case ..<3200:  return "warm"
        case ..<4300:  return "slightly warm"
        case ..<5600:  return "close to neutral"
        case ..<6400:  return "nearly neutral"
        default:       return "neutral"
        }
    }
}

// MARK: - Temporary overrides

public enum OverrideExpiry: Codable, Hashable, Sendable {
    case duration(TimeInterval)
    /// Runs until the schedule's next anchor, then hands control back.
    case untilNextScheduleChange
    case untilTime(Date)
    /// Stays until the person explicitly resumes automation.
    case untilResumed
}

/// Which displays a manual change applies to.
///
/// A change made while one display is selected should not quietly move the
/// others, and a change made with "All displays" selected should not become
/// stuck to whichever display happened to be first.
public enum OverrideScope: Codable, Hashable, Sendable {
    case allDisplays
    case display(key: String)
    case group(id: UUID)

    public func includes(displayKey: String, groupID: UUID?) -> Bool {
        switch self {
        case .allDisplays:        return true
        case .display(let key):   return key == displayKey
        case .group(let id):      return id == groupID
        }
    }
}

public struct TemporaryOverride: Identifiable, Codable, Hashable, Sendable {
    public var id: UUID
    public var label: String
    public var target: LightingTarget
    public var expiry: OverrideExpiry
    public var startedAt: Date
    /// Which layer this override occupies. Manual slider moves and mode
    /// selections both land here; a pause is modelled as its own layer.
    public var layer: ControlLayer
    public var scope: OverrideScope

    public init(id: UUID = UUID(),
                label: String,
                target: LightingTarget,
                expiry: OverrideExpiry,
                startedAt: Date,
                layer: ControlLayer = .manualOverride,
                scope: OverrideScope = .allDisplays) {
        self.id = id; self.label = label; self.target = target
        self.expiry = expiry; self.startedAt = startedAt
        self.layer = layer; self.scope = scope
    }

    enum CodingKeys: String, CodingKey {
        case id, label, target, expiry, startedAt, layer, scope
    }

    public init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = (try? c.decode(UUID.self, forKey: .id)) ?? UUID()
        label = (try? c.decode(String.self, forKey: .label)) ?? "Manual"
        target = (try? c.decode(LightingTarget.self, forKey: .target)) ?? LightingTarget()
        expiry = (try? c.decode(OverrideExpiry.self, forKey: .expiry)) ?? .untilResumed
        startedAt = (try? c.decode(Date.self, forKey: .startedAt)) ?? Date()
        layer = (try? c.decodeIfPresent(ControlLayer.self, forKey: .layer)) .flatMap { $0 } ?? .manualOverride
        scope = (try? c.decodeIfPresent(OverrideScope.self, forKey: .scope)) .flatMap { $0 } ?? .allDisplays
    }

    /// When this override ends. `nil` means "until you resume".
    public func expiryDate(nextScheduleChange: Date?) -> Date? {
        switch expiry {
        case .duration(let d):           return startedAt.addingTimeInterval(d)
        case .untilTime(let d):          return d
        case .untilNextScheduleChange:   return nextScheduleChange
        case .untilResumed:              return nil
        }
    }

    public func isExpired(at now: Date, nextScheduleChange: Date?) -> Bool {
        guard let end = expiryDate(nextScheduleChange: nextScheduleChange) else { return false }
        return now >= end
    }

    /// The sentence shown in the menu bar and the Today view.
    public func statusSentence(now: Date,
                               nextScheduleChange: Date?,
                               formatter: DateFormatter) -> String {
        guard let end = expiryDate(nextScheduleChange: nextScheduleChange) else {
            return "\(label) until you resume automation."
        }
        let remaining = end.timeIntervalSince(now)
        if remaining <= 0 { return "\(label) is ending now." }
        return "\(label) until \(formatter.string(from: end)). Your schedule resumes afterwards."
    }
}

// MARK: - Profiles (the app's "modes")

/// A named, transparent combination of settings. Every built-in mode is
/// nothing more than this — no hidden behaviour, so the description shown to
/// the user is always the whole truth.
public struct Profile: Identifiable, Codable, Hashable, Sendable {
    public var id: UUID
    public var name: String
    public var symbolName: String
    public var target: LightingTarget
    public var silencesReminders: Bool
    /// Plain-language description of exactly what this mode does.
    public var summary: String
    public var isBuiltIn: Bool

    public init(id: UUID = UUID(),
                name: String,
                symbolName: String,
                target: LightingTarget,
                silencesReminders: Bool = false,
                summary: String,
                isBuiltIn: Bool = false) {
        self.id = id; self.name = name; self.symbolName = symbolName
        self.target = target; self.silencesReminders = silencesReminders
        self.summary = summary; self.isBuiltIn = isBuiltIn
    }

    public static func builtIns() -> [Profile] {
        [
            Profile(name: "Focus", symbolName: "scope",
                    target: LightingTarget(temperature: ColourTemperature(kelvin: 5000),
                                           dimming: SoftwareDimming(factor: 0.95)),
                    summary: "Holds a steady, slightly warm setting instead of following your schedule.",
                    isBuiltIn: true),
            Profile(name: "Reading", symbolName: "book",
                    target: LightingTarget(temperature: ColourTemperature(kelvin: 3400),
                                           dimming: SoftwareDimming(factor: 0.82)),
                    summary: "Warmer and dimmer, for long stretches of text.",
                    isBuiltIn: true),
            Profile(name: "Wind Down", symbolName: "moon",
                    target: LightingTarget(temperature: ColourTemperature(kelvin: 2700),
                                           dimming: SoftwareDimming(factor: 0.7)),
                    summary: "Moves toward your evening settings early.",
                    isBuiltIn: true),
            Profile(name: "Colour Work", symbolName: "paintpalette",
                    target: LightingTarget(temperature: .neutral, dimming: SoftwareDimming.none),
                    summary: "Removes Daylight's own colour and dimming changes. This does not calibrate your display or make its colour accurate.",
                    isBuiltIn: true),
            Profile(name: "Presentation", symbolName: "person.2",
                    target: LightingTarget(temperature: .neutral, dimming: SoftwareDimming.none),
                    silencesReminders: true,
                    summary: "Neutral output and no reminders while you are presenting.",
                    isBuiltIn: true),
            Profile(name: "Gaming", symbolName: "gamecontroller",
                    target: LightingTarget(temperature: ColourTemperature(kelvin: 5800),
                                           dimming: SoftwareDimming.none),
                    silencesReminders: true,
                    summary: "A light touch of warmth and no reminders.",
                    isBuiltIn: true),
            Profile(name: "Night Desk", symbolName: "lamp.desk",
                    target: LightingTarget(temperature: ColourTemperature(kelvin: 2400),
                                           dimming: SoftwareDimming(factor: 0.55)),
                    summary: "Restrained warmth and brightness for late work.",
                    isBuiltIn: true),
        ]
    }
}

// MARK: - Rules

public enum RuleTrigger: Codable, Hashable, Sendable {
    /// Matches the frontmost application by bundle identifier.
    case frontmostApp(bundleIdentifier: String, displayName: String)
    case timeRange(startSeconds: Int, endSeconds: Int)
    case weekdays(Set<Int>)
    case onBatteryPower
    case displayConnected(identityKey: String, displayName: String)
    case workspace(name: String)

    public var describes: String {
        switch self {
        case .frontmostApp(_, let n):     return "\(n) is in front"
        case .timeRange(let s, let e):    return "between \(clockString(Double(s))) and \(clockString(Double(e)))"
        case .weekdays(let d):            return "on \(RuleTrigger.weekdayList(d))"
        case .onBatteryPower:             return "running on battery"
        case .displayConnected(_, let n): return "\(n) is connected"
        case .workspace(let n):           return "you are at \(n)"
        }
    }

    static func weekdayList(_ days: Set<Int>) -> String {
        let names = [1: "Sun", 2: "Mon", 3: "Tue", 4: "Wed", 5: "Thu", 6: "Fri", 7: "Sat"]
        return days.sorted().compactMap { names[$0] }.joined(separator: ", ")
    }
}

public enum RuleAction: Codable, Hashable, Sendable {
    case pauseWarmth
    case applyProfile(profileID: UUID, profileName: String)
    case setTemperature(ColourTemperature)
    case setDimming(SoftwareDimming)
    case silenceReminders
    case excludeDisplay(identityKey: String)

    public var describes: String {
        switch self {
        case .pauseWarmth:            return "pause warmth"
        case .applyProfile(_, let n): return "use \(n)"
        case .setTemperature(let t):  return "set warmth to about \(Int(t.kelvin.rounded())) K"
        case .setDimming(let d):      return "dim to \(Int((d.factor * 100).rounded()))%"
        case .silenceReminders:       return "silence reminders"
        case .excludeDisplay:         return "leave a display alone"
        }
    }
}

public struct Rule: Identifiable, Codable, Hashable, Sendable {
    public var id: UUID
    public var name: String
    public var isEnabled: Bool
    /// All triggers must match. Kept as AND-only on purpose: a rules system
    /// with mixed AND/OR quickly stops being predictable, and every case we
    /// need so far is expressible as several single-purpose rules.
    public var triggers: [RuleTrigger]
    public var actions: [RuleAction]
    /// Ordering among rules at the same layer. Lower runs first; later rules
    /// win ties, which is shown in the interface.
    public var order: Int

    public init(id: UUID = UUID(), name: String, isEnabled: Bool = true,
                triggers: [RuleTrigger], actions: [RuleAction], order: Int = 0) {
        self.id = id; self.name = name; self.isEnabled = isEnabled
        self.triggers = triggers; self.actions = actions; self.order = order
    }

    public var summary: String {
        let t = triggers.map(\.describes).joined(separator: " and ")
        let a = actions.map(\.describes).joined(separator: ", ")
        return "When \(t), \(a)."
    }
}

/// Everything the rules engine is allowed to look at. Passing a plain struct
/// keeps the engine pure and lets tests drive any situation directly.
public struct RuleContext: Equatable, Sendable {
    public var frontmostBundleID: String?
    public var secondsFromMidnight: Int
    public var weekday: Int
    public var onBattery: Bool
    public var connectedDisplayKeys: Set<String>
    /// Derived from which displays are attached — never from location services,
    /// network names, or anything else that would need a permission.
    public var workspaceName: String?

    public init(frontmostBundleID: String? = nil,
                secondsFromMidnight: Int = 0,
                weekday: Int = 2,
                onBattery: Bool = false,
                connectedDisplayKeys: Set<String> = [],
                workspaceName: String? = nil) {
        self.frontmostBundleID = frontmostBundleID
        self.secondsFromMidnight = secondsFromMidnight
        self.weekday = weekday
        self.onBattery = onBattery
        self.connectedDisplayKeys = connectedDisplayKeys
        self.workspaceName = workspaceName
    }
}

public struct RuleEvaluation: Equatable, Sendable {
    public var matchedRules: [Rule]
    public var proposal: LayerProposal?
    public var silencesReminders: Bool
    public var excludedDisplayKeys: Set<String>
}

public enum RulesEngine {

    public static func matches(_ trigger: RuleTrigger, _ ctx: RuleContext) -> Bool {
        switch trigger {
        case .frontmostApp(let bundle, _):
            return ctx.frontmostBundleID == bundle
        case .timeRange(let s, let e):
            // A range that wraps past midnight is normal, not an error.
            return s <= e ? (ctx.secondsFromMidnight >= s && ctx.secondsFromMidnight < e)
                          : (ctx.secondsFromMidnight >= s || ctx.secondsFromMidnight < e)
        case .weekdays(let days):
            return days.contains(ctx.weekday)
        case .onBatteryPower:
            return ctx.onBattery
        case .displayConnected(let key, _):
            return ctx.connectedDisplayKeys.contains(key)
        case .workspace(let name):
            return ctx.workspaceName == name
        }
    }

    public static func evaluate(rules: [Rule],
                                context: RuleContext,
                                profiles: [Profile]) -> RuleEvaluation {
        let matched = rules
            .filter { $0.isEnabled && !$0.triggers.isEmpty }
            .filter { rule in rule.triggers.allSatisfy { matches($0, context) } }
            .sorted { $0.order < $1.order }

        guard !matched.isEmpty else {
            return RuleEvaluation(matchedRules: [], proposal: nil,
                                  silencesReminders: false, excludedDisplayKeys: [])
        }

        var target = LightingTarget()
        var silence = false
        var excluded = Set<String>()

        // Later rules win per control, matching the visible ordering.
        for rule in matched {
            for action in rule.actions {
                switch action {
                case .pauseWarmth:
                    target.temperature = .neutral
                case .setTemperature(let t):
                    target.temperature = t
                case .setDimming(let d):
                    target.dimming = d
                case .applyProfile(let pid, _):
                    if let p = profiles.first(where: { $0.id == pid }) {
                        if let t = p.target.temperature { target.temperature = t }
                        if let d = p.target.dimming { target.dimming = d }
                        if p.silencesReminders { silence = true }
                    }
                case .silenceReminders:
                    silence = true
                case .excludeDisplay(let key):
                    excluded.insert(key)
                }
            }
        }

        let label = matched.count == 1 ? matched[0].name : "\(matched.count) rules"
        return RuleEvaluation(
            matchedRules: matched,
            proposal: LayerProposal(layer: .activityRule, label: label, target: target),
            silencesReminders: silence,
            excludedDisplayKeys: excluded)
    }
}
