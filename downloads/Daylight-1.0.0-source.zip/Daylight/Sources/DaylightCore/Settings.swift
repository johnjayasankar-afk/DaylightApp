import Foundation

// MARK: - Per-display settings

public struct DisplaySettings: Codable, Hashable, Identifiable, Sendable {
    /// Durable identity key, not a display index. See `DisplayIdentity`.
    public var id: String
    public var customName: String?
    /// Excluded displays are never written to at all.
    public var isExcluded: Bool
    /// Floor for software dimming on this display.
    public var minimumDimming: Double
    public var minimumKelvin: Double
    public var maximumKelvin: Double
    /// Added to the resolved dimming for this display, so one screen can sit
    /// a little darker than another without duplicating the whole schedule.
    public var dimmingOffset: Double
    public var groupID: UUID?
    /// Drive this display's backlight over DDC instead of dimming in software.
    /// Only has any effect on a display that has proven it answers DDC.
    public var prefersHardwareBrightness: Bool

    public init(id: String,
                customName: String? = nil,
                isExcluded: Bool = false,
                minimumDimming: Double = 0.35,
                minimumKelvin: Double = ColourTemperature.normalRange.lowerBound,
                maximumKelvin: Double = ColourTemperature.normalRange.upperBound,
                dimmingOffset: Double = 0,
                groupID: UUID? = nil,
                prefersHardwareBrightness: Bool = false) {
        self.id = id; self.customName = customName; self.isExcluded = isExcluded
        self.minimumDimming = minimumDimming
        self.minimumKelvin = minimumKelvin; self.maximumKelvin = maximumKelvin
        self.dimmingOffset = dimmingOffset; self.groupID = groupID
        self.prefersHardwareBrightness = prefersHardwareBrightness
    }

    /// Apply this display's own limits to a resolved target.
    public func constrain(_ target: ResolvedTarget) -> ResolvedTarget {
        let lo = min(minimumKelvin, maximumKelvin)
        let hi = max(minimumKelvin, maximumKelvin)
        return ResolvedTarget(
            temperature: target.temperature.clamped(to: lo...hi),
            dimming: SoftwareDimming(factor: target.dimming.factor + dimmingOffset)
                .clamped(to: max(minimumDimming, SoftwareDimming.safeFloor)...1.0),
            hardwareBrightness: target.hardwareBrightness
        )
    }

    enum CodingKeys: String, CodingKey {
        case id, customName, isExcluded, minimumDimming, minimumKelvin
        case maximumKelvin, dimmingOffset, groupID, prefersHardwareBrightness
    }

    /// Hand-written for the same reason as `DaylightSettings`: a new field must
    /// not invalidate settings files written before it existed.
    public init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = (try? c.decode(String.self, forKey: .id)) ?? "unknown"
        customName = try? c.decodeIfPresent(String.self, forKey: .customName)
        isExcluded = (try? c.decodeIfPresent(Bool.self, forKey: .isExcluded)) .flatMap { $0 } ?? false
        minimumDimming = (try? c.decodeIfPresent(Double.self, forKey: .minimumDimming)) .flatMap { $0 } ?? 0.35
        minimumKelvin = (try? c.decodeIfPresent(Double.self, forKey: .minimumKelvin)) .flatMap { $0 }
            ?? ColourTemperature.normalRange.lowerBound
        maximumKelvin = (try? c.decodeIfPresent(Double.self, forKey: .maximumKelvin)) .flatMap { $0 }
            ?? ColourTemperature.normalRange.upperBound
        dimmingOffset = (try? c.decodeIfPresent(Double.self, forKey: .dimmingOffset)) .flatMap { $0 } ?? 0
        groupID = try? c.decodeIfPresent(UUID.self, forKey: .groupID)
        prefersHardwareBrightness =
            (try? c.decodeIfPresent(Bool.self, forKey: .prefersHardwareBrightness)) .flatMap { $0 } ?? false
    }

    public mutating func validate() {
        minimumDimming = min(max(minimumDimming, SoftwareDimming.safeFloor), 1.0)
        minimumKelvin  = min(max(minimumKelvin, ColourTemperature.advancedRange.lowerBound),
                             ColourTemperature.advancedRange.upperBound)
        maximumKelvin  = min(max(maximumKelvin, ColourTemperature.advancedRange.lowerBound),
                             ColourTemperature.advancedRange.upperBound)
        if minimumKelvin > maximumKelvin { swap(&minimumKelvin, &maximumKelvin) }
        dimmingOffset  = min(max(dimmingOffset, -0.5), 0.5)
    }
}

/// Two or more displays that should behave identically.
///
/// The group owns one set of limits and its members defer to them, rather than
/// each member keeping its own copy that could quietly drift apart. Unlinking a
/// display gives it back its own settings, seeded from the group's.
public struct DisplayGroup: Identifiable, Codable, Hashable, Sendable {
    public var id: UUID
    public var name: String
    public var memberKeys: [String]
    /// The shared limits. Its `id` is unused; only the limit fields matter.
    public var settings: DisplaySettings

    public init(id: UUID = UUID(), name: String, memberKeys: [String],
                settings: DisplaySettings? = nil) {
        self.id = id; self.name = name; self.memberKeys = memberKeys
        self.settings = settings ?? DisplaySettings(id: "group:\(id.uuidString)")
    }

    enum CodingKeys: String, CodingKey { case id, name, memberKeys, settings }

    public init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = (try? c.decode(UUID.self, forKey: .id)) ?? UUID()
        name = (try? c.decode(String.self, forKey: .name)) ?? "Linked displays"
        memberKeys = (try? c.decode([String].self, forKey: .memberKeys)) ?? []
        settings = (try? c.decodeIfPresent(DisplaySettings.self, forKey: .settings)) .flatMap { $0 }
            ?? DisplaySettings(id: "group:\(id.uuidString)")
    }
}

// MARK: - Transition feel

public enum TransitionSpeed: String, Codable, CaseIterable, Sendable {
    case immediate, brisk, gentle, veryGentle

    public var displayName: String {
        switch self {
        case .immediate:  return "Immediate"
        case .brisk:      return "Brisk"
        case .gentle:     return "Gentle"
        case .veryGentle: return "Very gentle"
        }
    }
    /// How long a manual change takes to reach its new value.
    public var manualRampSeconds: Double {
        switch self {
        case .immediate:  return 0
        case .brisk:      return 1.5
        case .gentle:     return 6
        case .veryGentle: return 20
        }
    }
    public var description: String {
        switch self {
        case .immediate:  return "Changes apply at once."
        case .brisk:      return "A short, noticeable fade."
        case .gentle:     return "An unhurried fade."
        case .veryGentle: return "Slow enough to be easy to miss."
        }
    }
}

// MARK: - Root settings document

public struct DaylightSettings: Codable, Hashable, Sendable {
    public static let currentSchemaVersion = 1

    public var schemaVersion: Int
    public var schedules: [Schedule]
    public var activeScheduleID: UUID
    public var profiles: [Profile]
    public var rules: [Rule]
    public var displays: [DisplaySettings]
    public var groups: [DisplayGroup]
    public var workspaces: [Workspace]
    public var location: GeoLocation?
    public var transitionSpeed: TransitionSpeed
    public var automationEnabled: Bool
    public var hasCompletedOnboarding: Bool
    public var launchAtLogin: Bool
    public var showsMenuBarPercentage: Bool
    public var respectsReducedMotion: Bool
    /// Off unless the person turns it on; nothing is written to disk about
    /// which apps were in front unless they enable app rules.
    public var appRulesEnabled: Bool
    public var warnOnExtremeSettings: Bool
    public var advancedWarmthRange: Bool
    public var breakReminders: BreakReminderSettings
    /// Off by default. Turning this on lets Daylight try DDC/CI on external
    /// displays, which needs private system API. See Docs/compatibility.md.
    public var experimentalDDCBrightness: Bool
    public var history: HistorySettings

    public init(schemaVersion: Int = DaylightSettings.currentSchemaVersion,
                schedules: [Schedule],
                activeScheduleID: UUID,
                profiles: [Profile] = Profile.builtIns(),
                rules: [Rule] = [],
                displays: [DisplaySettings] = [],
                groups: [DisplayGroup] = [],
                workspaces: [Workspace] = [],
                location: GeoLocation? = nil,
                transitionSpeed: TransitionSpeed = .gentle,
                automationEnabled: Bool = true,
                hasCompletedOnboarding: Bool = false,
                launchAtLogin: Bool = false,
                showsMenuBarPercentage: Bool = false,
                respectsReducedMotion: Bool = true,
                appRulesEnabled: Bool = false,
                warnOnExtremeSettings: Bool = true,
                advancedWarmthRange: Bool = false,
                breakReminders: BreakReminderSettings = BreakReminderSettings(),
                experimentalDDCBrightness: Bool = false,
                history: HistorySettings = HistorySettings()) {
        self.schemaVersion = schemaVersion
        self.schedules = schedules
        self.activeScheduleID = activeScheduleID
        self.profiles = profiles
        self.rules = rules
        self.displays = displays
        self.groups = groups
        self.workspaces = workspaces
        self.location = location
        self.transitionSpeed = transitionSpeed
        self.automationEnabled = automationEnabled
        self.hasCompletedOnboarding = hasCompletedOnboarding
        self.launchAtLogin = launchAtLogin
        self.showsMenuBarPercentage = showsMenuBarPercentage
        self.respectsReducedMotion = respectsReducedMotion
        self.appRulesEnabled = appRulesEnabled
        self.warnOnExtremeSettings = warnOnExtremeSettings
        self.advancedWarmthRange = advancedWarmthRange
        self.breakReminders = breakReminders
        self.experimentalDDCBrightness = experimentalDDCBrightness
        self.history = history
    }

    // MARK: Decoding
    //
    // Written by hand rather than synthesised. Swift's synthesised decoder
    // treats every missing key as an error, including keys for properties that
    // have default values — so adding one field to this struct would make every
    // settings file written by an earlier build fail to decode, and the whole
    // configuration would be silently replaced by defaults.
    //
    // This was not hypothetical: it happened, and the schedule someone had set
    // up was quietly discarded on the next launch. Every field is now optional
    // on the way in, so old files keep working and new fields take their
    // defaults.

    enum CodingKeys: String, CodingKey {
        case schemaVersion, schedules, activeScheduleID, profiles, rules, displays
        case groups, workspaces, location, transitionSpeed, automationEnabled
        case hasCompletedOnboarding, launchAtLogin, showsMenuBarPercentage
        case respectsReducedMotion, appRulesEnabled, warnOnExtremeSettings
        case advancedWarmthRange, breakReminders, experimentalDDCBrightness, history
    }

    public init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        func value<T: Decodable>(_ key: CodingKeys, _ fallback: T) -> T {
            (try? c.decodeIfPresent(T.self, forKey: key)) .flatMap { $0 } ?? fallback
        }
        let defaults = Presets.all()
        schemaVersion  = value(.schemaVersion, DaylightSettings.currentSchemaVersion)
        schedules      = value(.schedules, defaults)
        activeScheduleID = value(.activeScheduleID, schedules.first?.id ?? UUID())
        profiles       = value(.profiles, Profile.builtIns())
        rules          = value(.rules, [])
        displays       = value(.displays, [])
        groups         = value(.groups, [])
        workspaces     = value(.workspaces, [])
        location       = try? c.decodeIfPresent(GeoLocation.self, forKey: .location)
        transitionSpeed = value(.transitionSpeed, .gentle)
        automationEnabled = value(.automationEnabled, true)
        hasCompletedOnboarding = value(.hasCompletedOnboarding, false)
        launchAtLogin = value(.launchAtLogin, false)
        showsMenuBarPercentage = value(.showsMenuBarPercentage, false)
        respectsReducedMotion = value(.respectsReducedMotion, true)
        appRulesEnabled = value(.appRulesEnabled, false)
        warnOnExtremeSettings = value(.warnOnExtremeSettings, true)
        advancedWarmthRange = value(.advancedWarmthRange, false)
        breakReminders = value(.breakReminders, BreakReminderSettings())
        experimentalDDCBrightness = value(.experimentalDDCBrightness, false)
        history = value(.history, HistorySettings())
    }

    public var activeSchedule: Schedule? {
        schedules.first { $0.id == activeScheduleID } ?? schedules.first
    }

    /// Settings actually in force for a display: its own, unless it is linked
    /// into a group, in which case the group's shared limits apply.
    ///
    /// The display's own name and exclusion always win — linking two monitors
    /// should not stop you naming them separately or leaving one alone.
    public func settings(forDisplay key: String) -> DisplaySettings {
        let own = displays.first { $0.id == key } ?? DisplaySettings(id: key)
        guard let group = group(containing: key) else { return own }
        var merged = group.settings
        merged.id = key
        merged.customName = own.customName
        merged.isExcluded = own.isExcluded
        merged.groupID = group.id
        return merged
    }

    public func group(containing key: String) -> DisplayGroup? {
        groups.first { $0.memberKeys.contains(key) }
    }

    /// Repair anything out of range rather than refusing to load. A settings
    /// file that is 95% valid should not cost someone their whole setup.
    public mutating func validate() {
        if schedules.isEmpty { schedules = [Presets.balanced()] }
        if !schedules.contains(where: { $0.id == activeScheduleID }) {
            activeScheduleID = schedules[0].id
        }
        for i in schedules.indices {
            schedules[i].weekdayAnchors = Self.validated(schedules[i].weekdayAnchors)
            schedules[i].weekendAnchors = Self.validated(schedules[i].weekendAnchors)
        }
        for i in displays.indices { displays[i].validate() }
        for i in groups.indices { groups[i].settings.validate() }
        // A display can only belong to one group; drop later duplicates rather
        // than leaving the resolution order to chance.
        var claimed = Set<String>()
        for i in groups.indices {
            groups[i].memberKeys = groups[i].memberKeys.filter { claimed.insert($0).inserted }
        }
        groups.removeAll { $0.memberKeys.count < 2 }
        for i in workspaces.indices {
            if let sid = workspaces[i].scheduleID, !schedules.contains(where: { $0.id == sid }) {
                workspaces[i].scheduleID = nil
            }
        }
        breakReminders.validate()
        history.validate()
        if let loc = location, !loc.isValid { location = nil }
        if profiles.isEmpty { profiles = Profile.builtIns() }
    }

    private static func validated(_ anchors: [ScheduleAnchor]) -> [ScheduleAnchor] {
        anchors.map { a in
            var a = a
            a.temperature = a.temperature.clamped(to: ColourTemperature.advancedRange)
            a.dimming = a.dimming.clamped()
            a.transitionMinutes = min(max(a.transitionMinutes, 0), 6 * 60)
            if case .clock(let s) = a.time {
                a.time = .clock(secondsFromMidnight: min(max(s, 0), 86_399))
            }
            return a
        }
    }
}

// MARK: - Presets

public enum Presets {

    public static func anchor(_ name: String, _ hour: Int, _ minute: Int,
                              _ kelvin: Double, _ dim: Double,
                              transition: Double = 60) -> ScheduleAnchor {
        ScheduleAnchor(name: name,
                       time: .clock(secondsFromMidnight: hour * 3600 + minute * 60),
                       temperature: ColourTemperature(kelvin: kelvin),
                       dimming: SoftwareDimming(factor: dim),
                       transitionMinutes: transition)
    }

    public static func subtle() -> Schedule {
        Schedule(name: "Subtle", weekdayAnchors: [
            anchor("Morning",   7,  0, 6500, 1.00, transition: 30),
            anchor("Day",      10,  0, 6500, 1.00, transition: 30),
            anchor("Evening",  20,  0, 5000, 0.98, transition: 90),
            anchor("Night",    23,  0, 4300, 0.92, transition: 60),
        ])
    }

    public static func balanced() -> Schedule {
        Schedule(name: "Balanced", weekdayAnchors: [
            anchor("Morning",   7,  0, 6500, 1.00, transition: 40),
            anchor("Day",       9, 30, 6500, 1.00, transition: 30),
            anchor("Evening",  19,  0, 4200, 0.95, transition: 90),
            anchor("Wind down",21, 30, 3200, 0.82, transition: 60),
            anchor("Night",    23, 30, 2800, 0.70, transition: 45),
        ])
    }

    public static func extraWarm() -> Schedule {
        Schedule(name: "Extra Warm", weekdayAnchors: [
            anchor("Morning",   7,  0, 6000, 1.00, transition: 40),
            anchor("Day",       9, 30, 6200, 1.00, transition: 30),
            anchor("Evening",  18, 30, 3600, 0.90, transition: 90),
            anchor("Wind down",21,  0, 2800, 0.72, transition: 60),
            anchor("Night",    23,  0, 2400, 0.58, transition: 45),
        ])
    }

    /// Uses solar anchors, clamped so the schedule stays sensible in midwinter
    /// and midsummer without the person having to re-tune it.
    public static func solar() -> Schedule {
        Schedule(name: "Follow the sun", weekdayAnchors: [
            ScheduleAnchor(name: "Sunrise",
                           time: .solar(event: .sunrise, offsetMinutes: 0,
                                        earliest: 5 * 3600, latest: 9 * 3600),
                           temperature: ColourTemperature(kelvin: 6500),
                           dimming: SoftwareDimming.none, transitionMinutes: 45),
            ScheduleAnchor(name: "Sunset",
                           time: .solar(event: .sunset, offsetMinutes: -30,
                                        earliest: 17 * 3600, latest: 21 * 3600 + 30 * 60),
                           temperature: ColourTemperature(kelvin: 4000),
                           dimming: SoftwareDimming(factor: 0.94), transitionMinutes: 90),
            anchor("Wind down", 21, 30, 3100, 0.80, transition: 60),
            anchor("Night",     23, 30, 2700, 0.68, transition: 45),
        ])
    }

    public static func all() -> [Schedule] { [balanced(), subtle(), extraWarm(), solar()] }

    public static func defaultSettings() -> DaylightSettings {
        let schedules = all()
        return DaylightSettings(schedules: schedules, activeScheduleID: schedules[0].id)
    }
}

// MARK: - Store

public enum SettingsStoreError: Error, LocalizedError {
    case unreadable(String)
    case unwritable(String)

    public var errorDescription: String? {
        switch self {
        case .unreadable(let s): return "Daylight could not read your settings. \(s)"
        case .unwritable(let s): return "Daylight could not save your settings. \(s)"
        }
    }
}

/// Local, file-backed settings. No account, no network, no database.
///
/// Writes go to a temporary file first and are then moved into place, so an
/// interrupted write cannot leave a half-written settings file behind.
public final class SettingsStore: @unchecked Sendable {
    public let directory: URL
    public let fileURL: URL
    private let backupURL: URL
    private let queue = DispatchQueue(label: "app.daylight.settings")

    public init(directory: URL) {
        self.directory = directory
        self.fileURL = directory.appendingPathComponent("settings.json")
        self.backupURL = directory.appendingPathComponent("settings.backup.json")
    }

    public static func defaultDirectory(appName: String = Branding.bundleFolderName) -> URL {
        // An override so a test run can be pointed at a scratch directory
        // instead of the real one. Nothing in the shipping app sets it.
        if let override = ProcessInfo.processInfo.environment["DAYLIGHT_SETTINGS_DIR"], !override.isEmpty {
            return URL(fileURLWithPath: override, isDirectory: true)
        }
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return base.appendingPathComponent(appName, isDirectory: true)
    }

    private static var encoder: JSONEncoder {
        let e = JSONEncoder()
        e.outputFormatting = [.prettyPrinted, .sortedKeys]
        e.dateEncodingStrategy = .iso8601
        return e
    }
    private static var decoder: JSONDecoder {
        let d = JSONDecoder()
        d.dateDecodingStrategy = .iso8601
        return d
    }

    /// Result of a load, including whether we had to recover.
    public struct LoadOutcome: Sendable {
        public var settings: DaylightSettings
        public var recoveredFromCorruption: Bool
        public var migratedFrom: Int?
        public var isFirstRun: Bool
    }

    public func load() -> LoadOutcome {
        queue.sync {
            let fm = FileManager.default
            guard fm.fileExists(atPath: fileURL.path) else {
                return LoadOutcome(settings: Presets.defaultSettings(),
                                   recoveredFromCorruption: false,
                                   migratedFrom: nil, isFirstRun: true)
            }
            if let outcome = decode(fileURL) { return outcome }
            // Primary file is unusable; try the last good copy before giving up.
            if let outcome = decode(backupURL) {
                return LoadOutcome(settings: outcome.settings,
                                   recoveredFromCorruption: true,
                                   migratedFrom: outcome.migratedFrom, isFirstRun: false)
            }
            return LoadOutcome(settings: Presets.defaultSettings(),
                               recoveredFromCorruption: true,
                               migratedFrom: nil, isFirstRun: false)
        }
    }

    private func decode(_ url: URL) -> LoadOutcome? {
        guard let data = try? Data(contentsOf: url) else { return nil }
        guard var s = try? Self.decoder.decode(DaylightSettings.self, from: data) else { return nil }
        let from = s.schemaVersion
        let migrated = Self.migrate(&s)
        s.validate()
        return LoadOutcome(settings: s, recoveredFromCorruption: false,
                           migratedFrom: migrated ? from : nil, isFirstRun: false)
    }

    /// Returns true if anything was changed. Version 1 is the first shipped
    /// schema, so there is nothing to migrate yet — but the seam exists and is
    /// covered by tests, which is the point.
    @discardableResult
    public static func migrate(_ s: inout DaylightSettings) -> Bool {
        var changed = false
        if s.schemaVersion < 1 {
            s.schemaVersion = 1
            changed = true
        }
        if s.schemaVersion > DaylightSettings.currentSchemaVersion {
            // Written by a newer build. Load what we can rather than refusing.
            s.schemaVersion = DaylightSettings.currentSchemaVersion
            changed = true
        }
        return changed
    }

    public func save(_ settings: DaylightSettings) throws {
        var s = settings
        s.schemaVersion = DaylightSettings.currentSchemaVersion
        s.validate()
        let data = try Self.encoder.encode(s)
        try queue.sync {
            let fm = FileManager.default
            try fm.createDirectory(at: directory, withIntermediateDirectories: true)
            if fm.fileExists(atPath: fileURL.path) {
                try? fm.removeItem(at: backupURL)
                try? fm.copyItem(at: fileURL, to: backupURL)
            }
            let tmp = directory.appendingPathComponent("settings.\(UUID().uuidString).tmp")
            do {
                try data.write(to: tmp, options: .atomic)
                _ = try fm.replaceItemAt(fileURL, withItemAt: tmp)
            } catch {
                try? fm.removeItem(at: tmp)
                throw SettingsStoreError.unwritable(error.localizedDescription)
            }
        }
    }

    // MARK: Export / import

    public func exportData(_ settings: DaylightSettings) throws -> Data {
        var s = settings
        s.validate()
        return try Self.encoder.encode(s)
    }

    /// Imported files are untrusted input: decoded, then clamped into range
    /// before anything is allowed near a display.
    public func importData(_ data: Data) throws -> DaylightSettings {
        guard var s = try? Self.decoder.decode(DaylightSettings.self, from: data) else {
            throw SettingsStoreError.unreadable("The file is not a Daylight settings file.")
        }
        Self.migrate(&s)
        s.validate()
        s.hasCompletedOnboarding = true
        return s
    }
}

// MARK: - Branding
//
// Every user-visible name comes from here, so renaming the product is a
// one-file change rather than an archaeology project.

public enum Branding {
    public static let productName = "Daylight"
    public static let bundleIdentifier = "app.daylight.Daylight"
    public static let bundleFolderName = "Daylight"
    public static let tagline = "Adjust your display to your preferences through the day."
    public static let version = "1.0.0"
}

// MARK: - Workspaces

/// A place you work, recognised by which displays are attached.
///
/// Deliberately inferred from display identity alone. Guessing location from
/// Wi-Fi names or Core Location would mean asking for a permission the rest of
/// the app does not need, to answer a question the displays already answer.
public struct Workspace: Identifiable, Codable, Hashable, Sendable {
    public var id: UUID
    public var name: String
    /// Every one of these must be connected for the workspace to match.
    /// An empty set means "whenever nothing more specific matches".
    public var requiredDisplayKeys: Set<String>
    public var target: LightingTarget
    /// Optionally switches to a different schedule entirely.
    public var scheduleID: UUID?
    public var isEnabled: Bool

    public init(id: UUID = UUID(), name: String,
                requiredDisplayKeys: Set<String> = [],
                target: LightingTarget = LightingTarget(),
                scheduleID: UUID? = nil,
                isEnabled: Bool = true) {
        self.id = id; self.name = name
        self.requiredDisplayKeys = requiredDisplayKeys
        self.target = target; self.scheduleID = scheduleID
        self.isEnabled = isEnabled
    }

    public var summary: String {
        if requiredDisplayKeys.isEmpty { return "Whenever no other workspace matches." }
        let n = requiredDisplayKeys.count
        return "When \(n) specific display\(n == 1 ? " is" : "s are") connected."
    }
}

public enum WorkspaceMatcher {
    /// The most specific enabled workspace whose displays are all present.
    ///
    /// "Most specific" means the largest set of required displays, so a
    /// two-monitor desk setup wins over a one-monitor rule that it contains.
    /// Ties are broken by the order they appear, which is the order shown.
    public static func match(_ workspaces: [Workspace],
                             connected: Set<String>) -> Workspace? {
        workspaces
            .filter { $0.isEnabled && $0.requiredDisplayKeys.isSubset(of: connected) }
            .max { a, b in
                if a.requiredDisplayKeys.count != b.requiredDisplayKeys.count {
                    return a.requiredDisplayKeys.count < b.requiredDisplayKeys.count
                }
                return false   // stable: `max` keeps the earlier element on a tie
            }
    }
}
