import Foundation

/// DDC/CI message framing (VESA MCCS).
///
/// Kept in `DaylightCore`, with no I/O of its own, so the byte-level protocol
/// can be tested exhaustively without a monitor attached. The transport that
/// actually puts these bytes on the wire lives in `DaylightDisplay` and needs
/// private system APIs; this part does not.
public enum DDCPacket {

    /// I²C address of a DDC/CI display, as a 7-bit address.
    public static let displayChipAddress: UInt8 = 0x37
    /// Address bytes used when computing checksums.
    public static let displayAddress: UInt8 = 0x6E
    public static let hostAddress: UInt8 = 0x51
    /// The host's address as it appears as a *destination* in a reply.
    public static let hostAddressInReply: UInt8 = 0x50

    /// Standard MCCS feature codes. Only these two are ever used.
    public enum VCP: UInt8 {
        case luminance = 0x10
        case contrast  = 0x12
    }

    public static func checksum(_ bytes: [UInt8], seed: UInt8) -> UInt8 {
        bytes.reduce(seed) { $0 ^ $1 }
    }

    /// "Set VCP feature" — the message that changes brightness.
    public static func setVCP(_ vcp: UInt8, value: UInt16) -> [UInt8] {
        let body: [UInt8] = [
            hostAddress,
            0x80 | 4,                       // four payload bytes follow
            0x03,                           // set VCP feature
            vcp,
            UInt8(truncatingIfNeeded: value >> 8),
            UInt8(truncatingIfNeeded: value),
        ]
        return body + [checksum(body, seed: displayAddress)]
    }

    /// "Get VCP feature" — used to find out whether the display answers at all,
    /// and what its maximum is.
    public static func getVCP(_ vcp: UInt8) -> [UInt8] {
        let body: [UInt8] = [
            hostAddress,
            0x80 | 2,
            0x01,                           // get VCP feature
            vcp,
        ]
        return body + [checksum(body, seed: displayAddress)]
    }

    public struct VCPReply: Equatable, Sendable {
        public var vcp: UInt8
        public var current: UInt16
        public var maximum: UInt16
    }

    /// Parses a "get VCP feature reply".
    ///
    /// Returns nil for anything that is not a well-formed, successful reply for
    /// the feature we asked about — a bad checksum, an error result, or a reply
    /// about a different feature. Being strict here is what lets the capability
    /// probe treat a successful parse as real evidence of DDC support.
    public static func parseReply(_ bytes: [UInt8], expecting vcp: UInt8) -> VCPReply? {
        // Some transports include the leading source-address byte and some do
        // not; accept both rather than guessing.
        var b = bytes
        if b.first == displayAddress { b.removeFirst() }
        guard b.count >= 10 else { return nil }

        guard b[0] == 0x88 else { return nil }          // eight payload bytes
        guard b[1] == 0x02 else { return nil }          // get-VCP reply
        guard b[2] == 0x00 else { return nil }          // 0 = no error
        guard b[3] == vcp else { return nil }           // about the right feature

        let expected = checksum([displayAddress] + Array(b[0..<9]), seed: hostAddressInReply)
        guard b[9] == expected else { return nil }

        let maximum = UInt16(b[5]) << 8 | UInt16(b[6])
        let current = UInt16(b[7]) << 8 | UInt16(b[8])
        guard maximum > 0 else { return nil }
        return VCPReply(vcp: vcp, current: current, maximum: maximum)
    }

    /// Convert a 0...1 level into the display's own scale.
    public static func rawValue(forLevel level: Double, maximum: UInt16) -> UInt16 {
        let clamped = min(max(level, 0), 1)
        return UInt16((clamped * Double(maximum)).rounded())
    }

    public static func level(forRaw raw: UInt16, maximum: UInt16) -> Double {
        guard maximum > 0 else { return 0 }
        return min(max(Double(raw) / Double(maximum), 0), 1)
    }
}
