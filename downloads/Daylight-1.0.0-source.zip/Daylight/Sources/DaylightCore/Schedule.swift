import Foundation

// MARK: - When an anchor happens

public enum AnchorTime: Codable, Hashable, Sendable {
    /// A wall-clock time, as seconds from local midnight. Wall clock is the
    /// right frame for "I go to bed at 23:00" — it should stay 23:00 across a
    /// daylight-saving change, not drift by an hour.
    case clock(secondsFromMidnight: Int)

    /// A solar event, optionally offset, optionally clamped to a window.
    ///
    /// The clamps are what make a hybrid schedule predictable: "wind down at
    /// sunset, but never before 18:30 and never after 21:30" behaves sensibly
    /// in December and in June without the user rethinking it twice a year.
    case solar(event: SolarEvent,
               offsetMinutes: Int,
               earliest: Int?,   // seconds from midnight
               latest: Int?)     // seconds from midnight

    public var isSolar: Bool { if case .solar = self { return true }; return false }
}

public enum AnchorOrigin: Equatable, Sendable {
    case clock
    case solar(SolarEvent)
    /// The solar event did not occur (polar day/night) or no location is set,
    /// so a fallback time was used. Surfaced to the user in plain language.
    case solarFallback(SolarEvent, reason: FallbackReason)
    case solarClamped(SolarEvent, clamp: ClampSide)

    public enum FallbackReason: String, Equatable, Sendable {
        case noLocation, polarDay, polarNight
    }
    public enum ClampSide: String, Equatable, Sendable { case earliest, latest }
}

// MARK: - Anchor

public struct ScheduleAnchor: Identifiable, Codable, Hashable, Sendable {
    public var id: UUID
    public var name: String
    public var time: AnchorTime
    public var temperature: ColourTemperature
    public var dimming: SoftwareDimming
    /// Length of the ramp *into* this anchor, in minutes. The output reaches
    /// this anchor's values exactly at the anchor's time.
    public var transitionMinutes: Double
    public var isEnabled: Bool

    public init(id: UUID = UUID(),
                name: String,
                time: AnchorTime,
                temperature: ColourTemperature,
                dimming: SoftwareDimming = .none,
                transitionMinutes: Double = 60,
                isEnabled: Bool = true) {
        self.id = id
        self.name = name
        self.time = time
        self.temperature = temperature
        self.dimming = dimming
        self.transitionMinutes = transitionMinutes
        self.isEnabled = isEnabled
    }

    public var target: ResolvedTarget {
        ResolvedTarget(temperature: temperature, dimming: dimming)
    }
}

// MARK: - Schedule

public struct Schedule: Identifiable, Codable, Hashable, Sendable {
    public var id: UUID
    public var name: String
    public var weekdayAnchors: [ScheduleAnchor]
    /// Only consulted when `usesSeparateWeekend` is true.
    public var weekendAnchors: [ScheduleAnchor]
    public var usesSeparateWeekend: Bool
    /// Which weekdays count as "weekend". 1 = Sunday ... 7 = Saturday, matching
    /// `Calendar.component(.weekday:)`. Configurable so that a night-shift or
    /// Sunday–Thursday week is expressible without special-casing.
    public var weekendDays: Set<Int>

    public init(id: UUID = UUID(),
                name: String,
                weekdayAnchors: [ScheduleAnchor],
                weekendAnchors: [ScheduleAnchor] = [],
                usesSeparateWeekend: Bool = false,
                weekendDays: Set<Int> = [1, 7]) {
        self.id = id
        self.name = name
        self.weekdayAnchors = weekdayAnchors
        self.weekendAnchors = weekendAnchors
        self.usesSeparateWeekend = usesSeparateWeekend
        self.weekendDays = weekendDays
    }

    public func anchors(forWeekday weekday: Int) -> [ScheduleAnchor] {
        if usesSeparateWeekend && weekendDays.contains(weekday) { return weekendAnchors }
        return weekdayAnchors
    }
}

// MARK: - Resolution

public struct ResolvedAnchor: Identifiable, Equatable, Sendable {
    public var id: UUID { anchor.id }
    public var anchor: ScheduleAnchor
    /// Seconds relative to *today's* local midnight. May be negative
    /// (yesterday) or > 86400 (tomorrow) so that cross-midnight schedules and
    /// weekday/weekend boundaries work without special cases.
    public var seconds: Double
    public var origin: AnchorOrigin
    public var dayOffset: Int

    public var target: ResolvedTarget { anchor.target }
}

public struct ScheduleDiagnostic: Equatable, Sendable, Identifiable {
    public var id = UUID()
    public var message: String
    public var severity: Severity
    public enum Severity: Sendable, Equatable { case info, warning }

    public init(_ message: String, severity: Severity = .info) {
        self.message = message
        self.severity = severity
    }
    public static func == (a: ScheduleDiagnostic, b: ScheduleDiagnostic) -> Bool {
        a.message == b.message && a.severity == b.severity
    }
}

/// A continuous, sorted set of anchors spanning yesterday through tomorrow.
public struct Timeline: Equatable, Sendable {
    public var anchors: [ResolvedAnchor]
    public var diagnostics: [ScheduleDiagnostic]
    public var referenceMidnight: Date
    public var timeZone: TimeZone

    public init(anchors: [ResolvedAnchor],
                diagnostics: [ScheduleDiagnostic],
                referenceMidnight: Date,
                timeZone: TimeZone) {
        self.anchors = anchors
        self.diagnostics = diagnostics
        self.referenceMidnight = referenceMidnight
        self.timeZone = timeZone
    }

    /// Anchors that fall inside today, for display.
    public var todayAnchors: [ResolvedAnchor] {
        anchors.filter { $0.seconds >= 0 && $0.seconds < 86_400 }
    }
}

public enum SchedulePhase: Equatable, Sendable {
    case holding(anchorName: String)
    case transitioning(from: String, to: String, progress: Double)
}

public struct ScheduleEvaluation: Equatable, Sendable {
    public var target: ResolvedTarget
    public var phase: SchedulePhase
    /// The anchor whose values are currently in force (or being approached).
    public var currentAnchorName: String
    public var nextAnchor: ResolvedAnchor?
    /// Absolute time at which the output next changes in a way worth waking for.
    public var nextChangeAt: Date?
    public var diagnostics: [ScheduleDiagnostic]

    public var isInTransition: Bool {
        if case .transitioning = phase { return true }
        return false
    }
}

public enum ScheduleResolver {

    /// Anchors resolving within this window of each other are treated as a
    /// conflict; the lower-priority one is dropped. Keeps a hybrid schedule
    /// from producing two competing ramps a few minutes apart.
    public static let mergeWindowSeconds: Double = 15 * 60

    public static func timeline(
        for schedule: Schedule,
        on date: Date,
        timeZone: TimeZone,
        location: GeoLocation?
    ) -> Timeline {
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = timeZone
        let midnight = cal.startOfDay(for: date)
        var out: [ResolvedAnchor] = []
        var diags: [ScheduleDiagnostic] = []
        var seenFallback = Set<String>()

        for dayOffset in -1...1 {
            guard let dayDate = cal.date(byAdding: .day, value: dayOffset, to: midnight) else { continue }
            let weekday = cal.component(.weekday, from: dayDate)
            let dayAnchors = schedule.anchors(forWeekday: weekday).filter(\.isEnabled)

            // The whole timeline lives in wall-clock space, so a day is
            // always a nominal 24 hours here. Using real elapsed time would
            // desynchronise anchors from the clock on a 23- or 25-hour
            // daylight-saving day, which is exactly when people notice.
            let dayBase = Double(dayOffset) * 86_400

            var resolvedForDay: [ResolvedAnchor] = []
            for anchor in dayAnchors {
                let (secs, origin, note) = resolve(
                    anchor: anchor, dayDate: dayDate, timeZone: timeZone, location: location
                )
                if let note, dayOffset == 0, !seenFallback.contains(note) {
                    seenFallback.insert(note)
                    diags.append(ScheduleDiagnostic(note, severity: .warning))
                }
                resolvedForDay.append(ResolvedAnchor(
                    anchor: anchor, seconds: dayBase + secs, origin: origin, dayOffset: dayOffset
                ))
            }

            // Conflict resolution within a single day. Explicit clock anchors
            // outrank solar ones, because a stated routine is more
            // authoritative than an astronomical event.
            resolvedForDay.sort { a, b in
                if a.seconds != b.seconds { return a.seconds < b.seconds }
                return priority(a) > priority(b)
            }
            var kept: [ResolvedAnchor] = []
            for candidate in resolvedForDay {
                if let last = kept.last,
                   candidate.seconds - last.seconds < mergeWindowSeconds {
                    let loser = priority(candidate) > priority(last) ? last : candidate
                    let winner = priority(candidate) > priority(last) ? candidate : last
                    if priority(candidate) > priority(last) { kept[kept.count - 1] = candidate }
                    if dayOffset == 0 {
                        diags.append(ScheduleDiagnostic(
                            "“\(loser.anchor.name)” lands within 15 minutes of “\(winner.anchor.name)”, so only “\(winner.anchor.name)” is used today.",
                            severity: .warning))
                    }
                } else {
                    kept.append(candidate)
                }
            }
            out.append(contentsOf: kept)
        }

        out.sort { $0.seconds < $1.seconds }
        if out.isEmpty {
            diags.append(ScheduleDiagnostic(
                "This schedule has no enabled anchors, so Daylight is leaving your display neutral.",
                severity: .warning))
        }
        return Timeline(anchors: out, diagnostics: diags,
                        referenceMidnight: midnight, timeZone: timeZone)
    }

    private static func priority(_ r: ResolvedAnchor) -> Int {
        switch r.origin {
        case .clock: return 2
        case .solarClamped: return 1
        case .solar, .solarFallback: return 0
        }
    }

    private static func resolve(
        anchor: ScheduleAnchor,
        dayDate: Date,
        timeZone: TimeZone,
        location: GeoLocation?
    ) -> (Double, AnchorOrigin, String?) {
        switch anchor.time {
        case .clock(let s):
            return (Double(s), .clock, nil)

        case .solar(let event, let offsetMinutes, let earliest, let latest):
            guard let location else {
                let fallback = defaultFallbackSeconds(for: event)
                return (fallback, .solarFallback(event, reason: .noLocation),
                        "No location is set, so “\(anchor.name)” is using \(clockString(fallback)) instead of \(event.friendlyName).")
            }
            let result = SolarCalculator.event(event, date: dayDate, location: location, timeZone: timeZone)
            switch result {
            case .polarDay:
                let fallback = clampSeconds(defaultFallbackSeconds(for: event), earliest, latest)
                return (fallback, .solarFallback(event, reason: .polarDay),
                        "The sun does not set at \(location.label) today, so “\(anchor.name)” is using \(clockString(fallback)).")
            case .polarNight:
                let fallback = clampSeconds(defaultFallbackSeconds(for: event), earliest, latest)
                return (fallback, .solarFallback(event, reason: .polarNight),
                        "The sun does not rise at \(location.label) today, so “\(anchor.name)” is using \(clockString(fallback)).")
            case .occurs(let s):
                let shifted = s + Double(offsetMinutes) * 60
                if let earliest, shifted < Double(earliest) {
                    return (Double(earliest), .solarClamped(event, clamp: .earliest), nil)
                }
                if let latest, shifted > Double(latest) {
                    return (Double(latest), .solarClamped(event, clamp: .latest), nil)
                }
                return (shifted, .solar(event), nil)
            }
        }
    }

    private static func clampSeconds(_ v: Double, _ lo: Int?, _ hi: Int?) -> Double {
        var v = v
        if let lo { v = max(v, Double(lo)) }
        if let hi { v = min(v, Double(hi)) }
        return v
    }

    /// Used when a solar event genuinely has no answer. Chosen to be
    /// unremarkable rather than clever.
    static func defaultFallbackSeconds(for event: SolarEvent) -> Double {
        switch event {
        case .sunrise:   return 7 * 3600
        case .civilDawn: return 6 * 3600 + 30 * 60
        case .sunset:    return 19 * 3600
        case .civilDusk: return 19 * 3600 + 30 * 60
        }
    }
}

public func clockString(_ secondsFromMidnight: Double) -> String {
    var s = secondsFromMidnight.truncatingRemainder(dividingBy: 86_400)
    if s < 0 { s += 86_400 }
    let h = Int(s) / 3600, m = (Int(s) % 3600) / 60
    return String(format: "%02d:%02d", h, m)
}

extension SolarEvent {
    public var friendlyName: String {
        switch self {
        case .sunrise: return "sunrise"
        case .sunset: return "sunset"
        case .civilDawn: return "first light"
        case .civilDusk: return "last light"
        }
    }
}

// MARK: - Evaluation

extension Timeline {

    /// Evaluate the schedule at an absolute instant.
    ///
    /// Deliberately pure: give it a clock reading and it tells you what the
    /// display should look like. No timers, no hardware, no hidden state —
    /// which is what makes the whole scheduling story testable.
    public func evaluate(at now: Date) -> ScheduleEvaluation {
        // Wall-clock seconds from local midnight, deliberately *not* elapsed
        // time. On a daylight-saving day the two differ by an hour, and a
        // schedule that says "19:00" must mean 19:00 on the clock.
        return evaluateCore(wallClockSeconds: Timeline.wallClockSeconds(of: now, in: timeZone))
    }

    private func evaluateCore(wallClockSeconds t: Double) -> ScheduleEvaluation {

        guard !anchors.isEmpty else {
            return ScheduleEvaluation(
                target: .neutral, phase: .holding(anchorName: "Neutral"),
                currentAnchorName: "Neutral", nextAnchor: nil,
                nextChangeAt: nil, diagnostics: diagnostics)
        }

        // The anchor most recently passed, and the next one coming up.
        var previousIndex = anchors.lastIndex(where: { $0.seconds <= t })
        if previousIndex == nil { previousIndex = anchors.indices.last }
        let prev = anchors[previousIndex!]
        let nextIndex = anchors.firstIndex(where: { $0.seconds > t })
        let next = nextIndex.map { anchors[$0] }

        guard let next else {
            // Past the end of the resolved window; hold the last value.
            return ScheduleEvaluation(
                target: prev.target, phase: .holding(anchorName: prev.anchor.name),
                currentAnchorName: prev.anchor.name, nextAnchor: nil,
                nextChangeAt: nil, diagnostics: diagnostics)
        }

        // A transition of duration D ends exactly at the next anchor's time.
        let rampSeconds = max(0, next.anchor.transitionMinutes * 60)
        let rampStart = next.seconds - rampSeconds

        if t >= rampStart && rampSeconds > 0 {
            let progress = min(max((t - rampStart) / rampSeconds, 0), 1)
            let target = ResolvedTarget.interpolate(prev.target, next.target, progress)
            return ScheduleEvaluation(
                target: target,
                phase: .transitioning(from: prev.anchor.name, to: next.anchor.name, progress: progress),
                currentAnchorName: next.anchor.name,
                nextAnchor: next,
                nextChangeAt: absoluteDate(wallClockSeconds: next.seconds),
                diagnostics: diagnostics)
        }

        return ScheduleEvaluation(
            target: prev.target,
            phase: .holding(anchorName: prev.anchor.name),
            currentAnchorName: prev.anchor.name,
            nextAnchor: next,
            nextChangeAt: absoluteDate(wallClockSeconds: rampStart),
            diagnostics: diagnostics)
    }

    /// Sample the whole visible day, for drawing the timeline. Pure geometry —
    /// no side effects, so the view can call it freely.
    public func sample(stepSeconds: Double = 300) -> [(seconds: Double, target: ResolvedTarget)] {
        stride(from: 0.0, through: 86_400.0, by: stepSeconds).map { s in
            (s, evaluateAtWallClock(seconds: s).target)
        }
    }

    /// Evaluate at an arbitrary point on the clock, without needing a real
    /// `Date`. Used for drawing the timeline and for "preview my day".
    public func evaluateAtWallClock(seconds: Double) -> ScheduleEvaluation {
        var s = seconds.truncatingRemainder(dividingBy: 86_400)
        if s < 0 { s += 86_400 }
        return evaluateCore(wallClockSeconds: s)
    }

    /// Wall-clock seconds since local midnight, from the clock's own fields
    /// rather than by subtracting dates.
    public static func wallClockSeconds(of date: Date, in zone: TimeZone) -> Double {
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = zone
        let c = cal.dateComponents([.hour, .minute, .second, .nanosecond], from: date)
        return Double(c.hour ?? 0) * 3600 + Double(c.minute ?? 0) * 60
             + Double(c.second ?? 0) + Double(c.nanosecond ?? 0) / 1e9
    }

    /// Turn a wall-clock offset (which may fall on yesterday or tomorrow) back
    /// into a real instant, letting Calendar handle daylight-saving gaps.
    public func absoluteDate(wallClockSeconds: Double) -> Date? {
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = timeZone
        var s = wallClockSeconds
        var dayOffset = 0
        while s < 0 { s += 86_400; dayOffset -= 1 }
        while s >= 86_400 { s -= 86_400; dayOffset += 1 }
        guard let day = cal.date(byAdding: .day, value: dayOffset, to: referenceMidnight)
        else { return nil }
        let ymd = cal.dateComponents([.year, .month, .day], from: day)
        let comps = DateComponents(year: ymd.year, month: ymd.month, day: ymd.day,
                                   hour: Int(s) / 3600,
                                   minute: (Int(s) % 3600) / 60,
                                   second: Int(s) % 60)
        // A nonexistent local time (the spring-forward gap) has no exact
        // answer; falling forward to the next real instant is the behaviour
        // people expect from an alarm-like schedule.
        return cal.date(from: comps) ?? day.addingTimeInterval(s)
    }
}
