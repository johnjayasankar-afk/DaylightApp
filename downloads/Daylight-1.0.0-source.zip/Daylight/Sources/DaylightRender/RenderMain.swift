import SwiftUI
import AppKit
import DaylightCore
import DaylightDisplay
import DaylightUI

/// Renders the real views to PNG files.
///
/// This exists so the interface can actually be looked at — in both themes and
/// at a narrow width — rather than taken on trust. It renders the same view
/// types the app ships, against simulated displays, touching no hardware.
@main
struct RenderMain {
    static func main() {
        let app = NSApplication.shared
        app.setActivationPolicy(.accessory)

        let outDir = CommandLine.arguments.count > 1
            ? CommandLine.arguments[1] : FileManager.default.currentDirectoryPath
        try? FileManager.default.createDirectory(atPath: outDir, withIntermediateDirectories: true)

        let tmp = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent("daylight-render-\(UUID().uuidString)")
        let store = SettingsStore(directory: tmp)
        try? store.save(sampleSettings())

        let coordinator = LightingCoordinator(store: store, useSimulation: true)
        coordinator.start()
        RunLoop.current.run(until: Date().addingTimeInterval(0.4))

        var shots: [(String, AnyView, CGSize)] = []
        for name in DaylightUI.Review.panelNames {
            guard let view = DaylightUI.Review.panel(named: name, coordinator: coordinator) else { continue }
            shots.append((name.lowercased(), view, CGSize(width: 760, height: panelHeight(name))))
        }
        if let rules = DaylightUI.Review.panel(named: "Rules", coordinator: coordinator, expanded: true) {
            shots.append(("rules-editing", rules, CGSize(width: 760, height: 1500)))
        }
        shots.append(("menubar", DaylightUI.menuBar(coordinator: coordinator, commands: nil),
                      CGSize(width: 324, height: 700)))
        shots.append(("onboarding", DaylightUI.onboarding(coordinator: coordinator, commands: nil),
                      CGSize(width: 640, height: 560)))
        shots.append(("onboarding-day", DaylightUI.onboarding(coordinator: coordinator, commands: nil, step: 2),
                      CGSize(width: 640, height: 560)))
        shots.append(("onboarding-warmth", DaylightUI.onboarding(coordinator: coordinator, commands: nil, step: 3),
                      CGSize(width: 640, height: 560)))
        if let today = DaylightUI.Review.panel(named: "Today", coordinator: coordinator) {
            shots.append(("today-narrow", today, CGSize(width: 460, height: 980)))
        }

        // Whole-window shots, for the site.
        for name in ["Today", "Schedule", "Displays", "Rules"] {
            shots.append(("window-\(name.lowercased())",
                          DaylightUI.window(coordinator: coordinator, panelNamed: name),
                          CGSize(width: 1000, height: 700)))
        }

        for (name, view, size) in shots {
            for scheme in [ColorScheme.light, .dark] {
                let suffix = scheme == .light ? "light" : "dark"
                render(view.frame(width: size.width, height: size.height)
                        .background(Palette.surface)
                        .environment(\.colorScheme, scheme),
                       size: size, to: "\(outDir)/\(name)-\(suffix).png",
                       dark: scheme == .dark)
            }
        }
        print("rendered \(shots.count * 2) images to \(outDir)")
        try? FileManager.default.removeItem(at: tmp)
        exit(0)
    }

    /// Panels differ a lot in length; rendering each at its own height avoids
    /// clipping content that would then never be reviewed.
    static func panelHeight(_ name: String) -> CGFloat {
        switch name {
        case "Displays": return 2400
        case "Schedule": return 1500
        case "Today":    return 1400
        case "Rules":    return 1500
        case "Settings": return 3200
        case "Modes":    return 1250
        default:         return 1000
        }
    }

    /// A configuration with enough going on to exercise the interface: rules,
    /// a location, groups and workspaces.
    static func sampleSettings() -> DaylightSettings {
        var settings = Presets.defaultSettings()
        settings.hasCompletedOnboarding = true
        settings.location = GeoLocation(latitude: 51.5074, longitude: -0.1278, label: "London")
        settings.appRulesEnabled = true
        settings.rules = [
            Rule(name: "Photos stays neutral",
                 triggers: [.frontmostApp(bundleIdentifier: "com.apple.Photos", displayName: "Photos")],
                 actions: [.pauseWarmth], order: 0),
            Rule(name: "Dim on battery", triggers: [.onBatteryPower],
                 actions: [.setDimming(SoftwareDimming(factor: 0.75))], order: 1),
        ]
        settings.groups = [
            DisplayGroup(name: "Desk pair", memberKeys: ["sim:builtin", "sim:external"])
        ]
        settings.breakReminders = BreakReminderSettings(isEnabled: true)
        settings.history = HistorySettings(isEnabled: true, retentionDays: 7)
        settings.workspaces = [
            Workspace(name: "Home desk", requiredDisplayKeys: ["sim:external"],
                      target: LightingTarget(dimming: SoftwareDimming(factor: 0.9))),
            Workspace(name: "Travelling", requiredDisplayKeys: []),
        ]
        return settings
    }

    /// Renders a view offscreen.
    ///
    /// The hosting view goes into a real (offscreen) window rather than being
    /// drawn free-standing: `NavigationSplitView` and `List` need a window to
    /// lay out at all, and without one the sidebar comes out empty.
    static func render<V: View>(_ view: V, size: CGSize, to path: String, dark: Bool) {
        let appearance = NSAppearance(named: dark ? .darkAqua : .aqua)!
        NSApp?.appearance = appearance

        let window = NSWindow(
            contentRect: CGRect(origin: .zero, size: size),
            styleMask: [.borderless], backing: .buffered, defer: false)
        window.appearance = appearance
        window.isReleasedWhenClosed = false
        // Far offscreen, so nothing flashes on a real display while rendering.
        window.setFrameOrigin(NSPoint(x: -40_000, y: -40_000))

        let host = NSHostingView(rootView: view)
        host.frame = CGRect(origin: .zero, size: size)
        window.contentView = host
        window.orderFront(nil)
        host.layoutSubtreeIfNeeded()
        RunLoop.current.run(until: Date().addingTimeInterval(0.35))
        host.layoutSubtreeIfNeeded()

        var written = false
        appearance.performAsCurrentDrawingAppearance {
            guard let rep = host.bitmapImageRepForCachingDisplay(in: host.bounds) else { return }
            rep.size = size
            host.cacheDisplay(in: host.bounds, to: rep)
            if let data = rep.representation(using: .png, properties: [:]) {
                try? data.write(to: URL(fileURLWithPath: path))
                written = true
            }
        }
        window.orderOut(nil)
        if !written { FileHandle.standardError.write(Data("failed: \(path)\n".utf8)) }
    }
}
